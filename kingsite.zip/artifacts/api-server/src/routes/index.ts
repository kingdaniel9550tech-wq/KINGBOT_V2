import { Router } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import usersRouter from "./users";
import pagesRouter from "./pages";
import postsRouter from "./posts";
import statsRouter from "./stats";
import uploadsRouter from "./uploads";
import storiesRouter from "./stories";
import messagesRouter from "./messages";
import notificationsRouter from "./notifications";

const router = Router();

router.use("/healthz", healthRouter);
router.use("/auth", authRouter);
router.use("/users", usersRouter);
router.use("/pages", pagesRouter);
router.use("/posts", postsRouter);
router.use("/stats", statsRouter);
router.use("/uploads", uploadsRouter);
router.use("/stories", storiesRouter);
router.use("/messages", messagesRouter);
router.use("/notifications", notificationsRouter);

export default router;
