import { Router, type Request, type Response } from "express";
import { db, pagesTable, postsTable, pageAccessTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { requireAuth, requireRole } from "../middlewares/auth";

const router = Router();

router.get("/", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;

  const pages = await db.select().from(pagesTable).where(eq(pagesTable.isActive, true));

  const postCounts = await db
    .select({ pageId: postsTable.pageId, count: sql<number>`count(*)::int` })
    .from(postsTable)
    .groupBy(postsTable.pageId);
  const countMap = new Map(postCounts.map((r) => [r.pageId, r.count]));

  if (user.role === "owner" || user.role === "admin") {
    return res.json(
      pages.map((p) => ({
        ...p,
        postCount: countMap.get(p.id) ?? 0,
      }))
    );
  }

  const access = await db
    .select()
    .from(pageAccessTable)
    .where(eq(pageAccessTable.userId, user.id));

  const accessPageIds = new Set(access.map((a) => a.pageId));

  return res.json(
    pages
      .filter((p) => accessPageIds.has(p.id))
      .map((p) => ({
        ...p,
        postCount: countMap.get(p.id) ?? 0,
      }))
  );
});

router.post("/", requireAuth, requireRole("owner"), async (req: Request, res: Response) => {
  const { name, slug, description } = req.body;

  if (!name || !slug) {
    res.status(400).json({ error: "name and slug are required" });
    return;
  }

  const [page] = await db
    .insert(pagesTable)
    .values({ name, slug, description: description ?? null })
    .returning();

  res.status(201).json({ ...page, postCount: 0 });
});

router.patch("/:pageId", requireAuth, requireRole("owner"), async (req: Request, res: Response) => {
  const pageId = parseInt(req.params.pageId);
  const { name, description, isActive } = req.body;

  const updates: Record<string, unknown> = {};
  if (name !== undefined) updates.name = name;
  if (description !== undefined) updates.description = description;
  if (isActive !== undefined) updates.isActive = isActive;

  const [page] = await db
    .update(pagesTable)
    .set(updates)
    .where(eq(pagesTable.id, pageId))
    .returning();

  if (!page) {
    res.status(404).json({ error: "Page not found" });
    return;
  }

  const [postCountRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(postsTable)
    .where(eq(postsTable.pageId, pageId));

  res.json({ ...page, postCount: postCountRow?.count ?? 0 });
});

router.delete("/:pageId", requireAuth, requireRole("owner"), async (req: Request, res: Response) => {
  const pageId = parseInt(req.params.pageId);
  await db.delete(pagesTable).where(eq(pagesTable.id, pageId));
  res.json({ success: true, message: "Page deleted" });
});

export default router;
