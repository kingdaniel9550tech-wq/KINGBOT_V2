import { Router, type Request, type Response } from "express";
import { db, usersTable, postsTable, pagesTable, commentsTable } from "@workspace/db";
import { sql, eq, desc } from "drizzle-orm";
import { requireAuth, requireRole } from "../middlewares/auth";

const router = Router();

router.get("/overview", requireAuth, requireRole("owner"), async (req: Request, res: Response) => {
  const user = (req as any).user;

  const [userCountRow] = await db.select({ count: sql<number>`count(*)::int` }).from(usersTable);
  const [postCountRow] = await db.select({ count: sql<number>`count(*)::int` }).from(postsTable);
  const [pageCountRow] = await db.select({ count: sql<number>`count(*)::int` }).from(pagesTable);
  const [commentCountRow] = await db.select({ count: sql<number>`count(*)::int` }).from(commentsTable);

  const allUsers = await db.select().from(usersTable);
  const activeUsers = allUsers.filter((u) => !!u.sessionToken).length;

  const recentPostsRaw = await db
    .select()
    .from(postsTable)
    .orderBy(desc(postsTable.createdAt))
    .limit(5);

  const { likesTable, pageAccessTable } = await import("@workspace/db");
  const { and } = await import("drizzle-orm");

  const recentPosts = await Promise.all(
    recentPostsRaw.map(async (post) => {
      const [author] = await db.select().from(usersTable).where(eq(usersTable.id, post.authorId));
      const [page] = post.pageId
        ? await db.select().from(pagesTable).where(eq(pagesTable.id, post.pageId))
        : [null];

      const [likeCountRow] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(likesTable)
        .where(eq(likesTable.postId, post.id));

      const [commentCountRow] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(commentsTable)
        .where(eq(commentsTable.postId, post.id));

      return {
        id: post.id,
        content: post.content,
        imageUrl: post.imageUrl,
        videoUrl: post.videoUrl,
        mediaType: post.mediaType,
        authorId: post.authorId,
        authorName: author?.displayName ?? author?.username ?? "Unknown",
        pageId: post.pageId,
        pageName: page?.name ?? null,
        likeCount: likeCountRow?.count ?? 0,
        commentCount: commentCountRow?.count ?? 0,
        isLikedByMe: false,
        createdAt: post.createdAt,
      };
    })
  );

  res.json({
    totalUsers: userCountRow?.count ?? 0,
    totalPosts: postCountRow?.count ?? 0,
    totalPages: pageCountRow?.count ?? 0,
    totalComments: commentCountRow?.count ?? 0,
    activeUsers,
    recentPosts,
  });
});

export default router;
