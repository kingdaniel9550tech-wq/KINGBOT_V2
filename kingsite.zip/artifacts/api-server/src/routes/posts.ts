import { Router, type Request, type Response } from "express";
import { db, postsTable, usersTable, pagesTable, likesTable, commentsTable, pageAccessTable, notificationsTable } from "@workspace/db";
import { eq, desc, sql, and, or, isNull, inArray } from "drizzle-orm";
import { requireAuth, requireRole } from "../middlewares/auth";

const router = Router();

async function buildPostResponse(post: typeof postsTable.$inferSelect, userId: number) {
  const [author] = await db.select().from(usersTable).where(eq(usersTable.id, post.authorId));
  const [page] = post.pageId ? await db.select().from(pagesTable).where(eq(pagesTable.id, post.pageId)) : [null];

  const [likeCountRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(likesTable)
    .where(eq(likesTable.postId, post.id));

  const [commentCountRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(commentsTable)
    .where(eq(commentsTable.postId, post.id));

  const myLike = await db
    .select()
    .from(likesTable)
    .where(and(eq(likesTable.postId, post.id), eq(likesTable.userId, userId)));

  return {
    id: post.id,
    content: post.content,
    imageUrl: post.imageUrl,
    videoUrl: post.videoUrl,
    mediaType: post.mediaType,
    images: post.images ?? [],
    documents: (post as any).documents ?? [],
    authorId: post.authorId,
    authorName: author?.displayName ?? author?.username ?? "Unknown",
    authorAvatarUrl: author?.avatarUrl ?? null,
    authorIsVerified: author?.isVerified ?? false,
    pageId: post.pageId,
    pageName: page?.name ?? null,
    likeCount: likeCountRow?.count ?? 0,
    commentCount: commentCountRow?.count ?? 0,
    isLikedByMe: myLike.length > 0,
    createdAt: post.createdAt,
  };
}

router.get("/", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;
  const pageId = req.query.pageId ? parseInt(req.query.pageId as string) : undefined;

  if (pageId !== undefined && (user.role === "user")) {
    const access = await db
      .select()
      .from(pageAccessTable)
      .where(and(eq(pageAccessTable.userId, user.id), eq(pageAccessTable.pageId, pageId)));
    if (access.length === 0) {
      res.status(403).json({ error: "Access denied to this page" });
      return;
    }
  }

  let posts;
  if (pageId !== undefined) {
    posts = await db.select().from(postsTable).where(eq(postsTable.pageId, pageId)).orderBy(desc(postsTable.createdAt));
  } else if (user.role === "user") {
    const accessRows = await db.select().from(pageAccessTable).where(eq(pageAccessTable.userId, user.id));
    const accessiblePageIds = accessRows.map((a) => a.pageId);
    if (accessiblePageIds.length > 0) {
      posts = await db
        .select()
        .from(postsTable)
        .where(or(isNull(postsTable.pageId), inArray(postsTable.pageId, accessiblePageIds)))
        .orderBy(desc(postsTable.createdAt));
    } else {
      posts = await db.select().from(postsTable).where(isNull(postsTable.pageId)).orderBy(desc(postsTable.createdAt));
    }
  } else {
    posts = await db.select().from(postsTable).orderBy(desc(postsTable.createdAt));
  }

  const result = await Promise.all(posts.map((p) => buildPostResponse(p, user.id)));
  res.json(result);
});

router.post("/", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;
  const { content, imageUrl, videoUrl, mediaType, pageId } = req.body;

  const { images, documents } = req.body;
  const hasImages = Array.isArray(images) && images.length > 0;
  const hasDocuments = Array.isArray(documents) && documents.length > 0;

  if (!content && !imageUrl && !videoUrl && !hasImages && !hasDocuments) {
    res.status(400).json({ error: "Post must have content, image, video, or document" });
    return;
  }

  const [post] = await db
    .insert(postsTable)
    .values({
      content: content ?? null,
      imageUrl: imageUrl ?? null,
      videoUrl: videoUrl ?? null,
      mediaType: mediaType ?? null,
      authorId: user.id,
      pageId: pageId ?? null,
      images: hasImages ? images : [],
      documents: hasDocuments ? documents : [],
    } as any)
    .returning();

  const response = await buildPostResponse(post, user.id);
  res.status(201).json(response);
});

router.get("/:postId", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;
  const postId = parseInt(req.params.postId);

  const [post] = await db.select().from(postsTable).where(eq(postsTable.id, postId));
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  const response = await buildPostResponse(post, user.id);
  res.json(response);
});

router.delete("/:postId", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;
  const postId = parseInt(req.params.postId);

  const [post] = await db.select().from(postsTable).where(eq(postsTable.id, postId));
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  if (user.role !== "owner" && post.authorId !== user.id) {
    res.status(403).json({ error: "Cannot delete someone else's post" });
    return;
  }

  await db.delete(postsTable).where(eq(postsTable.id, postId));
  res.json({ success: true, message: "Post deleted" });
});

router.post("/:postId/like", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;
  const postId = parseInt(req.params.postId);

  const existing = await db
    .select()
    .from(likesTable)
    .where(and(eq(likesTable.postId, postId), eq(likesTable.userId, user.id)));

  if (existing.length > 0) {
    await db
      .delete(likesTable)
      .where(and(eq(likesTable.postId, postId), eq(likesTable.userId, user.id)));
  } else {
    await db.insert(likesTable).values({ postId, userId: user.id });
  }

  const [countRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(likesTable)
    .where(eq(likesTable.postId, postId));

  res.json({ liked: existing.length === 0, likeCount: countRow?.count ?? 0 });
});

router.get("/:postId/comments", requireAuth, async (req: Request, res: Response) => {
  const postId = parseInt(req.params.postId);

  const comments = await db
    .select()
    .from(commentsTable)
    .where(eq(commentsTable.postId, postId))
    .orderBy(commentsTable.createdAt);

  const result = await Promise.all(
    comments.map(async (c) => {
      const [author] = await db.select().from(usersTable).where(eq(usersTable.id, c.authorId));
      return {
        id: c.id,
        postId: c.postId,
        authorId: c.authorId,
        authorName: author?.displayName ?? author?.username ?? "Unknown",
        content: c.content,
        createdAt: c.createdAt,
      };
    })
  );

  res.json(result);
});

router.post("/:postId/comments", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;
  const postId = parseInt(req.params.postId);
  const { content } = req.body;

  if (!content || !content.trim()) {
    res.status(400).json({ error: "Comment content is required" });
    return;
  }

  const [comment] = await db
    .insert(commentsTable)
    .values({ postId, authorId: user.id, content: content.trim() })
    .returning();

  const [post] = await db.select().from(postsTable).where(eq(postsTable.id, postId));
  if (post && post.authorId !== user.id) {
    const commenterName = user.displayName ?? user.username;
    await db.insert(notificationsTable).values({
      userId: post.authorId,
      actorId: user.id,
      type: "comment",
      postId,
      message: `${commenterName} commented on your post`,
    });
  }

  res.status(201).json({
    id: comment.id,
    postId: comment.postId,
    authorId: comment.authorId,
    authorName: user.displayName ?? user.username,
    content: comment.content,
    createdAt: comment.createdAt,
  });
});

router.delete("/:postId/comments/:commentId", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;
  const commentId = parseInt(req.params.commentId);

  const [comment] = await db.select().from(commentsTable).where(eq(commentsTable.id, commentId));
  if (!comment) {
    res.status(404).json({ error: "Comment not found" });
    return;
  }

  if (user.role !== "owner" && comment.authorId !== user.id) {
    res.status(403).json({ error: "Cannot delete someone else's comment" });
    return;
  }

  await db.delete(commentsTable).where(eq(commentsTable.id, commentId));
  res.json({ success: true, message: "Comment deleted" });
});

export default router;
