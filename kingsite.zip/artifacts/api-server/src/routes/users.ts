import { Router, type Request, type Response } from "express";
import bcrypt from "bcrypt";
import { db, usersTable, pagesTable, pageAccessTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth, requireRole } from "../middlewares/auth";

function publicUser(u: typeof usersTable.$inferSelect, extra?: { isOnline?: boolean }) {
  return {
    id: u.id,
    username: u.username,
    role: u.role,
    displayName: u.displayName,
    avatarUrl: u.avatarUrl,
    isVerified: u.isVerified,
    isActive: u.isActive,
    createdAt: u.createdAt,
    lastLoginAt: u.lastLoginAt,
    isOnline: extra?.isOnline ?? !!u.sessionToken,
  };
}

const router = Router();

router.get("/members", requireAuth, async (_req: Request, res: Response) => {
  const users = await db.select().from(usersTable).where(eq(usersTable.isActive, true));
  res.json(
    users.map((u) => ({
      id: u.id,
      username: u.username,
      displayName: u.displayName,
      avatarUrl: u.avatarUrl,
      isVerified: u.isVerified,
      role: u.role,
    }))
  );
});

// Update own profile (displayName + avatarUrl)
router.patch("/me", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;
  const { displayName, avatarUrl } = req.body;
  const updates: Record<string, unknown> = {};
  if (displayName !== undefined) updates.displayName = displayName || null;
  if (avatarUrl !== undefined) updates.avatarUrl = avatarUrl || null;

  const [updated] = await db.update(usersTable).set(updates).where(eq(usersTable.id, user.id)).returning();
  res.json(publicUser(updated));
});

// Toggle verification badge (owner only)
router.post("/:userId/verify", requireAuth, requireRole("owner"), async (req: Request, res: Response) => {
  const userId = parseInt(req.params.userId);
  const [current] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!current) { res.status(404).json({ error: "User not found" }); return; }
  const [updated] = await db.update(usersTable).set({ isVerified: !current.isVerified }).where(eq(usersTable.id, userId)).returning();
  res.json(publicUser(updated));
});

router.get("/", requireAuth, requireRole("owner"), async (_req: Request, res: Response) => {
  const users = await db.select().from(usersTable);
  res.json(users.map((u) => publicUser(u)));
});

router.post("/", requireAuth, requireRole("owner"), async (req: Request, res: Response) => {
  const { username, password, role, displayName } = req.body;

  if (!username || !password || !role) {
    res.status(400).json({ error: "username, password, and role are required" });
    return;
  }

  if (!["admin", "user"].includes(role)) {
    res.status(400).json({ error: "role must be admin or user" });
    return;
  }

  const existing = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.username, username));

  if (existing.length > 0) {
    res.status(400).json({ error: "Username already taken" });
    return;
  }

  const passwordHash = await bcrypt.hash(password, 12);

  const [user] = await db
    .insert(usersTable)
    .values({ username, passwordHash, role, displayName: displayName ?? null })
    .returning();

  res.status(201).json(publicUser(user, { isOnline: false }));
});

router.patch("/:userId", requireAuth, requireRole("owner"), async (req: Request, res: Response) => {
  const userId = parseInt(req.params.userId);
  const { password, role, displayName, isActive } = req.body;

  const updates: Record<string, unknown> = {};
  if (password) updates.passwordHash = await bcrypt.hash(password, 12);
  if (role !== undefined) updates.role = role;
  if (displayName !== undefined) updates.displayName = displayName;
  if (isActive !== undefined) updates.isActive = isActive;

  const [user] = await db
    .update(usersTable)
    .set(updates)
    .where(eq(usersTable.id, userId))
    .returning();

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json(publicUser(user));
});

router.delete("/:userId", requireAuth, requireRole("owner"), async (req: Request, res: Response) => {
  const userId = parseInt(req.params.userId);
  const currentUser = (req as any).user;

  if (userId === currentUser.id) {
    res.status(400).json({ error: "Cannot delete your own account" });
    return;
  }

  await db.delete(usersTable).where(eq(usersTable.id, userId));
  res.json({ success: true, message: "User deleted" });
});

router.post("/:userId/kick", requireAuth, requireRole("owner"), async (req: Request, res: Response) => {
  const userId = parseInt(req.params.userId);

  await db
    .update(usersTable)
    .set({ sessionToken: null })
    .where(eq(usersTable.id, userId));

  res.json({ success: true, message: "User session terminated" });
});

router.get("/:userId/page-access", requireAuth, requireRole("owner"), async (req: Request, res: Response) => {
  const userId = parseInt(req.params.userId);

  const allPages = await db.select().from(pagesTable);
  const access = await db
    .select()
    .from(pageAccessTable)
    .where(eq(pageAccessTable.userId, userId));

  const accessPageIds = new Set(access.map((a) => a.pageId));

  res.json(
    allPages.map((p) => ({
      pageId: p.id,
      pageName: p.name,
      hasAccess: accessPageIds.has(p.id),
    }))
  );
});

router.put("/:userId/page-access", requireAuth, requireRole("owner"), async (req: Request, res: Response) => {
  const userId = parseInt(req.params.userId);
  const { pageIds } = req.body as { pageIds: number[] };

  await db.delete(pageAccessTable).where(eq(pageAccessTable.userId, userId));

  if (pageIds && pageIds.length > 0) {
    await db.insert(pageAccessTable).values(
      pageIds.map((pageId) => ({ userId, pageId }))
    );
  }

  res.json({ success: true, message: "Access updated" });
});

export default router;
