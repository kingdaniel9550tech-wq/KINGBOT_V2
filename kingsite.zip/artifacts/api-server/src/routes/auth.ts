import { Router, type Request, type Response } from "express";
import bcrypt from "bcrypt";
import { randomUUID } from "crypto";
import { db, usersTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router = Router();

router.post("/register", async (req: Request, res: Response) => {
  const { username, password, displayName } = req.body;

  if (!username || !password) {
    res.status(400).json({ error: "Username and password required" });
    return;
  }

  if (username.length < 3 || username.length > 30) {
    res.status(400).json({ error: "Username must be 3–30 characters" });
    return;
  }

  if (!/^[a-zA-Z0-9_]+$/.test(username)) {
    res.status(400).json({ error: "Username may only contain letters, numbers, and underscores" });
    return;
  }

  if (password.length < 6) {
    res.status(400).json({ error: "Password must be at least 6 characters" });
    return;
  }

  const [existing] = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(sql`lower(${usersTable.username}) = lower(${username})`);

  if (existing) {
    res.status(409).json({ error: "Username is already taken" });
    return;
  }

  const passwordHash = await bcrypt.hash(password, 10);

  const [user] = await db
    .insert(usersTable)
    .values({
      username,
      passwordHash,
      role: "user",
      displayName: displayName?.trim() || null,
      isActive: true,
    })
    .returning();

  const sessionToken = randomUUID();
  await db
    .update(usersTable)
    .set({ sessionToken, lastLoginAt: new Date() })
    .where(eq(usersTable.id, user.id));

  req.session.userId = user.id;
  req.session.sessionToken = sessionToken;

  res.status(201).json({
    id: user.id,
    username: user.username,
    role: user.role,
    displayName: user.displayName,
  });
});

router.post("/login", async (req: Request, res: Response) => {
  const { username, password } = req.body;

  if (!username || !password) {
    res.status(400).json({ error: "Username and password required" });
    return;
  }

  const [user] = await db
    .select()
    .from(usersTable)
    .where(sql`lower(${usersTable.username}) = lower(${username})`);

  if (!user) {
    res.status(401).json({ error: "Invalid username or password" });
    return;
  }

  if (!user.isActive) {
    res.status(401).json({ error: "Account is disabled" });
    return;
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    res.status(401).json({ error: "Invalid username or password" });
    return;
  }

  if (user.sessionToken && user.role !== "owner") {
    res.status(409).json({ error: "You are already logged in on another device. Please log out there first, or ask the admin to kick your session." });
    return;
  }

  const sessionToken = randomUUID();

  await db
    .update(usersTable)
    .set({ sessionToken, lastLoginAt: new Date() })
    .where(eq(usersTable.id, user.id));

  req.session.userId = user.id;
  req.session.sessionToken = sessionToken;

  res.json({
    id: user.id,
    username: user.username,
    role: user.role,
    displayName: user.displayName,
  });
});

router.post("/logout", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;

  await db
    .update(usersTable)
    .set({ sessionToken: null })
    .where(eq(usersTable.id, user.id));

  req.session.destroy(() => {});
  res.json({ success: true, message: "Logged out" });
});

router.get("/me", requireAuth, (req: Request, res: Response) => {
  const user = (req as any).user;
  res.json({
    id: user.id,
    username: user.username,
    role: user.role,
    displayName: user.displayName,
  });
});

export default router;
