import { Router, type Request, type Response } from "express";
import { db, messagesTable, usersTable, notificationsTable } from "@workspace/db";
import { eq, and, or, desc, sql, isNull } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router = Router();

router.get("/conversations", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;

  const rows = await db
    .select()
    .from(messagesTable)
    .where(or(eq(messagesTable.senderId, user.id), eq(messagesTable.recipientId, user.id)))
    .orderBy(desc(messagesTable.createdAt));

  const seenUserIds = new Set<number>();
  const conversations: {
    userId: number;
    username: string;
    displayName: string | null;
    lastMessage: string;
    lastAt: Date;
    unread: number;
  }[] = [];

  for (const msg of rows) {
    const otherId = msg.senderId === user.id ? msg.recipientId : msg.senderId;
    if (seenUserIds.has(otherId)) continue;
    seenUserIds.add(otherId);

    const [other] = await db.select().from(usersTable).where(eq(usersTable.id, otherId));
    if (!other) continue;

    const [{ unread }] = await db
      .select({ unread: sql<number>`count(*)::int` })
      .from(messagesTable)
      .where(
        and(
          eq(messagesTable.senderId, otherId),
          eq(messagesTable.recipientId, user.id),
          sql`${messagesTable.readAt} is null`
        )
      );

    conversations.push({
      userId: other.id,
      username: other.username,
      displayName: other.displayName,
      lastMessage: msg.content,
      lastAt: msg.createdAt,
      unread: unread ?? 0,
    });
  }

  res.json(conversations);
});

router.get("/:userId", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;
  const otherId = parseInt(req.params.userId);

  const msgs = await db
    .select()
    .from(messagesTable)
    .where(
      or(
        and(eq(messagesTable.senderId, user.id), eq(messagesTable.recipientId, otherId)),
        and(eq(messagesTable.senderId, otherId), eq(messagesTable.recipientId, user.id))
      )
    )
    .orderBy(messagesTable.createdAt);

  await db
    .update(messagesTable)
    .set({ readAt: new Date() })
    .where(
      and(
        eq(messagesTable.senderId, otherId),
        eq(messagesTable.recipientId, user.id),
        sql`${messagesTable.readAt} is null`
      )
    );

  // Mark message notifications from this sender as read
  await db
    .update(notificationsTable)
    .set({ readAt: new Date() })
    .where(
      and(
        eq(notificationsTable.userId, user.id),
        eq(notificationsTable.actorId, otherId),
        eq(notificationsTable.type, "message"),
        isNull(notificationsTable.readAt)
      )
    );

  res.json(
    msgs.map((m) => ({
      id: m.id,
      senderId: m.senderId,
      recipientId: m.recipientId,
      content: m.content,
      readAt: m.readAt,
      createdAt: m.createdAt,
    }))
  );
});

router.post("/", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;
  const { recipientId, content } = req.body;

  if (!recipientId || !content?.trim()) {
    res.status(400).json({ error: "recipientId and content are required" });
    return;
  }

  const [recipient] = await db.select().from(usersTable).where(eq(usersTable.id, recipientId));
  if (!recipient) {
    res.status(404).json({ error: "Recipient not found" });
    return;
  }

  const [msg] = await db
    .insert(messagesTable)
    .values({ senderId: user.id, recipientId, content: content.trim() })
    .returning();

  // Fire a notification for the recipient
  await db.insert(notificationsTable).values({
    userId: recipientId,
    actorId: user.id,
    type: "message",
    message: `${user.displayName ?? user.username} sent you a message`,
  });

  res.status(201).json({
    id: msg.id,
    senderId: msg.senderId,
    recipientId: msg.recipientId,
    content: msg.content,
    readAt: msg.readAt,
    createdAt: msg.createdAt,
  });
});

export default router;
