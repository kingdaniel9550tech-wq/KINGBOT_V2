import { Router, type Request, type Response } from "express";
import { db, notificationsTable, usersTable } from "@workspace/db";
import { eq, desc, sql, and } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router = Router();

router.get("/", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;

  const rows = await db
    .select()
    .from(notificationsTable)
    .where(eq(notificationsTable.userId, user.id))
    .orderBy(desc(notificationsTable.createdAt))
    .limit(50);

  const result = await Promise.all(
    rows.map(async (n) => {
      const [actor] = await db.select().from(usersTable).where(eq(usersTable.id, n.actorId));
      return {
        id: n.id,
        type: n.type,
        message: n.message,
        postId: n.postId,
        actorId: n.actorId,
        actorName: actor?.displayName ?? actor?.username ?? "Someone",
        readAt: n.readAt,
        createdAt: n.createdAt,
      };
    })
  );

  res.json(result);
});

router.get("/unread-count", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;
  const [row] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(notificationsTable)
    .where(and(eq(notificationsTable.userId, user.id), sql`${notificationsTable.readAt} is null`));
  res.json({ count: row?.count ?? 0 });
});

router.post("/read-all", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;
  await db
    .update(notificationsTable)
    .set({ readAt: new Date() })
    .where(and(eq(notificationsTable.userId, user.id), sql`${notificationsTable.readAt} is null`));
  res.json({ success: true });
});

router.post("/:id/read", requireAuth, async (req: Request, res: Response) => {
  const user = (req as any).user;
  const id = parseInt(req.params.id as string);
  await db
    .update(notificationsTable)
    .set({ readAt: new Date() })
    .where(and(eq(notificationsTable.id, id), eq(notificationsTable.userId, user.id)));
  res.json({ success: true });
});

export default router;
