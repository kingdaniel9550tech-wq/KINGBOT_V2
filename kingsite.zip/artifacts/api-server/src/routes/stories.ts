import { Router, type Request, type Response } from "express";
import { db, storiesTable, usersTable } from "@workspace/db";
import { eq, desc, gt } from "drizzle-orm";
import { requireAuth, requireRole } from "../middlewares/auth";

const router = Router();

router.get("/", requireAuth, async (req: Request, res: Response) => {
  const now = new Date();
  const stories = await db
    .select()
    .from(storiesTable)
    .where(gt(storiesTable.expiresAt, now))
    .orderBy(desc(storiesTable.createdAt));

  const result = await Promise.all(
    stories.map(async (s) => {
      const [author] = await db.select().from(usersTable).where(eq(usersTable.id, s.authorId));
      return {
        id: s.id,
        authorId: s.authorId,
        authorName: author?.displayName ?? author?.username ?? "Unknown",
        mediaUrl: s.mediaUrl,
        mediaType: s.mediaType,
        expiresAt: s.expiresAt,
        createdAt: s.createdAt,
      };
    })
  );

  res.json(result);
});

router.post("/", requireAuth, requireRole("owner", "admin"), async (req: Request, res: Response) => {
  const user = (req as any).user;
  const { mediaUrl, mediaType } = req.body;

  if (!mediaUrl || !mediaType) {
    res.status(400).json({ error: "mediaUrl and mediaType are required" });
    return;
  }

  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

  const [story] = await db
    .insert(storiesTable)
    .values({ authorId: user.id, mediaUrl, mediaType, expiresAt })
    .returning();

  const [author] = await db.select().from(usersTable).where(eq(usersTable.id, user.id));

  res.status(201).json({
    id: story.id,
    authorId: story.authorId,
    authorName: author?.displayName ?? author?.username ?? "Unknown",
    mediaUrl: story.mediaUrl,
    mediaType: story.mediaType,
    expiresAt: story.expiresAt,
    createdAt: story.createdAt,
  });
});

router.delete("/:storyId", requireAuth, requireRole("owner", "admin"), async (req: Request, res: Response) => {
  const user = (req as any).user;
  const storyId = parseInt(req.params.storyId as string);

  const [story] = await db.select().from(storiesTable).where(eq(storiesTable.id, storyId));
  if (!story) {
    res.status(404).json({ error: "Story not found" });
    return;
  }

  if (user.role !== "owner" && story.authorId !== user.id) {
    res.status(403).json({ error: "Cannot delete someone else's story" });
    return;
  }

  await db.delete(storiesTable).where(eq(storiesTable.id, storyId));
  res.json({ success: true });
});

export default router;
