import { db, usersTable } from "@workspace/db";
import { sql } from "drizzle-orm";
import { logger } from "./lib/logger";

const OWNER_PASSWORD_HASH = "$2b$10$/ODo0qSd8mFtsjDDqE4LBej5pAl.FqkLNRHCRBTQvujGTyBI2ttGK";

export async function seedOwner() {
  try {
    const [existing] = await db
      .select()
      .from(usersTable)
      .where(sql`lower(${usersTable.username}) = 'owner'`);

    if (!existing) {
      await db.insert(usersTable).values({
        username: "owner",
        passwordHash: OWNER_PASSWORD_HASH,
        role: "owner",
        displayName: "The King",
        isActive: true,
      });
      logger.info("Owner account created");
    } else {
      await db.execute(
        sql`UPDATE users SET password_hash = ${OWNER_PASSWORD_HASH}, role = 'owner', is_active = true, session_token = NULL WHERE lower(username) = 'owner'`
      );
      logger.info("Owner account refreshed");
    }
  } catch (err) {
    logger.error({ err }, "Failed to seed owner account");
  }
}
