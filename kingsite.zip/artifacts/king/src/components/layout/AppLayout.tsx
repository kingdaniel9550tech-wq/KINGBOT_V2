import { useGetMe, useListPages, useLogout, getGetMeQueryKey, getListPagesQueryKey } from "@workspace/api-client-react";
import { Link, useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { LogOut, Home, PlusSquare, Users, Layers, Key, BarChart3, Menu, X, MessageCircle, UserCircle } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { NotificationBell } from "@/components/NotificationBell";

export function AppLayout({ children }: { children: React.ReactNode }) {
  const { data: user } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const { data: pages } = useListPages({ query: { queryKey: getListPagesQueryKey(), enabled: !!user } });
  const logoutMut = useLogout();
  const queryClient = useQueryClient();
  const [location, setLocation] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logoutMut.mutate(undefined, {
      onSuccess: () => {
        queryClient.clear();
        setLocation("/");
      }
    });
  };

  const isOwner = user?.role === 'owner';
  const isAdmin = user?.role === 'admin' || isOwner;

  const NavLinks = () => (
    <>
      <div className="mb-8">
        <Link href="/feed" className="flex items-center space-x-2 text-2xl font-serif font-bold text-primary tracking-widest uppercase">
          <span>👑KING👑</span>
        </Link>
      </div>

      <div className="space-y-6 flex-1">
        <div>
          <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Discover</h4>
          <nav className="space-y-1">
            <Link href="/feed" className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${location === '/feed' ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-white/5 hover:text-primary'}`}>
              <Home size={18} />
              <span className="font-medium">Global Feed</span>
            </Link>
            <Link href="/messages" className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${location === '/messages' ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-white/5 hover:text-primary'}`}>
              <MessageCircle size={18} />
              <span className="font-medium">Messages</span>
            </Link>
            <Link href="/people" className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${location === '/people' ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-white/5 hover:text-primary'}`}>
              <Users size={18} />
              <span className="font-medium">Members</span>
            </Link>
          </nav>
        </div>

        {pages && pages.length > 0 && (
          <div>
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Your Pages</h4>
            <nav className="space-y-1">
              {pages.map((p) => (
                <Link key={p.id} href={`/page/${p.slug}`} className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${location === `/page/${p.slug}` ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-white/5 hover:text-primary'}`}>
                  <span className="text-primary/70 text-lg leading-none mt-1">•</span>
                  <span className="font-medium">{p.name}</span>
                </Link>
              ))}
            </nav>
          </div>
        )}

        <div>
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Creator</h4>
            <nav className="space-y-1">
              <Link href="/create" className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${location === '/create' ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-white/5 hover:text-primary'}`}>
                <PlusSquare size={18} />
                <span className="font-medium">Create Post</span>
              </Link>
            </nav>
          </div>

        {isOwner && (
          <div>
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Admin</h4>
            <nav className="space-y-1">
              <Link href="/admin/users" className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${location === '/admin/users' ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-white/5 hover:text-primary'}`}>
                <Users size={18} />
                <span className="font-medium">Users</span>
              </Link>
              <Link href="/admin/pages" className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${location === '/admin/pages' ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-white/5 hover:text-primary'}`}>
                <Layers size={18} />
                <span className="font-medium">Pages</span>
              </Link>
              <Link href="/admin/access" className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${location === '/admin/access' ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-white/5 hover:text-primary'}`}>
                <Key size={18} />
                <span className="font-medium">Access</span>
              </Link>
              <Link href="/admin/stats" className={`flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${location === '/admin/stats' ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-white/5 hover:text-primary'}`}>
                <BarChart3 size={18} />
                <span className="font-medium">Stats</span>
              </Link>
            </nav>
          </div>
        )}
      </div>

      <div className="mt-auto pt-6 border-t border-border space-y-1">
        <Link href="/profile" className="flex items-center gap-3 px-3 py-2 rounded-md transition-colors hover:bg-white/5 hover:text-primary w-full">
          <Avatar className="h-8 w-8 border border-primary/20 flex-shrink-0">
            {(user as any)?.avatarUrl && <AvatarImage src={(user as any).avatarUrl} alt={user?.displayName ?? user?.username ?? ""} />}
            <AvatarFallback className="bg-primary/20 text-primary text-xs font-bold">
              {(user?.displayName || user?.username || "?")[0]?.toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex flex-col min-w-0">
            <span className="font-semibold text-sm truncate">{user?.displayName || user?.username}</span>
            <span className="text-xs text-primary capitalize">{user?.role}</span>
          </div>
        </Link>
        <button
          onClick={handleLogout}
          className="flex w-full items-center space-x-3 px-3 py-2 rounded-md transition-colors text-muted-foreground hover:bg-white/5 hover:text-destructive"
        >
          <LogOut size={18} />
          <span className="font-medium">Sign out</span>
        </button>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col md:flex-row">
      {/* Mobile Nav Header */}
      <div className="md:hidden flex items-center justify-between p-4 border-b border-border bg-card">
        <Link href="/feed" className="text-xl font-serif font-bold text-primary tracking-widest uppercase">
          👑KING👑
        </Link>
        <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 top-[73px] z-50 bg-background/95 backdrop-blur-sm p-4 overflow-y-auto border-b border-border">
          <div className="flex flex-col min-h-[calc(100vh-100px)]">
            <NavLinks />
          </div>
        </div>
      )}

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-r border-border bg-card p-6 h-screen sticky top-0">
        <NavLinks />
      </aside>

      {/* Main Content */}
      <main className="flex-1 min-w-0 flex flex-col min-h-screen">
        <div className="flex-1 max-w-5xl w-full mx-auto p-4 md:p-8 w-full">
          {children}
        </div>
      </main>
    </div>
  );
}
