import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { useEffect } from "react";

export function ProtectedRoute({ children, requireAdmin, requireOwner }: { children: React.ReactNode, requireAdmin?: boolean, requireOwner?: boolean }) {
  const { data: user, isLoading, error } = useGetMe({ query: { queryKey: getGetMeQueryKey(), retry: false } });
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && error) {
      setLocation("/");
    }
  }, [isLoading, error, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background text-primary">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) return null;

  if (requireOwner && user.role !== 'owner') {
    setLocation("/feed");
    return null;
  }

  if (requireAdmin && user.role !== 'admin' && user.role !== 'owner') {
    setLocation("/feed");
    return null;
  }

  return <>{children}</>;
}
