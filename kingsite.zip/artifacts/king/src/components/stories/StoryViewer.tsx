import { useEffect, useState } from "react";
import { X, ChevronLeft, ChevronRight, Trash2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export interface StoryItem {
  id: number;
  authorId: number;
  authorName: string;
  mediaUrl: string;
  mediaType: string;
  expiresAt: string;
  createdAt: string;
}

interface Props {
  stories: StoryItem[];
  startIndex: number;
  currentUserId?: number;
  currentUserRole?: string;
  onClose: () => void;
  onDelete?: (id: number) => void;
}

export function StoryViewer({ stories, startIndex, currentUserId, currentUserRole, onClose, onDelete }: Props) {
  const [index, setIndex] = useState(startIndex);
  const [progress, setProgress] = useState(0);

  const story = stories[index];

  useEffect(() => {
    setProgress(0);
    const interval = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(interval);
          if (index < stories.length - 1) {
            setIndex((i) => i + 1);
          } else {
            onClose();
          }
          return 0;
        }
        return p + 2;
      });
    }, 100);
    return () => clearInterval(interval);
  }, [index]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") setIndex((i) => Math.min(i + 1, stories.length - 1));
      if (e.key === "ArrowLeft") setIndex((i) => Math.max(i - 1, 0));
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  if (!story) return null;

  const canDelete =
    currentUserRole === "owner" ||
    (currentUserRole === "admin" && story.authorId === currentUserId);

  return (
    <div
      className="fixed inset-0 z-50 bg-black flex items-center justify-center"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-sm h-full max-h-[700px] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Progress bars */}
        <div className="absolute top-0 left-0 right-0 z-10 flex gap-1 p-2">
          {stories.map((_, i) => (
            <div key={i} className="flex-1 h-0.5 bg-white/30 rounded-full overflow-hidden">
              <div
                className="h-full bg-white rounded-full transition-none"
                style={{ width: i < index ? "100%" : i === index ? `${progress}%` : "0%" }}
              />
            </div>
          ))}
        </div>

        {/* Header */}
        <div className="absolute top-4 left-0 right-0 z-10 flex items-center justify-between px-4 mt-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary/30 border border-primary flex items-center justify-center text-xs font-bold text-primary">
              {story.authorName[0]?.toUpperCase()}
            </div>
            <span className="text-white text-sm font-semibold drop-shadow">{story.authorName}</span>
          </div>
          <div className="flex items-center gap-2">
            {canDelete && onDelete && (
              <button
                onClick={() => { onDelete(story.id); onClose(); }}
                className="p-1 rounded-full bg-black/30 text-white hover:bg-red-500/70"
              >
                <Trash2 size={16} />
              </button>
            )}
            <button onClick={onClose} className="p-1 rounded-full bg-black/30 text-white hover:bg-white/20">
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Media */}
        <AnimatePresence mode="wait">
          <motion.div
            key={story.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="w-full h-full flex items-center justify-center bg-black rounded-lg overflow-hidden"
          >
            {story.mediaType === "video" ? (
              <video
                src={story.mediaUrl}
                autoPlay
                muted
                playsInline
                className="w-full h-full object-contain"
                onContextMenu={(e) => e.preventDefault()}
              />
            ) : (
              <img
                src={story.mediaUrl}
                className="w-full h-full object-contain select-none"
                draggable={false}
                onContextMenu={(e) => e.preventDefault()}
              />
            )}
          </motion.div>
        </AnimatePresence>

        {/* Tap zones */}
        {index > 0 && (
          <button
            onClick={() => setIndex((i) => i - 1)}
            className="absolute left-0 top-0 bottom-0 w-1/4 flex items-center justify-start pl-2 opacity-0 hover:opacity-100 transition-opacity"
          >
            <ChevronLeft className="text-white" size={28} />
          </button>
        )}
        {index < stories.length - 1 && (
          <button
            onClick={() => setIndex((i) => i + 1)}
            className="absolute right-0 top-0 bottom-0 w-1/4 flex items-center justify-end pr-2 opacity-0 hover:opacity-100 transition-opacity"
          >
            <ChevronRight className="text-white" size={28} />
          </button>
        )}
      </div>
    </div>
  );
}
