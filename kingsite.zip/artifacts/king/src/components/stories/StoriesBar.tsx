import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { api } from "@/lib/api";
import { StoryViewer, type StoryItem } from "./StoryViewer";
import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";

export function StoriesBar() {
  const { data: user } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const qc = useQueryClient();
  const [viewerOpen, setViewerOpen] = useState(false);
  const [viewerStart, setViewerStart] = useState(0);
  const [uploading, setUploading] = useState(false);

  const { data: stories = [] } = useQuery<StoryItem[]>({
    queryKey: ["stories"],
    queryFn: () => api.get<StoryItem[]>("/stories"),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => api.delete(`/stories/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["stories"] }),
  });

  const isAdmin = user?.role === "admin" || user?.role === "owner";

  const handleAddStory = async () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*,video/*";
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      setUploading(true);
      try {
        const form = new FormData();
        form.append("file", file);
        const uploadRes = await fetch("/api/uploads", {
          method: "POST",
          credentials: "include",
          body: form,
        });
        if (!uploadRes.ok) throw new Error("Upload failed");
        const { url } = await uploadRes.json();
        const mediaType = file.type.startsWith("video") ? "video" : "image";
        await api.post("/stories", { mediaUrl: url, mediaType });
        qc.invalidateQueries({ queryKey: ["stories"] });
      } catch (err) {
        console.error(err);
      } finally {
        setUploading(false);
      }
    };
    input.click();
  };

  if (!isAdmin && stories.length === 0) return null;

  return (
    <>
      <div className="flex items-center gap-3 pb-4 overflow-x-auto no-scrollbar">
        {isAdmin && (
          <button
            onClick={handleAddStory}
            disabled={uploading}
            className="flex-shrink-0 flex flex-col items-center gap-1"
          >
            <div className="w-14 h-14 rounded-full border-2 border-dashed border-primary/50 flex items-center justify-center bg-card hover:border-primary transition-colors">
              {uploading ? (
                <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              ) : (
                <Plus size={20} className="text-primary" />
              )}
            </div>
            <span className="text-[10px] text-muted-foreground">Add Story</span>
          </button>
        )}

        {stories.map((story, i) => (
          <button
            key={story.id}
            onClick={() => { setViewerStart(i); setViewerOpen(true); }}
            className="flex-shrink-0 flex flex-col items-center gap-1"
          >
            <div className="w-14 h-14 rounded-full border-2 border-primary p-0.5 bg-black overflow-hidden hover:border-yellow-300 transition-colors">
              {story.mediaType === "video" ? (
                <div className="w-full h-full rounded-full bg-primary/20 flex items-center justify-center">
                  <span className="text-primary text-lg">▶</span>
                </div>
              ) : (
                <img
                  src={story.mediaUrl}
                  className="w-full h-full rounded-full object-cover select-none"
                  draggable={false}
                  onContextMenu={(e) => e.preventDefault()}
                />
              )}
            </div>
            <span className="text-[10px] text-muted-foreground max-w-[56px] truncate">{story.authorName}</span>
          </button>
        ))}
      </div>

      {viewerOpen && stories.length > 0 && (
        <StoryViewer
          stories={stories}
          startIndex={viewerStart}
          currentUserId={user?.id}
          currentUserRole={user?.role}
          onClose={() => setViewerOpen(false)}
          onDelete={(id) => deleteMutation.mutate(id)}
        />
      )}
    </>
  );
}
