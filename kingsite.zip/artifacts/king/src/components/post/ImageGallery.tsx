import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Watermark } from "./Watermark";

interface Props {
  images: string[];
  username?: string;
}

export function ImageGallery({ images, username }: Props) {
  const [current, setCurrent] = useState(0);

  if (!images || images.length === 0) return null;

  if (images.length === 1) {
    return (
      <div className="media-protected w-full bg-black/50 max-h-[600px] flex items-center justify-center overflow-hidden border-y border-border">
        <img
          src={images[0]}
          alt="Post image"
          className="max-w-full max-h-[600px] object-contain select-none"
          onContextMenu={(e) => e.preventDefault()}
          draggable={false}
        />
        <Watermark username={username} />
      </div>
    );
  }

  return (
    <div className="media-protected w-full bg-black/50 max-h-[600px] flex items-center justify-center overflow-hidden border-y border-border">
      <img
        src={images[current]}
        alt={`Image ${current + 1}`}
        className="max-w-full max-h-[600px] object-contain select-none"
        onContextMenu={(e) => e.preventDefault()}
        draggable={false}
      />
      <Watermark username={username} />

      {current > 0 && (
        <button
          onClick={() => setCurrent((c) => c - 1)}
          className="absolute left-2 top-1/2 -translate-y-1/2 z-20 bg-black/60 hover:bg-black/80 text-white rounded-full p-1 transition-colors"
        >
          <ChevronLeft size={20} />
        </button>
      )}
      {current < images.length - 1 && (
        <button
          onClick={() => setCurrent((c) => c + 1)}
          className="absolute right-2 top-1/2 -translate-y-1/2 z-20 bg-black/60 hover:bg-black/80 text-white rounded-full p-1 transition-colors"
        >
          <ChevronRight size={20} />
        </button>
      )}

      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 z-20 flex gap-1.5">
        {images.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            className={`w-1.5 h-1.5 rounded-full transition-colors ${i === current ? "bg-white" : "bg-white/40"}`}
          />
        ))}
      </div>
    </div>
  );
}
