export function Watermark({ username }: { username?: string }) {
  if (!username) return null;
  const tiles = Array.from({ length: 24 }, (_, i) => i);
  return (
    <div
      aria-hidden
      style={{
        position: "absolute",
        inset: 0,
        zIndex: 11,
        pointerEvents: "none",
        overflow: "hidden",
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gridTemplateRows: "repeat(6, 1fr)",
        userSelect: "none",
      }}
    >
      {tiles.map((i) => (
        <span
          key={i}
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "11px",
            fontWeight: 600,
            color: "rgba(255,255,255,0.13)",
            transform: "rotate(-30deg)",
            whiteSpace: "nowrap",
            letterSpacing: "0.05em",
            textTransform: "uppercase",
          }}
        >
          {username}
        </span>
      ))}
    </div>
  );
}
