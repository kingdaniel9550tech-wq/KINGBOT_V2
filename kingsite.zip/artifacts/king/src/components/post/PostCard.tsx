import { formatDistanceToNow } from "date-fns";
import { Heart, MessageSquare, Trash2, FileText, Download, BadgeCheck } from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  useToggleLike,
  useListComments,
  useCreateComment,
  useDeletePost,
  getGetMeQueryKey,
  useGetMe,
  Post,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Watermark } from "./Watermark";
import { ImageGallery } from "./ImageGallery";

type Doc = { url: string; name: string; type: string };
type PostWithExtras = Post & { images?: string[]; documents?: Doc[]; authorAvatarUrl?: string | null; authorIsVerified?: boolean };

function DocAttachment({ doc }: { doc: Doc }) {
  const ext = doc.name?.split(".").pop()?.toUpperCase() ?? "FILE";
  return (
    <a
      href={doc.url}
      download={doc.name}
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center gap-3 px-4 py-3 bg-background border border-border rounded-lg hover:border-primary/40 hover:bg-primary/5 transition-colors group"
    >
      <div className="w-9 h-9 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
        <FileText size={16} className="text-primary" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-foreground truncate">{doc.name || "Document"}</p>
        <p className="text-[11px] text-muted-foreground">{ext} · Click to download</p>
      </div>
      <Download size={14} className="text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" />
    </a>
  );
}

export function PostCard({ post, onDeleted }: { post: PostWithExtras; onDeleted?: () => void }) {
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState("");
  const [optimisticLike, setOptimisticLike] = useState({ isLiked: post.isLikedByMe, count: post.likeCount });

  const { data: user } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const toggleLike = useToggleLike();
  const deletePost = useDeletePost();
  const createComment = useCreateComment();
  const queryClient = useQueryClient();

  const { data: comments, isLoading: commentsLoading } = useListComments(post.id, {
    query: { enabled: showComments },
  });

  const handleLike = () => {
    const newIsLiked = !optimisticLike.isLiked;
    setOptimisticLike({ isLiked: newIsLiked, count: optimisticLike.count + (newIsLiked ? 1 : -1) });
    toggleLike.mutate({ postId: post.id }, {
      onError: () => setOptimisticLike({ isLiked: post.isLikedByMe, count: post.likeCount }),
    });
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    createComment.mutate({ postId: post.id, data: { content: newComment } }, {
      onSuccess: () => {
        setNewComment("");
        queryClient.invalidateQueries({ queryKey: ["comments", post.id] });
      },
    });
  };

  const handleDelete = () => {
    if (confirm("Are you sure you want to delete this post?")) {
      deletePost.mutate({ postId: post.id }, { onSuccess: () => onDeleted?.() });
    }
  };

  // Any user can delete their own post; owner can delete any post
  const canDelete = user?.role === "owner" || post.authorId === user?.id;
  const dateStr = post.createdAt ? formatDistanceToNow(new Date(post.createdAt), { addSuffix: true }) : "";
  const watermarkName = user?.displayName ?? user?.username;

  const galleryImages = post.images && post.images.length > 0 ? post.images : post.imageUrl ? [post.imageUrl] : [];
  const docs: Doc[] = post.documents ?? [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border rounded-lg overflow-hidden shadow-md"
    >
      {/* Header */}
      <div className="p-4 flex items-start justify-between">
        <div className="flex items-center space-x-3">
          <Avatar className="h-10 w-10 border border-primary/20">
            {post.authorAvatarUrl && <AvatarImage src={post.authorAvatarUrl} alt={post.authorName ?? ""} />}
            <AvatarFallback className="bg-background text-primary font-serif font-bold">
              {post.authorName?.charAt(0)?.toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="font-semibold text-foreground">{post.authorName}</span>
              {post.authorIsVerified && (
                <BadgeCheck size={15} className="text-primary fill-primary/20" title="Verified" />
              )}
              {post.pageName && (
                <Badge variant="outline" className="bg-primary/5 text-primary border-primary/20 text-[10px] px-1.5 uppercase tracking-wider ml-1">
                  {post.pageName}
                </Badge>
              )}
            </div>
            <span className="text-xs text-muted-foreground">{dateStr}</span>
          </div>
        </div>

        {canDelete && (
          <button
            onClick={handleDelete}
            className="text-muted-foreground hover:text-destructive transition-colors p-1"
            title="Delete post"
          >
            <Trash2 size={15} />
          </button>
        )}
      </div>

      {/* Content */}
      {post.content && (
        <div className="px-4 pb-3">
          <p className="text-foreground/90 whitespace-pre-wrap leading-relaxed">{post.content}</p>
        </div>
      )}

      {/* Images */}
      {galleryImages.length > 0 && (
        <div className="relative">
          <ImageGallery images={galleryImages} />
          {watermarkName && <Watermark name={watermarkName} />}
        </div>
      )}

      {/* Video */}
      {post.videoUrl && (
        <div className="relative bg-black">
          <video controls className="w-full max-h-96" src={post.videoUrl} />
          {watermarkName && <Watermark name={watermarkName} />}
        </div>
      )}

      {/* Documents */}
      {docs.length > 0 && (
        <div className="px-4 pb-3 space-y-2">
          {docs.map((doc, i) => <DocAttachment key={i} doc={doc} />)}
        </div>
      )}

      {/* Actions */}
      <div className="px-4 py-3 border-t border-border flex items-center space-x-4">
        <button
          onClick={handleLike}
          className={`flex items-center space-x-1.5 transition-colors ${optimisticLike.isLiked ? "text-red-500" : "text-muted-foreground hover:text-red-500"}`}
        >
          <Heart size={16} className={optimisticLike.isLiked ? "fill-current" : ""} />
          <span className="text-sm">{optimisticLike.count}</span>
        </button>
        <button
          onClick={() => setShowComments(!showComments)}
          className="flex items-center space-x-1.5 text-muted-foreground hover:text-foreground transition-colors"
        >
          <MessageSquare size={16} />
          <span className="text-sm">{post.commentCount ?? 0}</span>
        </button>
      </div>

      {/* Comments */}
      <AnimatePresence>
        {showComments && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t border-border bg-background/50 overflow-hidden"
          >
            <div className="p-4 space-y-4">
              {commentsLoading ? (
                <div className="flex justify-center py-4">
                  <div className="animate-spin h-5 w-5 border-b-2 border-primary rounded-full" />
                </div>
              ) : comments && comments.length > 0 ? (
                <div className="space-y-4">
                  {comments.map((comment: any) => (
                    <div key={comment.id} className="flex space-x-3 text-sm">
                      <Avatar className="h-8 w-8 border border-border">
                        {comment.authorAvatarUrl && <AvatarImage src={comment.authorAvatarUrl} />}
                        <AvatarFallback className="bg-card text-xs">{comment.authorName?.charAt(0)?.toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div className="bg-card border border-border rounded-lg px-3 py-2 flex-1">
                        <div className="flex justify-between items-baseline mb-1">
                          <span className="font-semibold flex items-center gap-1">
                            {comment.authorName}
                            {comment.authorIsVerified && <BadgeCheck size={12} className="text-primary fill-primary/20" />}
                          </span>
                          <span className="text-[10px] text-muted-foreground">
                            {comment.createdAt ? formatDistanceToNow(new Date(comment.createdAt)) : ""}
                          </span>
                        </div>
                        <p className="text-foreground/90">{comment.content}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-2">No comments yet. Be the first.</p>
              )}

              <form onSubmit={handleAddComment} className="flex items-center space-x-2 pt-2">
                <Input
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Write a comment..."
                  className="bg-card h-9 border-border"
                />
                <Button type="submit" size="sm" disabled={createComment.isPending || !newComment.trim()}>
                  Post
                </Button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
