import { useState } from "react";
import { useLogin, getGetMeQueryKey } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

const BASE_URL = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

export default function Login() {
  const [mode, setMode] = useState<"login" | "register">("login");

  // Login state
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  // Register state
  const [regUsername, setRegUsername] = useState("");
  const [regDisplayName, setRegDisplayName] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regConfirm, setRegConfirm] = useState("");
  const [regLoading, setRegLoading] = useState(false);

  const login = useLogin();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) return;

    login.mutate(
      { data: { username, password } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
          setLocation("/feed");
        },
        onError: (error: any) => {
          if (error?.status === 409) {
            toast({
              title: "Session Active",
              description: "You are already logged in on another device. Please log out there first.",
              variant: "destructive",
            });
          } else {
            toast({
              title: "Access Denied",
              description: "Invalid credentials or your account is deactivated.",
              variant: "destructive",
            });
          }
        },
      }
    );
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regUsername || !regPassword || !regConfirm) return;

    if (regPassword !== regConfirm) {
      toast({ title: "Passwords don't match", variant: "destructive" });
      return;
    }

    setRegLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          username: regUsername,
          password: regPassword,
          displayName: regDisplayName || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Registration failed", description: data.error, variant: "destructive" });
        return;
      }
      queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
      setLocation("/feed");
    } catch {
      toast({ title: "Registration failed", description: "Something went wrong.", variant: "destructive" });
    } finally {
      setRegLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle at center, hsl(var(--primary)) 0%, transparent 50%)', backgroundSize: '100% 100%' }} />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="w-full max-w-md"
      >
        <div className="bg-card border border-border rounded-lg shadow-2xl p-8 md:p-12 relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-50" />

          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-serif font-bold text-primary tracking-widest uppercase mb-2">
              👑KING👑
            </h1>
            <p className="text-muted-foreground text-sm uppercase tracking-[0.2em] font-medium">
              {mode === "login" ? "Private Access Only" : "Create Your Account"}
            </p>
          </div>

          {/* Mode toggle */}
          <div className="flex rounded-md border border-border overflow-hidden mb-8">
            <button
              type="button"
              onClick={() => setMode("login")}
              className={`flex-1 py-2 text-xs font-bold uppercase tracking-widest transition-colors ${
                mode === "login"
                  ? "bg-primary text-primary-foreground"
                  : "bg-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => setMode("register")}
              className={`flex-1 py-2 text-xs font-bold uppercase tracking-widest transition-colors ${
                mode === "register"
                  ? "bg-primary text-primary-foreground"
                  : "bg-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              Register
            </button>
          </div>

          <AnimatePresence mode="wait">
            {mode === "login" ? (
              <motion.form
                key="login"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.2 }}
                onSubmit={handleLogin}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <Label htmlFor="username" className="uppercase tracking-wider text-xs font-semibold text-muted-foreground">Username</Label>
                  <Input
                    id="username"
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="bg-background border-border focus-visible:ring-primary h-12"
                    placeholder="Enter your username"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="uppercase tracking-wider text-xs font-semibold text-muted-foreground">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="bg-background border-border focus-visible:ring-primary h-12"
                    placeholder="Enter your password"
                    required
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full h-12 text-sm font-bold tracking-widest uppercase mt-4 shadow-[0_0_15px_rgba(201,168,76,0.15)] hover:shadow-[0_0_25px_rgba(201,168,76,0.3)] transition-all"
                  disabled={login.isPending}
                >
                  {login.isPending ? "Authenticating..." : "Enter"}
                </Button>
              </motion.form>
            ) : (
              <motion.form
                key="register"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
                onSubmit={handleRegister}
                className="space-y-5"
              >
                <div className="space-y-2">
                  <Label htmlFor="reg-username" className="uppercase tracking-wider text-xs font-semibold text-muted-foreground">Username</Label>
                  <Input
                    id="reg-username"
                    type="text"
                    value={regUsername}
                    onChange={(e) => setRegUsername(e.target.value)}
                    className="bg-background border-border focus-visible:ring-primary h-12"
                    placeholder="Letters, numbers, underscores"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reg-display" className="uppercase tracking-wider text-xs font-semibold text-muted-foreground">
                    Display Name <span className="normal-case font-normal text-muted-foreground/60">(optional)</span>
                  </Label>
                  <Input
                    id="reg-display"
                    type="text"
                    value={regDisplayName}
                    onChange={(e) => setRegDisplayName(e.target.value)}
                    className="bg-background border-border focus-visible:ring-primary h-12"
                    placeholder="How others see you"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reg-password" className="uppercase tracking-wider text-xs font-semibold text-muted-foreground">Password</Label>
                  <Input
                    id="reg-password"
                    type="password"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="bg-background border-border focus-visible:ring-primary h-12"
                    placeholder="At least 6 characters"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reg-confirm" className="uppercase tracking-wider text-xs font-semibold text-muted-foreground">Confirm Password</Label>
                  <Input
                    id="reg-confirm"
                    type="password"
                    value={regConfirm}
                    onChange={(e) => setRegConfirm(e.target.value)}
                    className="bg-background border-border focus-visible:ring-primary h-12"
                    placeholder="Repeat your password"
                    required
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full h-12 text-sm font-bold tracking-widest uppercase mt-2 shadow-[0_0_15px_rgba(201,168,76,0.15)] hover:shadow-[0_0_25px_rgba(201,168,76,0.3)] transition-all"
                  disabled={regLoading}
                >
                  {regLoading ? "Creating Account..." : "Join"}
                </Button>
              </motion.form>
            )}
          </AnimatePresence>
        </div>

        <div className="mt-8 text-center">
          <p className="text-xs text-muted-foreground/60 uppercase tracking-widest">
            {mode === "login" ? "New here? Switch to Register above" : "Already have an account? Switch to Sign In above"}
          </p>
        </div>
      </motion.div>
    </div>
  );
}
