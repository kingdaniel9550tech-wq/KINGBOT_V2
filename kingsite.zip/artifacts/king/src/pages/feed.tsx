import { useListPosts, getListPostsQueryKey } from "@workspace/api-client-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { PostCard } from "@/components/post/PostCard";
import { StoriesBar } from "@/components/stories/StoriesBar";
import { motion } from "framer-motion";

export default function Feed() {
  const { data: posts, isLoading, refetch } = useListPosts({ query: { queryKey: getListPostsQueryKey() } });

  return (
    <AppLayout>
      <div className="max-w-2xl mx-auto py-8">
        <StoriesBar />

        <div className="mb-10">
          <h1 className="text-3xl font-serif font-bold text-foreground">Global Feed</h1>
          <p className="text-muted-foreground mt-2">All updates across the network.</p>
        </div>

        {isLoading ? (
          <div className="space-y-6">
            {[1, 2, 3].map(i => (
              <div key={i} className="bg-card border border-border rounded-lg h-64 animate-pulse" />
            ))}
          </div>
        ) : posts && posts.length > 0 ? (
          <div className="space-y-8">
            {posts.map((post, i) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <PostCard post={post} onDeleted={() => refetch()} />
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-card border border-border rounded-lg">
            <h3 className="text-xl font-serif text-primary">No posts yet</h3>
            <p className="text-muted-foreground mt-2">The kingdom is quiet.</p>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
