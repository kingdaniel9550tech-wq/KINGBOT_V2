import { useState, useEffect } from "react";
import { useListUsers, useListPages, useGetUserPageAccess, useSetUserPageAccess, getListUsersQueryKey, getListPagesQueryKey, getGetUserPageAccessQueryKey } from "@workspace/api-client-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { useQueryClient } from "@tanstack/react-query";

// Inner component for a single user row to handle its own access queries/mutations
function UserAccessRow({ user, pages }: { user: any, pages: any[] }) {
  const { data: accessData, isLoading } = useGetUserPageAccess(user.id, { query: { queryKey: getGetUserPageAccessQueryKey(user.id) } });
  const setAccess = useSetUserPageAccess();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleToggle = (pageId: number, checked: boolean) => {
    if (!accessData) return;
    
    // Calculate new array of pageIds that this user should have access to
    const currentAccessIds = accessData.filter(a => a.hasAccess).map(a => a.pageId);
    let newAccessIds = [...currentAccessIds];
    
    if (checked && !newAccessIds.includes(pageId)) {
      newAccessIds.push(pageId);
    } else if (!checked && newAccessIds.includes(pageId)) {
      newAccessIds = newAccessIds.filter(id => id !== pageId);
    }

    setAccess.mutate({
      userId: user.id,
      data: { pageIds: newAccessIds }
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetUserPageAccessQueryKey(user.id) });
      },
      onError: () => {
        toast({ title: "Error", description: "Failed to update access", variant: "destructive" });
      }
    });
  };

  const isOwner = user.role === 'owner';

  return (
    <div className="flex border-b border-border p-4 items-center hover:bg-white/[0.02] transition-colors">
      <div className="w-64 flex items-center space-x-3 shrink-0">
        <Avatar className="h-8 w-8 border border-border">
          <AvatarFallback className="bg-background text-xs">{user.username.charAt(0).toUpperCase()}</AvatarFallback>
        </Avatar>
        <div className="overflow-hidden">
          <div className="font-semibold text-sm truncate">{user.displayName || user.username}</div>
          <div className="text-xs text-muted-foreground uppercase">{user.role}</div>
        </div>
      </div>

      <div className="flex-1 flex items-center space-x-6 overflow-x-auto pb-2">
        {pages.map(page => {
          const hasAccess = isOwner || (accessData?.find(a => a.pageId === page.id)?.hasAccess || false);
          return (
            <div key={page.id} className="flex flex-col items-center justify-center min-w-[80px] space-y-2">
              <Checkbox 
                checked={hasAccess} 
                onCheckedChange={(c) => handleToggle(page.id, c === true)}
                disabled={isOwner || setAccess.isPending}
                className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
              />
              <span className="text-[10px] text-muted-foreground truncate w-full text-center">{page.name}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function AdminAccess() {
  const { data: users } = useListUsers({ query: { queryKey: getListUsersQueryKey() } });
  const { data: pages } = useListPages({ query: { queryKey: getListPagesQueryKey() } });

  return (
    <AppLayout>
      <div className="py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-serif font-bold text-foreground">Access Control</h1>
          <p className="text-muted-foreground mt-2">Manage which users can view specific pages.</p>
        </div>

        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="flex border-b border-border p-4 bg-muted/30">
            <div className="w-64 font-semibold text-sm uppercase tracking-wider shrink-0 text-muted-foreground">User</div>
            <div className="flex-1 font-semibold text-sm uppercase tracking-wider text-muted-foreground pl-2">Pages</div>
          </div>
          
          <div className="divide-y divide-border">
            {users && pages && users.map(user => (
              <UserAccessRow key={user.id} user={user} pages={pages} />
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
