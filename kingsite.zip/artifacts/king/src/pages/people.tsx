import { useQuery } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { api } from "@/lib/api";
import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, BadgeCheck } from "lucide-react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { AvatarImage } from "@/components/ui/avatar";

interface Member {
  id: number;
  username: string;
  displayName: string | null;
  avatarUrl: string | null;
  isVerified: boolean;
  role: string;
}

export default function People() {
  const { data: me } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const [, setLocation] = useLocation();

  const { data: members = [], isLoading } = useQuery<Member[]>({
    queryKey: ["members"],
    queryFn: () => api.get<Member[]>("/users/members"),
  });

  const others = members.filter((m) => m.id !== me?.id);

  const roleColor = (role: string) =>
    role === "owner" ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" :
    role === "admin" ? "bg-blue-500/20 text-blue-400 border-blue-500/30" :
    "bg-white/10 text-muted-foreground border-border";

  return (
    <AppLayout>
      <div className="max-w-2xl mx-auto py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-serif font-bold text-foreground">Members</h1>
          <p className="text-muted-foreground mt-2">Everyone in the network. Send a message to connect.</p>
        </div>

        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="bg-card border border-border rounded-lg h-16 animate-pulse" />
            ))}
          </div>
        ) : others.length === 0 ? (
          <div className="text-center py-16 bg-card border border-border rounded-lg">
            <p className="text-muted-foreground">No other members yet.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {others.map((member, i) => (
              <motion.div
                key={member.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="bg-card border border-border rounded-lg px-4 py-3 flex items-center gap-4"
              >
                <Avatar className="h-10 w-10 flex-shrink-0">
                  {member.avatarUrl && <AvatarImage src={member.avatarUrl} alt={member.displayName || member.username} />}
                  <AvatarFallback className="bg-primary/20 text-primary font-semibold">
                    {(member.displayName || member.username)[0]?.toUpperCase()}
                  </AvatarFallback>
                </Avatar>

                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm truncate flex items-center gap-1">
                    {member.displayName || member.username}
                    {member.isVerified && <BadgeCheck size={14} className="text-primary fill-primary/20 flex-shrink-0" />}
                  </p>
                  {member.displayName && (
                    <p className="text-xs text-muted-foreground truncate">@{member.username}</p>
                  )}
                </div>

                <Badge variant="outline" className={`text-[10px] uppercase tracking-wider flex-shrink-0 ${roleColor(member.role)}`}>
                  {member.role}
                </Badge>

                <Button
                  size="sm"
                  variant="outline"
                  className="flex-shrink-0 gap-1.5 border-primary/30 text-primary hover:bg-primary/10"
                  onClick={() => setLocation(`/messages?user=${member.id}`)}
                >
                  <MessageCircle size={14} />
                  Message
                </Button>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
