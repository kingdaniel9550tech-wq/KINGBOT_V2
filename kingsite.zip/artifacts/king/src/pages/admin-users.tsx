import { useListUsers, useUpdateUser, useDeleteUser, useKickUserSession, useCreateUser, getListUsersQueryKey } from "@workspace/api-client-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useState } from "react";
import { format } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { MoreHorizontal, Trash2, Edit2, ShieldAlert, BadgeCheck } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { api } from "@/lib/api";

function EditUserDialog({ user, trigger }: { user: any, trigger: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const [displayName, setDisplayName] = useState(user.displayName || "");
  const [role, setRole] = useState(user.role);
  const [password, setPassword] = useState("");
  const [isActive, setIsActive] = useState(user.isActive);

  const updateUser = useUpdateUser();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleSave = () => {
    updateUser.mutate({
      userId: user.id,
      data: {
        displayName: displayName || null,
        role,
        isActive,
        ...(password ? { password } : {})
      }
    }, {
      onSuccess: () => {
        toast({ title: "User updated" });
        queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
        setOpen(false);
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="bg-card border-border text-foreground">
        <DialogHeader>
          <DialogTitle className="font-serif">Edit User: {user.username}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Display Name</Label>
            <Input value={displayName} onChange={e => setDisplayName(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Role</Label>
            <Select value={role} onValueChange={setRole} disabled={user.role === 'owner'}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="user">User</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
                {user.role === 'owner' && <SelectItem value="owner">Owner</SelectItem>}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Reset Password (leave blank to keep current)</Label>
            <Input type="password" value={password} onChange={e => setPassword(e.target.value)} />
          </div>
          <div className="flex items-center space-x-2 pt-2">
            <Switch checked={isActive} onCheckedChange={setIsActive} disabled={user.role === 'owner'} />
            <Label>Active Account</Label>
          </div>
          <div className="flex justify-end pt-4">
            <Button onClick={handleSave} disabled={updateUser.isPending}>Save Changes</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function CreateUserDialog() {
  const [open, setOpen] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [role, setRole] = useState("user");

  const createUser = useCreateUser();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleCreate = () => {
    if (!username || !password) return;
    createUser.mutate({
      data: { username, password, displayName: displayName || null, role: role as any }
    }, {
      onSuccess: () => {
        toast({ title: "User created" });
        queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
        setOpen(false);
        setUsername(""); setPassword(""); setDisplayName(""); setRole("user");
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="font-bold tracking-wider uppercase">Invite User</Button>
      </DialogTrigger>
      <DialogContent className="bg-card border-border text-foreground">
        <DialogHeader>
          <DialogTitle className="font-serif">Invite New User</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Username</Label>
            <Input value={username} onChange={e => setUsername(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Password</Label>
            <Input type="password" value={password} onChange={e => setPassword(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Display Name</Label>
            <Input value={displayName} onChange={e => setDisplayName(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Role</Label>
            <Select value={role} onValueChange={setRole}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="user">User</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex justify-end pt-4">
            <Button onClick={handleCreate} disabled={createUser.isPending}>Create User</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function AdminUsers() {
  const { data: users, isLoading } = useListUsers({ query: { queryKey: getListUsersQueryKey() } });
  const deleteUser = useDeleteUser();
  const kickUser = useKickUserSession();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleDelete = (id: number) => {
    if (confirm("Permanently delete this user?")) {
      deleteUser.mutate({ userId: id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
          toast({ title: "User deleted" });
        }
      });
    }
  };

  const handleKick = (id: number) => {
    kickUser.mutate({ userId: id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
        toast({ title: "Session terminated" });
      }
    });
  };

  const handleVerify = async (id: number, currentlyVerified: boolean) => {
    try {
      await api.post(`/users/${id}/verify`);
      queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
      toast({ title: currentlyVerified ? "Verification removed" : "Verification granted" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  return (
    <AppLayout>
      <div className="py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-serif font-bold text-foreground">Directory</h1>
            <p className="text-muted-foreground mt-2">Manage the private network members.</p>
          </div>
          <CreateUserDialog />
        </div>

        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead>User</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last Seen</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={5} className="text-center py-8">Loading...</TableCell></TableRow>
              ) : users?.map(u => (
                <TableRow key={u.id} className="border-border">
                  <TableCell>
                    <div className="font-medium">{u.username}</div>
                    {u.displayName && <div className="text-xs text-muted-foreground">{u.displayName}</div>}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={`uppercase text-[10px] ${u.role === 'owner' ? 'border-primary text-primary' : u.role === 'admin' ? 'border-secondary-foreground' : ''}`}>
                      {u.role}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <div className={`h-2 w-2 rounded-full ${u.isOnline ? 'bg-green-500' : 'bg-muted'}`} />
                      <span className="text-xs">{!u.isActive ? 'Suspended' : u.isOnline ? 'Online' : 'Offline'}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">
                    {u.lastLoginAt ? format(new Date(u.lastLoginAt), "MMM d, yyyy") : 'Never'}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal size={16} /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-card border-border">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuSeparator className="bg-border" />
                        <EditUserDialog 
                          user={u} 
                          trigger={<DropdownMenuItem onSelect={e => e.preventDefault()}><Edit2 className="mr-2 h-4 w-4"/> Edit</DropdownMenuItem>} 
                        />
                        <DropdownMenuItem onSelect={() => handleVerify(u.id, u.isVerified)}>
                          <BadgeCheck className="mr-2 h-4 w-4" />
                          {u.isVerified ? "Remove Verification" : "Grant Verification"}
                        </DropdownMenuItem>
                        {u.role !== 'owner' && (
                          <>
                            <DropdownMenuItem onSelect={() => handleKick(u.id)}><ShieldAlert className="mr-2 h-4 w-4"/> Kick Session</DropdownMenuItem>
                            <DropdownMenuItem className="text-destructive focus:bg-destructive/10 focus:text-destructive" onSelect={() => handleDelete(u.id)}>
                              <Trash2 className="mr-2 h-4 w-4"/> Delete
                            </DropdownMenuItem>
                          </>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </AppLayout>
  );
}
