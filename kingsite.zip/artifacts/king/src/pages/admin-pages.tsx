import { useListPages, useCreatePage, useUpdatePage, useDeletePage, getListPagesQueryKey } from "@workspace/api-client-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useState } from "react";
import { format } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { MoreHorizontal, Trash2, Edit2 } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

function EditPageDialog({ page, trigger }: { page: any, trigger: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState(page.name);
  const [description, setDescription] = useState(page.description || "");
  const [isActive, setIsActive] = useState(page.isActive);

  const updatePage = useUpdatePage();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleSave = () => {
    updatePage.mutate({
      pageId: page.id,
      data: { name, description, isActive }
    }, {
      onSuccess: () => {
        toast({ title: "Page updated" });
        queryClient.invalidateQueries({ queryKey: getListPagesQueryKey() });
        setOpen(false);
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="bg-card border-border text-foreground">
        <DialogHeader>
          <DialogTitle className="font-serif">Edit Page</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Name</Label>
            <Input value={name} onChange={e => setName(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea value={description} onChange={e => setDescription(e.target.value)} />
          </div>
          <div className="flex items-center space-x-2 pt-2">
            <Switch checked={isActive} onCheckedChange={setIsActive} />
            <Label>Active</Label>
          </div>
          <div className="flex justify-end pt-4">
            <Button onClick={handleSave} disabled={updatePage.isPending}>Save</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function CreatePageDialog() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [description, setDescription] = useState("");

  const createPage = useCreatePage();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleCreate = () => {
    if (!name || !slug) return;
    createPage.mutate({
      data: { name, slug, description }
    }, {
      onSuccess: () => {
        toast({ title: "Page created" });
        queryClient.invalidateQueries({ queryKey: getListPagesQueryKey() });
        setOpen(false);
        setName(""); setSlug(""); setDescription("");
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="font-bold tracking-wider uppercase">Create Page</Button>
      </DialogTrigger>
      <DialogContent className="bg-card border-border text-foreground">
        <DialogHeader>
          <DialogTitle className="font-serif">New Page</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Name</Label>
            <Input value={name} onChange={e => { setName(e.target.value); if(!slug) setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, '-')) }} />
          </div>
          <div className="space-y-2">
            <Label>Slug</Label>
            <Input value={slug} onChange={e => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]+/g, ''))} />
          </div>
          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea value={description} onChange={e => setDescription(e.target.value)} />
          </div>
          <div className="flex justify-end pt-4">
            <Button onClick={handleCreate} disabled={createPage.isPending}>Create</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function AdminPages() {
  const { data: pages, isLoading } = useListPages({ query: { queryKey: getListPagesQueryKey() } });
  const deletePage = useDeletePage();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleDelete = (id: number) => {
    if (confirm("Delete this page? This will also remove all its posts!")) {
      deletePage.mutate({ pageId: id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListPagesQueryKey() });
          toast({ title: "Page deleted" });
        }
      });
    }
  };

  return (
    <AppLayout>
      <div className="py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-serif font-bold text-foreground">Pages</h1>
            <p className="text-muted-foreground mt-2">Manage content channels.</p>
          </div>
          <CreatePageDialog />
        </div>

        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead>Page</TableHead>
                <TableHead>Slug</TableHead>
                <TableHead>Posts</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={5} className="text-center py-8">Loading...</TableCell></TableRow>
              ) : pages?.map(p => (
                <TableRow key={p.id} className="border-border">
                  <TableCell>
                    <div className="font-medium flex items-center space-x-2">
                      <span>{p.name}</span>
                      {!p.isActive && <Badge variant="secondary" className="text-[10px]">Archived</Badge>}
                    </div>
                  </TableCell>
                  <TableCell className="text-muted-foreground font-mono text-xs">/{p.slug}</TableCell>
                  <TableCell>{p.postCount}</TableCell>
                  <TableCell className="text-muted-foreground text-sm">
                    {p.createdAt ? format(new Date(p.createdAt), "MMM d, yyyy") : ''}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal size={16} /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-card border-border">
                        <EditPageDialog 
                          page={p} 
                          trigger={<DropdownMenuItem onSelect={e => e.preventDefault()}><Edit2 className="mr-2 h-4 w-4"/> Edit</DropdownMenuItem>} 
                        />
                        <DropdownMenuItem className="text-destructive focus:bg-destructive/10 focus:text-destructive" onSelect={() => handleDelete(p.id)}>
                          <Trash2 className="mr-2 h-4 w-4"/> Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </AppLayout>
  );
}
