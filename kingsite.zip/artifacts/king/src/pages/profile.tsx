import { useState, useRef } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Camera, BadgeCheck, Loader2 } from "lucide-react";
import { api } from "@/lib/api";
import { motion } from "framer-motion";

export default function Profile() {
  const { data: user, isLoading } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const qc = useQueryClient();
  const { toast } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);

  const [displayName, setDisplayName] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);

  // Initialise fields once user loads
  const [initialised, setInitialised] = useState(false);
  if (user && !initialised) {
    setDisplayName(user.displayName ?? "");
    setAvatarUrl((user as any).avatarUrl ?? null);
    setInitialised(true);
  }

  const handleAvatarClick = () => fileRef.current?.click();

  const handleAvatarFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/uploads", { method: "POST", credentials: "include", body: fd });
      if (!res.ok) throw new Error((await res.json()).error || "Upload failed");
      const data = await res.json();
      setAvatarUrl(data.url);
    } catch (err: any) {
      toast({ title: "Upload failed", description: err.message, variant: "destructive" });
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await api.patch("/users/me", { displayName: displayName || null, avatarUrl });
      await qc.invalidateQueries({ queryKey: getGetMeQueryKey() });
      toast({ title: "Profile updated" });
    } catch (err: any) {
      toast({ title: "Failed to save", description: err.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="animate-spin text-primary" size={28} />
        </div>
      </AppLayout>
    );
  }

  const previewName = displayName || user?.username || "";

  return (
    <AppLayout>
      <div className="max-w-lg mx-auto py-8">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card border border-border rounded-xl p-8 space-y-8"
        >
          <div>
            <h1 className="text-2xl font-serif font-bold">My Profile</h1>
            <p className="text-muted-foreground text-sm mt-1">Update your display name and profile picture.</p>
          </div>

          {/* Avatar */}
          <div className="flex flex-col items-center gap-4">
            <div className="relative group cursor-pointer" onClick={handleAvatarClick}>
              <Avatar className="h-24 w-24 border-2 border-primary/30">
                {avatarUrl && <AvatarImage src={avatarUrl} alt={previewName} />}
                <AvatarFallback className="bg-primary/20 text-primary text-3xl font-serif font-bold">
                  {previewName[0]?.toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="absolute inset-0 rounded-full bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                {uploading
                  ? <Loader2 size={20} className="text-white animate-spin" />
                  : <Camera size={20} className="text-white" />}
              </div>
            </div>
            <p className="text-xs text-muted-foreground">Click the picture to change it</p>
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleAvatarFile} />
          </div>

          {/* Fields */}
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>Username</Label>
              <Input value={user?.username ?? ""} disabled className="bg-background opacity-60" />
              <p className="text-[11px] text-muted-foreground">Username cannot be changed.</p>
            </div>
            <div className="space-y-1.5">
              <Label>Display Name</Label>
              <Input
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="How you appear to others"
                className="bg-background border-border"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Role</Label>
              <div className="flex items-center gap-2">
                <Input value={user?.role ?? ""} disabled className="bg-background opacity-60 capitalize" />
                {(user as any)?.isVerified && (
                  <div className="flex items-center gap-1 text-primary text-sm">
                    <BadgeCheck size={16} className="fill-primary/20" />
                    <span className="text-xs font-medium">Verified</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <Button onClick={handleSave} disabled={saving || uploading} className="w-full font-bold uppercase tracking-widest">
            {saving ? <Loader2 size={16} className="animate-spin mr-2" /> : null}
            Save Profile
          </Button>
        </motion.div>
      </div>
    </AppLayout>
  );
}
