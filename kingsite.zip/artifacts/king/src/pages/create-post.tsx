import { useState, useRef } from "react";
import { useListPages, getListPagesQueryKey } from "@workspace/api-client-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";
import { Upload, Link2, X, Image, Video, FileVideo, Plus } from "lucide-react";
import { api } from "@/lib/api";

type MediaMode = "url" | "upload";

interface UploadedFile {
  url: string;
  mediaType: "image" | "video" | "document";
  originalName?: string;
}

export default function CreatePost() {
  const [content, setContent] = useState("");
  const [mediaMode, setMediaMode] = useState<MediaMode>("upload");
  const [imageUrl, setImageUrl] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [pageId, setPageId] = useState<string>("global");
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: pages } = useListPages({ query: { queryKey: getListPagesQueryKey() } });
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const uploadFiles = async (files: FileList | File[]) => {
    const arr = Array.from(files);
    if (arr.length === 0) return;
    setUploading(true);
    try {
      for (const file of arr) {
        const formData = new FormData();
        formData.append("file", file);
        const res = await fetch("/api/uploads", { method: "POST", credentials: "include", body: formData });
        if (!res.ok) throw new Error((await res.json()).error || "Upload failed");
        const data = await res.json();
        setUploadedFiles((prev) => [...prev, {
          url: data.url,
          mediaType: data.mediaType as "image" | "video" | "document",
          originalName: data.originalName ?? file.name,
        }]);
      }
    } catch (err: any) {
      toast({ title: "Upload Failed", description: err.message, variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) uploadFiles(e.target.files);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files.length > 0) uploadFiles(e.dataTransfer.files);
  };

  const removeFile = (idx: number) => setUploadedFiles((prev) => prev.filter((_, i) => i !== idx));

  const clearAll = () => {
    setUploadedFiles([]);
    setImageUrl("");
    setVideoUrl("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const images = uploadedFiles.filter((f) => f.mediaType === "image").map((f) => f.url);
    const videoFile = uploadedFiles.find((f) => f.mediaType === "video");
    const docFiles = uploadedFiles.filter((f) => f.mediaType === "document");

    const finalVideoUrl = mediaMode === "upload" ? (videoFile?.url ?? null) : (videoUrl || null);
    const finalImageUrl = mediaMode === "url" ? (imageUrl || null) : null;
    const finalImages = mediaMode === "upload" && images.length > 0 ? images : [];
    const finalDocs = docFiles.map((d) => ({ url: d.url, name: d.originalName ?? "Document", type: "document" }));
    const finalMediaType = finalImages.length > 0 ? "image" : finalImageUrl ? "image" : finalVideoUrl ? "video" : null;

    if (!content.trim() && finalImages.length === 0 && !finalImageUrl && !finalVideoUrl && finalDocs.length === 0) {
      toast({ title: "Validation Error", description: "Post must contain text, a file, or a document.", variant: "destructive" });
      return;
    }

    setPublishing(true);
    try {
      await api.post("/posts", {
        content: content || null,
        imageUrl: finalImages.length === 0 ? finalImageUrl : null,
        videoUrl: finalVideoUrl,
        mediaType: finalMediaType,
        pageId: pageId !== "global" ? parseInt(pageId) : null,
        images: finalImages,
        documents: finalDocs,
      });
      toast({ title: "Published", description: "Your post is live." });
      setLocation("/feed");
    } catch (err: any) {
      toast({ title: "Error", description: err.message || "Failed to publish post.", variant: "destructive" });
    } finally {
      setPublishing(false);
    }
  };

  const hasImages = uploadedFiles.some((f) => f.mediaType === "image");
  const hasVideo = uploadedFiles.some((f) => f.mediaType === "video");

  return (
    <AppLayout>
      <div className="max-w-2xl mx-auto py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-serif font-bold text-foreground">Draft Post</h1>
          <p className="text-muted-foreground mt-2">Publish an update to the network.</p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card border border-border rounded-lg p-6"
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Destination */}
            <div className="space-y-2">
              <Label>Destination</Label>
              <Select value={pageId} onValueChange={setPageId}>
                <SelectTrigger className="bg-background border-border">
                  <SelectValue placeholder="Select destination" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="global">Global Feed (All Users)</SelectItem>
                  {pages?.map((p) => (
                    <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Content */}
            <div className="space-y-2">
              <Label>Content</Label>
              <Textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Write your message..."
                className="min-h-[120px] bg-background border-border resize-none"
              />
            </div>

            {/* Media */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Media (Optional)</Label>
                <div className="flex rounded-md border border-border overflow-hidden text-xs">
                  <button
                    type="button"
                    onClick={() => { setMediaMode("upload"); clearAll(); }}
                    className={`px-3 py-1.5 flex items-center gap-1.5 transition-colors ${mediaMode === "upload" ? "bg-primary text-primary-foreground" : "bg-background text-muted-foreground hover:text-foreground"}`}
                  >
                    <Upload size={12} /> Upload File
                  </button>
                  <button
                    type="button"
                    onClick={() => { setMediaMode("url"); clearAll(); }}
                    className={`px-3 py-1.5 flex items-center gap-1.5 transition-colors ${mediaMode === "url" ? "bg-primary text-primary-foreground" : "bg-background text-muted-foreground hover:text-foreground"}`}
                  >
                    <Link2 size={12} /> Paste URL
                  </button>
                </div>
              </div>

              {mediaMode === "upload" && (
                <div className="space-y-3">
                  {/* Uploaded file previews */}
                  {uploadedFiles.length > 0 && (
                    <div className={`grid gap-2 ${uploadedFiles.length > 1 ? "grid-cols-3" : "grid-cols-1"}`}>
                      {uploadedFiles.map((file, idx) => (
                        <div key={idx} className="relative group rounded-lg overflow-hidden border border-border bg-black">
                          {file.mediaType === "image" ? (
                            <img src={file.url} className="w-full h-28 object-cover" />
                          ) : (
                            <video src={file.url} className="w-full h-28 object-cover" />
                          )}
                          <button
                            type="button"
                            onClick={() => removeFile(idx)}
                            className="absolute top-1 right-1 bg-black/70 hover:bg-red-600 text-white rounded-full p-0.5 transition-colors opacity-0 group-hover:opacity-100"
                          >
                            <X size={12} />
                          </button>
                          <div className="absolute bottom-1 left-1 bg-black/60 text-[9px] text-white px-1.5 py-0.5 rounded-full flex items-center gap-1">
                            {file.mediaType === "image" ? <Image size={8} /> : <FileVideo size={8} />}
                            {file.mediaType}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Drop zone */}
                  {!hasVideo && (
                    <div
                      onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                      onDragLeave={() => setDragOver(false)}
                      onDrop={handleDrop}
                      onClick={() => fileInputRef.current?.click()}
                      className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${dragOver ? "border-primary bg-primary/5" : "border-border hover:border-primary/50 hover:bg-primary/5"}`}
                    >
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*,video/*"
                        multiple
                        onChange={handleFileChange}
                        className="hidden"
                      />
                      {uploading ? (
                        <div className="flex flex-col items-center gap-2">
                          <div className="animate-spin h-7 w-7 border-2 border-primary border-t-transparent rounded-full" />
                          <p className="text-sm text-muted-foreground">Uploading...</p>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center gap-1.5">
                          <div className="flex gap-2 text-muted-foreground">
                            {hasImages ? <Plus size={20} className="text-primary" /> : <><Image size={20} /><Video size={20} /></>}
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {hasImages
                              ? <span className="text-primary underline">Add more images</span>
                              : <>Drop files here, or <span className="text-primary underline">click to browse</span></>
                            }
                          </p>
                          <p className="text-xs text-muted-foreground/60">
                            Select multiple images at once · JPG, PNG, GIF, WEBP, MP4, WEBM · up to 100 MB each
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {mediaMode === "url" && (
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <Label className="text-xs text-muted-foreground flex items-center gap-1">
                      <Image size={12} /> Image URL
                    </Label>
                    <Input
                      type="url"
                      value={imageUrl}
                      onChange={(e) => { setImageUrl(e.target.value); if (e.target.value) setVideoUrl(""); }}
                      placeholder="https://example.com/image.jpg"
                      className="bg-background border-border"
                    />
                    {imageUrl && (
                      <div className="mt-2 rounded-md overflow-hidden bg-black max-h-[200px] flex items-center justify-center border border-border">
                        <img src={imageUrl} alt="Preview" className="max-h-[200px] object-contain" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
                      </div>
                    )}
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs text-muted-foreground flex items-center gap-1">
                      <Video size={12} /> Video URL
                    </Label>
                    <Input
                      type="url"
                      value={videoUrl}
                      onChange={(e) => { setVideoUrl(e.target.value); if (e.target.value) setImageUrl(""); }}
                      placeholder="https://example.com/video.mp4"
                      className="bg-background border-border"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-border flex justify-end">
              <Button type="submit" disabled={publishing} className="font-bold tracking-widest uppercase px-8">
                {publishing ? "Publishing..." : "Publish"}
              </Button>
            </div>
          </form>
        </motion.div>
      </div>
    </AppLayout>
  );
}
