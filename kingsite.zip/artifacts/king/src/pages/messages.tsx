import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { AppLayout } from "@/components/layout/AppLayout";
import { api } from "@/lib/api";
import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { Send, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { motion } from "framer-motion";

interface Conversation {
  userId: number;
  username: string;
  displayName: string | null;
  lastMessage: string;
  lastAt: string;
  unread: number;
}

interface Message {
  id: number;
  senderId: number;
  recipientId: number;
  content: string;
  readAt: string | null;
  createdAt: string;
}

export default function Messages() {
  const { data: me } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const qc = useQueryClient();
  const [draft, setDraft] = useState("");

  const searchParams = new URLSearchParams(window.location.search);
  const userFromQuery = searchParams.get("user") ? parseInt(searchParams.get("user")!) : null;
  const [activeUserId, setActiveUserId] = useState<number | null>(userFromQuery);

  const { data: conversations = [] } = useQuery<Conversation[]>({
    queryKey: ["conversations"],
    queryFn: () => api.get<Conversation[]>("/messages/conversations"),
    refetchInterval: 5000,
  });

  const { data: thread = [] } = useQuery<Message[]>({
    queryKey: ["thread", activeUserId],
    queryFn: () => api.get<Message[]>(`/messages/${activeUserId}`),
    enabled: !!activeUserId,
    refetchInterval: 3000,
  });

  const sendMutation = useMutation({
    mutationFn: (content: string) =>
      api.post("/messages", { recipientId: activeUserId, content }),
    onSuccess: () => {
      setDraft("");
      qc.invalidateQueries({ queryKey: ["thread", activeUserId] });
      qc.invalidateQueries({ queryKey: ["conversations"] });
    },
  });

  const handleSend = () => {
    if (!draft.trim() || !activeUserId) return;
    sendMutation.mutate(draft.trim());
  };

  const activeConversation = conversations.find((c) => c.userId === activeUserId);
  const activeName = activeConversation?.displayName || activeConversation?.username || "";

  return (
    <AppLayout>
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-serif font-bold text-foreground mb-6">Messages</h1>

        <div className="border border-border rounded-lg overflow-hidden bg-card flex" style={{ minHeight: 480 }}>
          {/* Conversation list */}
          <div className={`w-full md:w-72 border-r border-border flex-shrink-0 ${activeUserId ? "hidden md:flex" : "flex"} flex-col`}>
            <div className="p-3 border-b border-border text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              Conversations
            </div>
            {conversations.length === 0 ? (
              <div className="flex-1 flex items-center justify-center p-6 text-center text-muted-foreground text-sm">
                No messages yet. Start by visiting a user's profile.
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto">
                {conversations.map((c) => (
                  <button
                    key={c.userId}
                    onClick={() => setActiveUserId(c.userId)}
                    className={`w-full flex items-center gap-3 p-3 hover:bg-white/5 transition-colors text-left border-b border-border/50 ${activeUserId === c.userId ? "bg-primary/10" : ""}`}
                  >
                    <Avatar className="h-10 w-10 flex-shrink-0">
                      <AvatarFallback className="bg-primary/20 text-primary font-semibold">
                        {(c.displayName || c.username)[0]?.toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-sm truncate">{c.displayName || c.username}</span>
                        {c.unread > 0 && (
                          <span className="ml-2 bg-primary text-black text-[10px] font-bold rounded-full px-1.5 py-0.5 flex-shrink-0">
                            {c.unread}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground truncate">{c.lastMessage}</p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Chat area */}
          <div className={`flex-1 flex flex-col ${!activeUserId ? "hidden md:flex" : "flex"}`}>
            {activeUserId ? (
              <>
                <div className="flex items-center gap-3 p-3 border-b border-border">
                  <button onClick={() => setActiveUserId(null)} className="md:hidden text-muted-foreground hover:text-foreground">
                    <ArrowLeft size={20} />
                  </button>
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-primary/20 text-primary text-sm font-semibold">
                      {activeName[0]?.toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <span className="font-semibold">{activeName}</span>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {thread.map((msg, i) => {
                    const isMe = msg.senderId === me?.id;
                    return (
                      <motion.div
                        key={msg.id}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.02 }}
                        className={`flex ${isMe ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`max-w-[70%] px-3 py-2 rounded-2xl text-sm ${
                            isMe
                              ? "bg-primary text-black rounded-br-sm"
                              : "bg-white/10 text-foreground rounded-bl-sm"
                          }`}
                        >
                          {msg.content}
                        </div>
                      </motion.div>
                    );
                  })}
                </div>

                <div className="p-3 border-t border-border flex gap-2">
                  <Input
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    placeholder="Type a message..."
                    className="flex-1"
                    onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                  />
                  <Button
                    onClick={handleSend}
                    disabled={!draft.trim() || sendMutation.isPending}
                    size="icon"
                    className="bg-primary text-black hover:bg-primary/80"
                  >
                    <Send size={16} />
                  </Button>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-muted-foreground text-sm">
                Select a conversation to start messaging
              </div>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
