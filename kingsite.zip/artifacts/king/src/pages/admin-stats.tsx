import { useGetOverviewStats, getGetOverviewStatsQueryKey } from "@workspace/api-client-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, FileText, Layers, MessageSquare, Activity } from "lucide-react";
import { motion } from "framer-motion";
import { formatDistanceToNow } from "date-fns";

export default function AdminStats() {
  const { data: stats, isLoading } = useGetOverviewStats({ query: { queryKey: getGetOverviewStatsQueryKey() } });

  const metrics = [
    { title: "Total Users", value: stats?.totalUsers || 0, icon: Users, color: "text-blue-500" },
    { title: "Active Now", value: stats?.activeUsers || 0, icon: Activity, color: "text-green-500" },
    { title: "Total Posts", value: stats?.totalPosts || 0, icon: FileText, color: "text-primary" },
    { title: "Total Pages", value: stats?.totalPages || 0, icon: Layers, color: "text-purple-500" },
    { title: "Comments", value: stats?.totalComments || 0, icon: MessageSquare, color: "text-orange-500" },
  ];

  return (
    <AppLayout>
      <div className="py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-serif font-bold text-foreground">Empire Stats</h1>
          <p className="text-muted-foreground mt-2">Metrics and overview of the platform.</p>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1,2,3,4,5].map(i => <div key={i} className="bg-card border border-border h-32 rounded-lg animate-pulse" />)}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
              {metrics.map((m, i) => (
                <motion.div
                  key={m.title}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.1 }}
                >
                  <Card className="bg-card border-border">
                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                      <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-wider">{m.title}</CardTitle>
                      <m.icon className={`h-4 w-4 ${m.color}`} />
                    </CardHeader>
                    <CardContent>
                      <div className="text-4xl font-bold font-serif">{m.value}</div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            <div className="space-y-4">
              <h2 className="text-xl font-serif font-bold border-b border-border pb-2">Recent Pulses</h2>
              <div className="bg-card border border-border rounded-lg overflow-hidden divide-y divide-border">
                {stats?.recentPosts?.length ? stats.recentPosts.map((post: any) => (
                  <div key={post.id} className="p-4 flex items-center justify-between">
                    <div>
                      <div className="font-semibold">{post.authorName}</div>
                      <div className="text-sm text-muted-foreground truncate max-w-md">{post.content || "Media post"}</div>
                    </div>
                    <div className="text-xs text-muted-foreground whitespace-nowrap ml-4">
                      {post.createdAt ? formatDistanceToNow(new Date(post.createdAt), { addSuffix: true }) : ''}
                    </div>
                  </div>
                )) : (
                  <div className="p-8 text-center text-muted-foreground">No recent posts</div>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </AppLayout>
  );
}
