import { useListPosts, useListPages, getListPostsQueryKey, getListPagesQueryKey } from "@workspace/api-client-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { PostCard } from "@/components/post/PostCard";
import { motion } from "framer-motion";
import { useParams } from "wouter";

export default function PageView() {
  const params = useParams();
  const slug = params.slug;

  const { data: pages } = useListPages({ query: { queryKey: getListPagesQueryKey() } });
  const page = pages?.find(p => p.slug === slug);

  // We fetch posts for the specific page. If the user doesn't have access, the API should 403, 
  // but wouter matches regardless. We can show an error state.
  const { data: posts, isLoading, error, refetch } = useListPosts(
    { pageId: page?.id },
    { query: { queryKey: getListPostsQueryKey({ pageId: page?.id }), enabled: !!page?.id, retry: false } }
  );

  return (
    <AppLayout>
      <div className="max-w-2xl mx-auto py-8">
        {!page && !isLoading && !error && (
          <div className="text-center py-20 bg-card border border-border rounded-lg">
            <h3 className="text-xl font-serif text-destructive">Page Not Found</h3>
          </div>
        )}

        {error && (
          <div className="text-center py-20 bg-card border border-destructive/50 rounded-lg">
            <h3 className="text-xl font-serif text-destructive mb-2">Access Denied</h3>
            <p className="text-muted-foreground">You do not have permission to view this page.</p>
          </div>
        )}

        {page && !error && (
          <>
            <div className="mb-10 pb-6 border-b border-border">
              <h1 className="text-3xl font-serif font-bold text-primary">{page.name}</h1>
              {page.description && <p className="text-muted-foreground mt-2">{page.description}</p>}
            </div>

            {isLoading ? (
              <div className="space-y-6">
                {[1, 2].map(i => (
                  <div key={i} className="bg-card border border-border rounded-lg h-64 animate-pulse" />
                ))}
              </div>
            ) : posts && posts.length > 0 ? (
              <div className="space-y-8">
                {posts.map((post, i) => (
                  <motion.div
                    key={post.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <PostCard post={post} onDeleted={() => refetch()} />
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-20 border border-dashed border-border rounded-lg">
                <p className="text-muted-foreground">No posts in this page yet.</p>
              </div>
            )}
          </>
        )}
      </div>
    </AppLayout>
  );
}
