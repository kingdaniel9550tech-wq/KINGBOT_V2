import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

document.addEventListener("contextmenu", (e) => e.preventDefault());

document.addEventListener("keydown", (e) => {
  if (
    e.key === "PrintScreen" ||
    (e.ctrlKey && e.shiftKey && (e.key === "s" || e.key === "S")) ||
    (e.metaKey && e.shiftKey && (e.key === "s" || e.key === "S" || e.key === "3" || e.key === "4" || e.key === "5"))
  ) {
    e.preventDefault();
  }
});

createRoot(document.getElementById("root")!).render(<App />);
