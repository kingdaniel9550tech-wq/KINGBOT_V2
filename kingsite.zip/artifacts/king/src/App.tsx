import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import NotFound from "@/pages/not-found";
import Login from "@/pages/login";
import Feed from "@/pages/feed";
import PageView from "@/pages/page-view";
import CreatePost from "@/pages/create-post";
import AdminUsers from "@/pages/admin-users";
import AdminPages from "@/pages/admin-pages";
import AdminAccess from "@/pages/admin-access";
import AdminStats from "@/pages/admin-stats";
import Messages from "@/pages/messages";
import People from "@/pages/people";
import Profile from "@/pages/profile";

import { ProtectedRoute } from "@/components/ProtectedRoute";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Login} />
      
      <Route path="/feed">
        <ProtectedRoute><Feed /></ProtectedRoute>
      </Route>
      
      <Route path="/page/:slug">
        <ProtectedRoute><PageView /></ProtectedRoute>
      </Route>

      <Route path="/create">
        <ProtectedRoute><CreatePost /></ProtectedRoute>
      </Route>

      <Route path="/profile">
        <ProtectedRoute><Profile /></ProtectedRoute>
      </Route>

      <Route path="/admin/users">
        <ProtectedRoute requireOwner><AdminUsers /></ProtectedRoute>
      </Route>

      <Route path="/admin/pages">
        <ProtectedRoute requireOwner><AdminPages /></ProtectedRoute>
      </Route>

      <Route path="/admin/access">
        <ProtectedRoute requireOwner><AdminAccess /></ProtectedRoute>
      </Route>

      <Route path="/admin/stats">
        <ProtectedRoute requireOwner><AdminStats /></ProtectedRoute>
      </Route>

      <Route path="/messages">
        <ProtectedRoute><Messages /></ProtectedRoute>
      </Route>

      <Route path="/people">
        <ProtectedRoute><People /></ProtectedRoute>
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
