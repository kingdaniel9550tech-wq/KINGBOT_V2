# 👑KING👑

An exclusive, invite-only content platform. Admins post content (text, images, video); regular users can view, like, and comment. The owner controls everything: who joins, what they can see, and who can post.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/king run dev` — run the KING frontend (port 20958)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string, `SESSION_SECRET` — session signing secret

## Owner Login

- **Username**: `owner`
- **Password**: `king2024`
- Change this password immediately after first login via the User Management panel.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind CSS + framer-motion + wouter
- API: Express 5 + express-session + bcrypt
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — API contract (source of truth)
- `lib/db/src/schema/` — DB table definitions (users, pages, posts, comments, likes, page_access)
- `artifacts/api-server/src/routes/` — Express route handlers
- `artifacts/api-server/src/middlewares/auth.ts` — auth middleware + session validation
- `artifacts/king/src/` — React frontend

## Architecture decisions

- **Custom auth with express-session**: Owner-controlled accounts, single-device enforcement via `sessionToken` field in DB. Each login writes a UUID to the user row; middleware checks it matches the session. Kicking a session clears that token.
- **Role system**: `owner` > `admin` > `user`. Only owner creates accounts. Admins and owner can post. Users can only view/like/comment.
- **Page-level access**: Stored in `page_access` join table. Owner assigns users to pages. Admins/owners see all pages always.
- **Global feed**: `/api/posts` without `pageId` returns ALL posts regardless of page assignment — visible to all logged-in users.
- **Session single-device**: If `sessionToken` is set in the DB row, login returns 409. Owner can kick any user's session from User Management.

## Product

- Login page (invite-only, no registration)
- Global feed (`/feed`) — all posts from all pages
- Page feeds (`/page/:slug`) — filtered by page, access-controlled
- Create post (`/create`) — admin/owner only, supports text/image/video
- User management (`/admin/users`) — owner only
- Page management (`/admin/pages`) — owner only
- Access control (`/admin/access`) — owner only, per-user per-page toggle grid
- Stats dashboard (`/admin/stats`) — owner only

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- bcrypt requires `pnpm approve-builds` (handled via `onlyBuiltDependencies` in pnpm-workspace.yaml)
- Sessions use `SESSION_SECRET` env var — falls back to a default in dev, must be set in production
- Single-device login: if a user forgets to logout before switching devices, owner must kick their session from `/admin/users`

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
