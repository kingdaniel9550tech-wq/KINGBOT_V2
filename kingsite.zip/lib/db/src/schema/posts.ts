import { pgTable, text, serial, timestamp, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";
import { pagesTable } from "./pages";

export const postsTable = pgTable("posts", {
  id: serial("id").primaryKey(),
  content: text("content"),
  imageUrl: text("image_url"),
  videoUrl: text("video_url"),
  mediaType: text("media_type"),
  authorId: integer("author_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  pageId: integer("page_id").references(() => pagesTable.id, { onDelete: "set null" }),
  images: jsonb("images").$type<string[]>().default([]),
  documents: jsonb("documents").$type<{ url: string; name: string; type: string }[]>().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertPostSchema = createInsertSchema(postsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertPost = z.infer<typeof insertPostSchema>;
export type Post = typeof postsTable.$inferSelect;
