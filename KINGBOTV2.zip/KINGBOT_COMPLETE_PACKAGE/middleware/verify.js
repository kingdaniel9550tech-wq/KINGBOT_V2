const fs = require('fs');
const path = require('path');
const nodemailer = require('nodemailer');

const verifiedFile = path.join(__dirname, '../data/verified_users.json');
const pendingFile = path.join(__dirname, '../data/pending_verification.json');

function loadJson(file) {
  try {
    if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {}
  return {};
}

function saveJson(file, data) {
  try {
    const dir = path.dirname(file);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
  } catch (e) {}
}

const verifiedUsers = loadJson(verifiedFile);
const pendingUsers = loadJson(pendingFile);

function isVerified(userId) {
  return !!verifiedUsers[userId];
}

function verifyUser(userId, email) {
  verifiedUsers[userId] = { email, date: new Date().toISOString() };
  saveJson(verifiedFile, verifiedUsers);
  delete pendingUsers[userId];
  saveJson(pendingFile, pendingUsers);
}

function getPending(userId) {
  return pendingUsers[userId] || null;
}

function setPending(userId, data) {
  pendingUsers[userId] = data;
  saveJson(pendingFile, pendingUsers);
}

function clearPending(userId) {
  delete pendingUsers[userId];
  saveJson(pendingFile, pendingUsers);
}

async function sendOtpEmail(email, otp) {
  // Configure your SMTP email service here (e.g., Gmail App Password)
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER || "kingdaniel9550@gmail.com",
      pass: process.env.EMAIL_PASS || "wyqwvidfiadlhogg" // Update with your App Password if needed
    }
  });

  const mailOptions = {
    from: '"KingBot Security" <' + (process.env.EMAIL_USER || "kingdaniel9550@gmail.com") + '>',
    to: email,
    subject: 'Your KingBot Verification OTP',
    text: `Hello,\n\nYour verification OTP code for KingBot is: ${otp}\n\nPlease reply with this 6-digit code in WhatsApp to complete your verification.\n\nIf you did not request this, please ignore this email.`
  };

  try {
    await transporter.sendMail(mailOptions);
    return true;
  } catch (err) {
    console.error("Failed to send OTP email:", err);
    return false;
  }
}

module.exports = { isVerified, verifyUser, getPending, setPending, clearPending, sendOtpEmail };