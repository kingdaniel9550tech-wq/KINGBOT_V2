const { OWNER_NUMBER } = require("./config");

// The single source of truth for "is this message from the bot owner".
// fromMe is the reliable signal — the bot runs on your own linked number,
// so any message WhatsApp marks as fromMe genuinely came from you, even
// when the sender ID is reported in the newer @lid privacy format instead
// of a plain phone-number JID (which can't be reliably compared to
// OWNER_NUMBER at all).
function isOwner(ctx) {
  if (ctx.isFromMe) return true;
  const senderNumber = (ctx.sender || "").split("@")[0];
  return senderNumber === OWNER_NUMBER;
}

module.exports = { isOwner };
