const { ANTHROPIC_API_KEY, AI_MODEL } = require("./config");

async function askAI(messages) {
  if (!ANTHROPIC_API_KEY) {
    throw new Error("AI isn't configured yet — add ANTHROPIC_API_KEY to config.js (get one at console.anthropic.com).");
  }
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: AI_MODEL || "claude-haiku-4-5-20251001",
      max_tokens: 500,
      messages,
    }),
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error.message);
  const text = (data.content || []).map((c) => c.text || "").join("").trim();
  return text || "(no response)";
}

module.exports = { askAI };