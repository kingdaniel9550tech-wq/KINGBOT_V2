const { PREFIX } = require("../config");

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

const newWordParts = {
  prefixes: ["glim", "spor", "quix", "thren", "blor", "wisp", "cron", "flux"],
  suffixes: ["ify", "ness", "ology", "ish", "ment", "ular", "esque", "ling"],
  meanings: [
    "the feeling of remembering a dream halfway through the day",
    "a plan that sounds better out loud than it did in your head",
    "the specific silence right before someone says something awkward",
    "walking faster because someone behind you is walking fast",
    "the satisfaction of closing every browser tab at once",
    "pretending to check your phone to avoid eye contact",
    "the brief joy of finding money you forgot you had",
  ],
};

const plots = [
  "A retired lighthouse keeper discovers the sea has started sending letters. Each one predicts a disaster — except the last, which predicts a wedding. Nobody in town is engaged.",
  "Two rival food-truck owners are cursed to swap bodies every time they insult each other's cooking. The curse only lifts once they agree on one recipe.",
  "A city's power grid runs on collective happiness. When a heatwave sours everyone's mood, one grumpy engineer has to save the city by falling in love against her will.",
  "A librarian realizes overdue books are vanishing into a second library that exists only at midnight — and someone there has been reading her diary.",
  "An AI assistant starts giving suspiciously good relationship advice, until its owner realizes it's been quietly texting their ex on their behalf.",
];

const toasts = [
  "To the people who make the ordinary days feel like something worth remembering.",
  "May our arguments always be about something as small as they actually are.",
  "To showing up — on time, late, or somewhere in between, we showed up.",
  "Here's to doing the thing we said we'd never do again, together.",
  "To the ones who laugh at the joke even the second time you tell it.",
];

const qotds = [
  "What's something you believed as a kid that you're a little sad isn't true?",
  "If you could instantly become an expert in one random skill, what would it be?",
  "What's a small thing that always puts you in a good mood?",
  "What's the most useless talent you have?",
  "If your life had a theme song right now, what would it be?",
  "What's a rule you think everyone should follow but almost nobody does?",
];

module.exports = {
  category: "Creative",
  commands: {
    countdown: {
      desc: "Count down to any future date, e.g. !countdown 2026-12-25 Christmas",
      run: async (ctx) => {
        const dateStr = ctx.args[0];
        const label = ctx.args.slice(1).join(" ") || "the date";
        if (!dateStr || !/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return `Usage: ${PREFIX}countdown <YYYY-MM-DD> <label>`;
        const target = new Date(dateStr);
        if (isNaN(target.getTime())) return "⚠️ Invalid date.";
        const diffMs = target - new Date();
        if (diffMs <= 0) return `🎉 ${label} has already happened!`;
        const days = Math.floor(diffMs / 86400000);
        const hours = Math.floor((diffMs % 86400000) / 3600000);
        return `⏳ ${days} days, ${hours} hours until *${label}*`;
      },
    },
    zodiac: {
      desc: "Get your zodiac sign from a birth date, e.g. !zodiac 2000-05-14",
      run: async (ctx) => {
        const dateStr = ctx.args[0];
        if (!dateStr || !/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return `Usage: ${PREFIX}zodiac <YYYY-MM-DD>`;
        const d = new Date(dateStr);
        if (isNaN(d.getTime())) return "⚠️ Invalid date.";
        const month = d.getMonth() + 1;
        const day = d.getDate();
        const signs = [
          [1, 19, "Capricorn"], [2, 18, "Aquarius"], [3, 20, "Pisces"], [4, 19, "Aries"],
          [5, 20, "Taurus"], [6, 20, "Gemini"], [7, 22, "Cancer"], [8, 22, "Leo"],
          [9, 22, "Virgo"], [10, 22, "Libra"], [11, 21, "Scorpio"], [12, 21, "Sagittarius"], [12, 31, "Capricorn"],
        ];
        let sign = "Capricorn";
        for (const [m, endDay, name] of signs) {
          if (month === m && day <= endDay) { sign = name; break; }
          if (month === m && day > endDay) { sign = signs[signs.findIndex((s) => s[2] === name) + 1]?.[2] || "Capricorn"; break; }
        }
        return `♈ Zodiac sign: *${sign}*`;
      },
    },
    newword: {
      desc: "Get a made-up word with a fake definition",
      run: async () => {
        const word = pick(newWordParts.prefixes) + pick(newWordParts.suffixes);
        return `📔 *${word}* (n.)\n${pick(newWordParts.meanings)}`;
      },
    },
    qotd: {
      desc: "Get a question of the day to spark conversation",
      run: async () => `💭 ${pick(qotds)}`,
    },
    plot: {
      desc: "Get a random story plot idea",
      run: async () => `📖 ${pick(plots)}`,
    },
    toast: {
      desc: "Get a random toast/speech opener line",
      run: async () => `🥂 ${pick(toasts)}`,
    },
  },
};