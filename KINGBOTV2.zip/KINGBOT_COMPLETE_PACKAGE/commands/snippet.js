const fs = require('fs');
const path = require('path');

module.exports = {
  category: "owner",
  description: "Manage and fetch reusable code snippets instantly (Owner only)",
  commands: {
    addsnippet: {
      category: "owner",
      description: "Save a code snippet. Usage: .addsnippet <name> | <code>",
      async run(ctx) {
        const { sock, remoteJid, msg, args } = ctx;

        // Strict Owner Verification
        const ownerJid = sock.user?.id || "";
        const ownerPhoneNum = ownerJid ? ownerJid.split("@")[0].split(":")[0] : "";
        const configOwnerNum = process.env.OWNER_NUMBER || "2349073828261";
        const sender = msg.key.participant || remoteJid;
        const isOwner = msg.key.fromMe || (ownerPhoneNum && sender.includes(ownerPhoneNum)) || (configOwnerNum && sender.includes(configOwnerNum));

        if (!isOwner) {
          return { text: "⚠️ *Kingbot Security:* Access denied." };
        }

        const input = args.join(" ").trim();
        if (!input || !input.includes("|")) {
          return { 
            text: "👑 *KingDaniel - Code Vault*\n\n" +
                  "⚠️ *Invalid Format!*\n" +
                  "Please provide a snippet name and the code separated by a `|`.\n\n" +
                  "📌 *Example:*\n" +
                  "`.addsnippet express | const express = require('express');\nconst app = express();\napp.listen(3000);`" 
          };
        }

        const parts = input.split("|");
        const snippetName = parts[0].trim().toLowerCase().replace(/\s+/g, '-');
        const snippetCode = parts.slice(1).join("|").trim();

        if (!snippetName || !snippetCode) {
          return { text: "⚠️ *Kingbot:* Please provide both a valid snippet name and code." };
        }

        const dataDir = path.join(__dirname, '../data');
        if (!fs.existsSync(dataDir)) {
          fs.mkdirSync(dataDir, { recursive: true });
        }

        const snippetFile = path.join(dataDir, 'snippets.json');
        let snippets = {};

        if (fs.existsSync(snippetFile)) {
          try {
            snippets = JSON.parse(fs.readFileSync(snippetFile, 'utf8'));
          } catch (e) {
            snippets = {};
          }
        }

        snippets[snippetName] = {
          code: snippetCode,
          updatedAt: new Date().toISOString()
        };

        fs.writeFileSync(snippetFile, JSON.stringify(snippets, null, 2));

        return {
          text: `👑 *Kingbot*\n\n` +
                `✅ *Snippet Saved Successfully!* \n\n` +
                `🏷️ *Name:* \`${snippetName}\`\n` +
                `🤖 _Retrievable anytime using \`.snippet ${snippetName}\`_`
        };
      }
    },
    snippet: {
      category: "owner",
      description: "Fetch a saved code snippet. Usage: .snippet <name>",
      async run(ctx) {
        const { sock, remoteJid, msg, args } = ctx;

        // Strict Owner Verification
        const ownerJid = sock.user?.id || "";
        const ownerPhoneNum = ownerJid ? ownerJid.split("@")[0].split(":")[0] : "";
        const configOwnerNum = process.env.OWNER_NUMBER || "2349073828261";
        const sender = msg.key.participant || remoteJid;
        const isOwner = msg.key.fromMe || (ownerPhoneNum && sender.includes(ownerPhoneNum)) || (configOwnerNum && sender.includes(configOwnerNum));

        if (!isOwner) {
          return { text: "⚠️ *Kingbot Security:* Access denied." };
        }

        const snippetName = args[0] ? args[0].trim().toLowerCase() : "";
        if (!snippetName) {
          return { text: "👑 *KingDaniel - Code Vault*\n\n⚠️ *Usage:* `.snippet <snippet-name>`\nType `.listsnippets` to browse your saved code templates." };
        }

        const dataDir = path.join(__dirname, '../data');
        const snippetFile = path.join(dataDir, 'snippets.json');

        if (!fs.existsSync(snippetFile)) {
          return { text: "❌ *Kingbot Error:* No snippets database found. Save one using `.addsnippet` first." };
        }

        let snippets = {};
        try {
          snippets = JSON.parse(fs.readFileSync(snippetFile, 'utf8'));
        } catch (e) {
          return { text: "❌ *Kingbot Error:* Failed to read snippet database." };
        }

        if (!snippets[snippetName]) {
          return { text: `❌ *Kingbot Error:* Snippet \`${snippetName}\` not found in vault. Type \`.listsnippets\` to view available codes.` };
        }

        return {
          text: `👑 *Kingbot*\n\n` +
                `📂 *Snippet:* \`${snippetName}\`\n\n` +
                `\`\`\`javascript\n${snippets[snippetName].code}\n\`\`\`\n` +
                `_Powered by Kingbot_`
        };
      }
    },
    listsnippets: {
      category: "owner",
      description: "List all saved code snippets (Owner only)",
      async run(ctx) {
        const { sock, remoteJid, msg } = ctx;

        // Strict Owner Verification
        const ownerJid = sock.user?.id || "";
        const ownerPhoneNum = ownerJid ? ownerJid.split("@")[0].split(":")[0] : "";
        const configOwnerNum = process.env.OWNER_NUMBER || "2349073828261";
        const sender = msg.key.participant || remoteJid;
        const isOwner = msg.key.fromMe || (ownerPhoneNum && sender.includes(ownerPhoneNum)) || (configOwnerNum && sender.includes(configOwnerNum));

        if (!isOwner) {
          return { text: "⚠️ *Kingbot Security:* Access denied." };
        }

        const dataDir = path.join(__dirname, '../data');
        const snippetFile = path.join(dataDir, 'snippets.json');

        if (!fs.existsSync(snippetFile)) {
          return { text: "👑 *Kingbot*\n\n📂 *Snippet Vault is currently empty.* Use `.addsnippet` to save your first code template." };
        }

        let snippets = {};
        try {
          snippets = JSON.parse(fs.readFileSync(snippetFile, 'utf8'));
        } catch (e) {
          snippets = {};
        }

        const keys = Object.keys(snippets);
        if (keys.length === 0) {
          return { text: "👑 *Kingbot*\n\n📂 *Snippet Vault is currently empty.*" };
        }

        let listText = "👑 *Kingbot*\n\n📂 *SAVED CODE SNIPPETS:*\n\n";
        keys.forEach((k, index) => {
          listText += `${index + 1}. \`${k}\`\n`;
        });
        listText += `\n_Type \`.snippet <name>\` to fetch any code._`;

        return { text: listText };
      }
    }
  }
};