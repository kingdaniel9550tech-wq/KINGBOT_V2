module.exports = {
  category: "utility",
  commands: {
    online: {
      description: "Check if a specific WhatsApp user is currently online or view their last seen",
      async run(ctx) {
        const { sock, remoteJid, msg, args } = ctx;
        
        let targetJid = "";
        const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
        const quotedParticipant = contextInfo?.participant;
        const mentionedJids = contextInfo?.mentionedJid;

        if (quotedParticipant) {
          targetJid = quotedParticipant;
        } else if (mentionedJids && mentionedJids.length > 0) {
          targetJid = mentionedJids[0];
        } else if (args[0]) {
          const cleanNum = args[0].replace(/[^0-9]/g, "");
          targetJid = `${cleanNum}@s.whatsapp.net`;
        } else {
          return { 
            text: `⚠️ *Please specify who you want to check!*\n\n` +
                  `*Usage:* \`.online @user\`, reply to their message with \`.online\`, or type \`.online 2348123456789\`` 
          };
        }

        let presenceObj = null;

        try {
          // Temporarily listen for this specific user's presence update
          const presencePromise = new Promise((resolve) => {
            const listener = (update) => {
              if (update.id === targetJid) {
                sock.ev.off('presence.update', listener);
                resolve(update);
              }
            };

            sock.ev.on('presence.update', listener);

            // Request presence stream from WhatsApp
            sock.presenceSubscribe(targetJid).catch(() => {});

            // Timeout after 2.5 seconds if WhatsApp doesn't reply
            setTimeout(() => {
              sock.ev.off('presence.update', listener);
              resolve(null);
            }, 2500);
          });

          presenceObj = await presencePromise;
        } catch (err) {
          console.error("Failed to fetch presence:", err);
        }

        const state = presenceObj?.lastKnownPresence || "unavailable";
        const lastSeenTimestamp = presenceObj?.lastSeen;
        
        let lastSeenTime = "Unavailable / Hidden";
        if (lastSeenTimestamp) {
          lastSeenTime = new Date(lastSeenTimestamp * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        }

        let statusDisplay = "🔴 *Offline / Unavailable*";
        if (state === "available") {
          statusDisplay = "🟢 *Online & Active Right Now*";
        } else if (state === "composing") {
          statusDisplay = "✍️ *Typing a message...*";
        } else if (state === "recording") {
          statusDisplay = "🎤 *Recording audio...*";
        }

        const cleanNumber = targetJid.split('@')[0];

        return {
          text: `🔍 *P R E S E N C E  I N S P E C T O R*\n` +
                `─────────────────────────────\n` +
                `👤 *Target:* @${cleanNumber}\n` +
                `📊 *Status:* ${statusDisplay}\n` +
                `⏱️ *Last Seen:* ${lastSeenTime}\n` +
                `─────────────────────────────\n` +
                `⚡ *Powered by Kingbot*`,
          mentions: [targetJid]
        };
      }
    }
  }
};