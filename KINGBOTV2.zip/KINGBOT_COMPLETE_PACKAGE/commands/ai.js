const { PREFIX } = require("../config");
const { askAI } = require("../aiClient");
const { isOwner } = require("../utils");
const state = require("../state");

// Dedicated robust fetching function for .ai2 using your curl configuration
async function fetchAlternativeAI(prompt) {
  try {
    const res = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-goog-api-key": "AQ.Ab8RN6Jb4RkpS4J6tJZ29jPkcgbmeWd54lEWbDQGWqgBhJ7BRw"
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              { text: "You are Kingbot, an advanced, helpful, and friendly AI assistant created by King Daniel. Keep responses clear, concise, and formatted for WhatsApp.\n\nUser: " + prompt }
            ]
          }
        ]
      })
    });

    const data = await res.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (text && text.trim().length > 0) {
      return text.trim();
    }
    throw new Error(data?.error?.message || "Invalid response structure from Gemini API.");
  } catch (err) {
    throw new Error(err.message);
  }
}

module.exports = {
  category: "AI",
  commands: {
    ai: {
      desc: "Ask the AI a question, e.g. !ai what's the capital of France?",
      run: async (ctx) => {
        const prompt = ctx.args.join(" ");
        if (!prompt) return `Usage: ${PREFIX}ai <question>`;
        try {
          const reply = await askAI([{ role: "user", content: prompt }]);
          return `🤖 ${reply}`;
        } catch (err) {
          return `⚠️ ${err.message}`;
        }
      },
    },
    ai2: {
      desc: "Ask the secondary AI engine with Kingbot branding, e.g. !ai2 Hello",
      run: async (ctx) => {
        const prompt = ctx.args.join(" ");
        if (!prompt) return `Usage: ${PREFIX}ai2 <question>`;
        try {
          const reply = await fetchAlternativeAI(prompt);
          
          return `👑 *KINGBOT AI* 👑\n\n` +
            `${reply}\n\n` +
            `👤 *👑✨️👑:* Kingbot Official AI\n` +
            `🔗 *Join our WhatsApp Channel:* https://whatsapp.com/channel/0029Vaj1zo6HVvTV3Sd4zd2k`;
        } catch (err) {
          return `👑 *KINGBOT AI* 👑\n\n` +
            `⚠️ Error: ${err.message}\n\n` +
            `👤 *👑✨️👑:* Kingbot Official AI\n` +
            `🔗 *Join our WhatsApp Channel:* https://whatsapp.com/channel/0029Vaj1zo6HVvTV3Sd4zd2k`;
        }
      },
    },
    aichat: {
      desc: "(Owner only) Toggle AI auto-chat for this conversation: !aichat on | off",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const choice = (ctx.args[0] || "").toLowerCase();
        if (choice !== "on" && choice !== "off") return `Usage: ${PREFIX}aichat <on|off>`;
        if (choice === "on") state.aiChatChats.add(ctx.remoteJid);
        else state.aiChatChats.delete(ctx.remoteJid);
        return `✅ AI auto-chat *${choice === "on" ? "enabled" : "disabled"}* for this chat.\n${choice === "on" ? "Any non-command message here now gets an AI reply." : ""}`;
      },
    },
  },
};