const fs = require('fs');
const path = require('path');

const settingsFile = path.join(__dirname, '../data/antilink_settings.json');
const warningsFile = path.join(__dirname, '../data/antilink_warnings.json');

function loadJson(file) {
  try {
    if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {}
  return {};
}

function saveJson(file, data) {
  try {
    const dir = path.dirname(file);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
  } catch (e) {}
}

let settings = loadJson(settingsFile);
let warnings = loadJson(warningsFile);

module.exports = {
  category: "Group Admin",
  commands: {
    antilink: {
      description: "Configure anti-link protection mode (delete, warn, kick, warn3, off)",
      run: async (ctx) => {
        const { remoteJid, args } = ctx;
        if (!remoteJid.endsWith('@g.us')) {
          return "❌ This command can only be used in groups.";
        }
        
        const action = (args[0] || '').toLowerCase();
        const validModes = ['off', 'delete', 'warn', 'kick', 'warn3'];

        if (!validModes.includes(action)) {
          const currentMode = settings[remoteJid] || 'off';
          return `📌 *Anti-Link Configuration*\n` +
                 `Current Mode: *${currentMode.toUpperCase()}*\n\n` +
                 `*Available Options:*\n` +
                 `• \`.antilink delete\` - Delete links only\n` +
                 `• \`.antilink warn\` - Delete and warn user\n` +
                 `• \`.antilink kick\` - Delete and kick immediately\n` +
                 `• \`.antilink warn3\` - Kick after 3 warnings\n` +
                 `• \`.antilink off\` - Disable anti-link`;
        }

        settings[remoteJid] = action;
        saveJson(settingsFile, settings);
        return `🛡️ Anti-link mode successfully updated to: *${action.toUpperCase()}*`;
      }
    }
  },

  handleAntiLink: async (ctx) => {
    const { sock, msg, remoteJid, sender, isFromMe, body } = ctx;
    if (!remoteJid.endsWith('@g.us') || isFromMe) return;
    
    const mode = settings[remoteJid] || 'off';
    if (mode === 'off') return;

    const linkRegex = /(https?:\/\/[^\s]+|www\.[^\s]+|[a-zA-Z0-9][-a-zA-Z0-9]*\.[a-zA-Z]{2,}(\/[^\s]*)?|chat\.whatsapp\.com\/[^\s]+)/i;

    if (linkRegex.test(body)) {
      const userId = sender.split('@')[0];
      try {
        // Always delete the link message first
        await sock.sendMessage(remoteJid, { delete: msg.key });

        if (mode === 'delete') {
          await sock.sendMessage(remoteJid, { 
            text: `⚠️ @${userId}, links are not allowed in this group!`,
            mentions: [sender]
          });
        } else if (mode === 'warn') {
          await sock.sendMessage(remoteJid, { 
            text: `⚠️ @${userId}, warning! Link sharing is strictly prohibited.`,
            mentions: [sender]
          });
        } else if (mode === 'kick') {
          await sock.sendMessage(remoteJid, { 
            text: `🚫 @${userId} has been kicked for sharing links!`,
            mentions: [sender]
          });
          await sock.groupParticipantsUpdate(remoteJid, [sender], "remove");
        } else if (mode === 'warn3') {
          if (!warnings[remoteJid]) warnings[remoteJid] = {};
          if (!warnings[remoteJid][sender]) warnings[remoteJid][sender] = 0;

          warnings[remoteJid][sender] += 1;
          const count = warnings[remoteJid][sender];

          if (count >= 3) {
            warnings[remoteJid][sender] = 0; // Reset warnings after kick
            saveJson(warningsFile, warnings);
            await sock.sendMessage(remoteJid, { 
              text: `🚫 @${userId} reached 3 link warnings and has been removed from the group!`,
              mentions: [sender]
            });
            await sock.groupParticipantsUpdate(remoteJid, [sender], "remove");
          } else {
            saveJson(warningsFile, warnings);
            await sock.sendMessage(remoteJid, { 
              text: `⚠️ @${userId}, link warning (${count}/3)! Further link sharing will result in a kick.`,
              mentions: [sender]
            });
          }
        }
      } catch (e) {
        console.error("Anti-link execution error:", e);
      }
    }
  }
};