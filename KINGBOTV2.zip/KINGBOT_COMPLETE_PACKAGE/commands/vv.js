const { downloadMediaMessage } = require('@whiskeysockets/baileys');

module.exports = {
  category: "Tools",
  commands: {
    vv: {
      desc: "Retrieve hidden View Once photos, videos, or voice notes by replying to them",
      run: async (ctx) => {
        const { msg } = ctx;
        const conn = ctx.client || ctx.sock || ctx.conn;
        const chatId = ctx.from || ctx.chat || msg?.key?.remoteJid || msg?.chatId || msg?.from;

        const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        
        if (!quotedMsg) {
          return "⚠️ Please reply to a View Once photo, video, or voice note with `.vv`!";
        }

        // Extract media message structure (handles images, videos, and voice notes)
        let mediaMessage = 
          quotedMsg.imageMessage || 
          quotedMsg.videoMessage || 
          quotedMsg.audioMessage ||
          quotedMsg.viewOnceMessage?.message?.imageMessage || 
          quotedMsg.viewOnceMessage?.message?.videoMessage ||
          quotedMsg.viewOnceMessage?.message?.audioMessage ||
          quotedMsg.viewOnceMessageV2?.message?.imageMessage ||
          quotedMsg.viewOnceMessageV2?.message?.videoMessage ||
          quotedMsg.viewOnceMessageV2?.message?.audioMessage;

        if (!mediaMessage) {
          return "❌ The quoted message is not a valid View Once media or audio file!";
        }

        try {
          if (conn && conn.sendMessage && chatId) {
            await conn.sendMessage(chatId, { text: "👁️ *Kingbot View Once Extractor*\n⏳ Unlocking content..." }, { quoted: msg });
          }

          const isVideo = quotedMsg.videoMessage || quotedMsg.viewOnceMessage?.message?.videoMessage || quotedMsg.viewOnceMessageV2?.message?.videoMessage;
          const isAudio = quotedMsg.audioMessage || quotedMsg.viewOnceMessage?.message?.audioMessage || quotedMsg.viewOnceMessageV2?.message?.audioMessage || mediaMessage.ptt;
          
          let mediaType = 'image';
          if (isVideo) mediaType = 'video';
          if (isAudio) mediaType = 'audio';

          const wrappedMessage = {
            key: { remoteJid: chatId },
            message: { [`${mediaType}Message`]: mediaMessage }
          };

          const mediaBuffer = await downloadMediaMessage(
            wrappedMessage,
            'buffer',
            {},
            { 
              logger: console, 
              reuploadRequest: conn.updateMediaMessage 
            }
          );

          if (!mediaBuffer) {
            return "❌ Failed to download the View Once media buffer.";
          }

          // If it's a voice note, send it back as an active PTT audio waveform
          if (isAudio) {
            await conn.sendMessage(chatId, {
              audio: mediaBuffer,
              mimetype: mediaMessage.mimetype || 'audio/ogg; codecs=opus',
              ptt: true
            }, { quoted: msg });
            return;
          }

          const originalCaption = mediaMessage.caption || "None";
          const caption = `👁️ *Kingbot View Once Recovery*\n\n*Original Caption:* ${originalCaption}\n\n🤖 _Powered by Kingbot`;

          await conn.sendMessage(chatId, {
            [mediaType]: mediaBuffer,
            caption: caption
          }, { quoted: msg });

          return;

        } catch (error) {
          console.error("View Once extraction error:", error);
          return `❌ Error unlocking media: ${error.message}`;
        }
      },
    },
  },
};