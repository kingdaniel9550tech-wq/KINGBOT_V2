const { PREFIX } = require("../config");
const { isOwner } = require("../utils");
const state = require("../state");

let scheduleIdCounter = 1;

module.exports = {
  category: "Automation",
  commands: {
    welcome: {
      desc: "Toggle welcome/goodbye messages for this group: !welcome on | off",
      run: async (ctx) => {
        if (!ctx.remoteJid.endsWith("@g.us")) return "⚠️ This command only works in groups.";
        const choice = (ctx.args[0] || "").toLowerCase();
        if (choice !== "on" && choice !== "off") return `Usage: ${PREFIX}welcome <on|off>`;
        state.groupWelcome[ctx.remoteJid] = choice === "on";
        return `✅ Welcome/goodbye messages turned *${choice}* for this group.`;
      },
    },
    autoreply: {
      desc: "(Owner only) Toggle keyword auto-replies bot-wide: !autoreply on | off",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const choice = (ctx.args[0] || "").toLowerCase();
        if (choice !== "on" && choice !== "off") return `Usage: ${PREFIX}autoreply <on|off>`;
        state.autoReplyEnabled = choice === "on";
        return `✅ Auto-reply turned *${choice}*.`;
      },
    },
    autoreact: {
      desc: "(Owner only) Toggle auto-reacting to messages: !autoreact on [emoji] | off",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const choice = (ctx.args[0] || "").toLowerCase();
        if (choice !== "on" && choice !== "off") return `Usage: ${PREFIX}autoreact <on [emoji]|off>`;
        state.autoReactEnabled = choice === "on";
        if (choice === "on" && ctx.args[1]) state.autoReactEmoji = ctx.args[1];
        return `✅ Auto-react turned *${choice}*${choice === "on" ? ` (emoji: ${state.autoReactEmoji})` : ""}.`;
      },
    },
    schedule: {
      desc: "(Owner only) Schedule a daily message here: !schedule add <HH:MM> <message> | !schedule list | !schedule remove <id>",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const sub = (ctx.args[0] || "").toLowerCase();

        if (sub === "add") {
          const time = ctx.args[1];
          const text = ctx.args.slice(2).join(" ");
          if (!/^\d{2}:\d{2}$/.test(time || "") || !text) {
            return `Usage: ${PREFIX}schedule add <HH:MM> <message>\n(24-hour format, e.g. 09:00 or 21:30)`;
          }
          const id = scheduleIdCounter++;
          state.schedules.push({ id, jid: ctx.remoteJid, time, text, lastFired: null });
          return `✅ Scheduled daily message #${id} at ${time} for this chat.\n(Note: schedules are stored in memory and lost if the bot restarts.)`;
        }

        if (sub === "list") {
          if (!state.schedules.length) return "No active schedules.";
          return "📅 *Schedules*\n" + state.schedules
            .map((s) => `#${s.id} — ${s.time} — ${s.jid === ctx.remoteJid ? "this chat" : s.jid} — "${s.text}"`)
            .join("\n");
        }

        if (sub === "remove") {
          const id = parseInt(ctx.args[1]);
          const idx = state.schedules.findIndex((s) => s.id === id);
          if (idx === -1) return `No schedule with id #${id}. Use ${PREFIX}schedule list to see active ones.`;
          state.schedules.splice(idx, 1);
          return `✅ Removed schedule #${id}.`;
        }

        return `Usage: ${PREFIX}schedule <add|list|remove> ...`;
      },
    },
  },
};
