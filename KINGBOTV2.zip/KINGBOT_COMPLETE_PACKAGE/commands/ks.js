const { PREFIX } = require("../config");
const { isOwner } = require("../utils");
const fs = require("fs");
const path = require("path");

// ==========================================
// KINGBOT AI HUB - PERSISTENT STORAGE SETUP
// ==========================================
const configFilePath = path.join(__dirname, "../group_configs.json");
const groupUserTracker = new Map();
const slowmodeTracker = new Map();
const pendingCaptchas = new Map();

// Load saved configurations from disk on startup
let groupConfigs = new Map();
try {
  if (fs.existsSync(configFilePath)) {
    const rawData = fs.readFileSync(configFilePath, "utf8");
    const parsedData = JSON.parse(rawData);
    for (const [jid, conf] of Object.entries(parsedData)) {
      conf.vipList = new Set(conf.vipList || []);
      groupConfigs.set(jid, conf);
    }
  }
} catch (err) {
  console.error("KingBot Storage Load Error:", err);
}

// Save configurations to disk whenever changes occur
function saveGroupConfigs() {
  try {
    const plainObj = {};
    for (const [jid, conf] of groupConfigs.entries()) {
      plainObj[jid] = {
        ...conf,
        vipList: Array.from(conf.vipList)
      };
    }
    fs.writeFileSync(configFilePath, JSON.stringify(plainObj, null, 2));
  } catch (err) {
    console.error("KingBot Storage Save Error:", err);
  }
}

function getGroupConfig(jid) {
  if (!groupConfigs.has(jid)) {
    groupConfigs.set(jid, {
      thresholdMsgs: 3,
      thresholdWindowSec: 10,
      slowmodeSec: 0,
      anticrash: false,
      antiforward: false,
      antilink: false,
      welcome: false,
      captcha: false,
      quarantineNewMembers: false,
      panic: false,
      vipList: new Set(),
      schedule: { active: false, lock: null, unlock: null, lastState: null }
    });
    saveGroupConfigs();
  }
  return groupConfigs.get(jid);
}

// Admin Audit Logger
async function logAuditAction(sock, jid, actionDescription) {
  try {
    const timestamp = new Date().toLocaleString();
    console.log(`[AUDIT] [${jid}] ${actionDescription}`);
  } catch (e) {
    console.error("Audit Log Error:", e);
  }
}

async function checkBotAdmin(sock, jid) {
  try {
    const meta = await sock.groupMetadata(jid);
    const myIds = [
      sock.user?.id,
      sock.user?.lid,
      sock.authState?.creds?.me?.id,
      sock.authState?.creds?.me?.lid,
    ].filter(Boolean).map(id => id.replace(/:\d+@/, "@"));
    
    const me = meta.participants.find((p) => myIds.includes(p.id.replace(/:\d+@/, "@")));
    return me && (me.admin === "admin" || me.admin === "superadmin");
  } catch {
    return false;
  }
}

async function checkUserAdmin(ctx) {
  if (isOwner(ctx)) return true;
  try {
    const meta = await ctx.sock.groupMetadata(ctx.remoteJid);
    const rawSender = ctx.sender || ctx.msg?.key?.participant || ctx.remoteJid;
    const sender = rawSender.replace(/:\d+@/, "@");
    const participant = meta.participants.find(p => p.id.replace(/:\d+@/, "@").includes(sender.split("@")[0]));
    return participant && (participant.admin === "admin" || participant.admin === "superadmin");
  } catch {
    return false;
  }
}

// ==========================================
// BULLETPROOF TIME-WINDOW SCHEDULER
// ==========================================
let globalSock = null;
let isSchedulerInitialized = false;

function isTimeInRange(current, start, end) {
  if (start < end) {
    return current >= start && current < end;
  } else {
    return current >= start || current < end;
  }
}

function initKsScheduler(sock) {
  if (sock) globalSock = sock;
  if (isSchedulerInitialized) return;
  isSchedulerInitialized = true;

  setInterval(async () => {
    if (!globalSock) return;

    const now = new Date();
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    const currentTime = `${hours}:${minutes}`;

    for (const [chatJid, config] of groupConfigs.entries()) {
      if (!config.schedule || !config.schedule.active || !config.schedule.lock || !config.schedule.unlock) continue;

      try {
        const shouldBeLocked = isTimeInRange(currentTime, config.schedule.lock, config.schedule.unlock);
        const targetState = shouldBeLocked ? "locked" : "unlocked";

        if (config.schedule.lastState !== targetState) {
          const botIsAdmin = await checkBotAdmin(globalSock, chatJid);
          if (botIsAdmin) {
            if (shouldBeLocked) {
              await globalSock.groupSettingUpdate(chatJid, "announcement");
              await globalSock.sendMessage(chatJid, {
                text: `🌙 *KINGBOT SECURITY*\n\nTime window active (${config.schedule.lock} - ${config.schedule.unlock}). Group has been locked automatically.`
              });
              logAuditAction(globalSock, chatJid, "Auto-locked group via night schedule.");
            } else {
              await globalSock.groupSettingUpdate(chatJid, "not_announcement");
              await globalSock.sendMessage(chatJid, {
                text: `☀️ *KINGBOT SECURITY*\n\nScheduled time reached. Group has been reopened. Everyone can chat now!`
              });
              logAuditAction(globalSock, chatJid, "Auto-unlocked group via night schedule.");
            }
            config.schedule.lastState = targetState;
            saveGroupConfigs();
          }
        }
      } catch (err) {
        console.error(`KingBot Schedule Error for ${chatJid}:`, err.message);
      }
    }
  }, 60 * 1000);
}

function parseDuration(str) {
  if (!str) return null;
  const match = str.match(/^(\d+)([smh])?$/i);
  if (!match) return null;
  const val = parseInt(match[1]);
  const unit = (match[2] || "m").toLowerCase();

  if (unit === "s") return { ms: val * 1000, label: `${val} second(s)` };
  if (unit === "h") return { ms: val * 60 * 60 * 1000, label: `${val} hour(s)` };
  return { ms: val * 60 * 1000, label: `${val} minute(s)` };
}

module.exports = {
  category: "KINGBOT AI HUB",
  init: initKsScheduler,
  commands: {
    ks: {
      desc: "👑 KingBot AI Hub - Elite Security Suite & Moderation Manager",
      run: async (ctx) => {
        initKsScheduler(ctx.sock);

        const isGroup = ctx.remoteJid.endsWith("@g.us");
        if (!isGroup) return "⚠️ *KINGBOT SECURITY:* Group moderation features are only available in group chats.";

        const args = ctx.args || [];
        const subCommand = (args[0] || "").toLowerCase();
        const config = getGroupConfig(ctx.remoteJid);

        if (!subCommand || subCommand === "help") {
          return `👑 *KINGBOT ELITE SECURITY* 👑\n\n` +
                 `*Core & Protection:*\n` +
                 `• \`${PREFIX}ks status\` - Active security dashboard\n` +
                 `• \`${PREFIX}ks threshold <msgs> <sec>\` - Anti-spam limit\n` +
                 `• \`${PREFIX}ks slowmode <sec|off>\` - Chat cooldown delay\n` +
                 `• \`${PREFIX}ks antilink <on|off>\` - Block chat/group invite links\n` +
                 `• \`${PREFIX}ks anticrash <on|off>\` - Block text crash bugs\n` +
                 `• \`${PREFIX}ks antiforward <on|off>\` - Block mass forwarded posts\n\n` +
                 `*Advanced Controls:*\n` +
                 `• \`${PREFIX}ks captcha <on|off>\` - Math verification\n` +
                 `• \`${PREFIX}ks quarantine <on|off>\` - Read-only mode for unverified joins\n` +
                 `• \`${PREFIX}ks lockfor <time>\` - Timed lockdown (\`30m\`, \`2h\`)\n` +
                 `• \`${PREFIX}ks panic <on|off>\` - Emergency group shield\n` +
                 `• \`${PREFIX}ks vip <add|remove|list> @user\` - Trusted members\n` +
                 `• \`${PREFIX}ks schedule <HH:MM> <HH:MM>|off\` - Night auto-lock\n` +
                 `• \`${PREFIX}ks welcome <on|off>\` - Welcome banner\n\n` +
                 `⚡ _Powered by KingBot_`;
        }

        const isAdmin = await checkUserAdmin(ctx);
        if (!isAdmin) return "⚠️ *KINGBOT SECURITY:* Admin permissions required to alter security settings.";

        if (subCommand === "status") {
          return `🛡️ *KINGBOT SECURITY DASHBOARD* 🛡️\n` +
                 `━━━━━━━━━━━━━━━━━━━━━━\n` +
                 `• *Anti-Spam:* ${config.thresholdMsgs} msgs in ${config.thresholdWindowSec}s\n` +
                 `• *Slowmode:* ${config.slowmodeSec > 0 ? `${config.slowmodeSec}s delay` : "Disabled"}\n` +
                 `• *Anti-Link Shield:* ${config.antilink ? "✅ Enabled" : "❌ Disabled"}\n` +
                 `• *Panic Mode:* ${config.panic ? "🚨 ACTIVE" : "Inactive"}\n` +
                 `• *Captcha Verification:* ${config.captcha ? "✅ Enabled" : "❌ Disabled"}\n` +
                 `• *Quarantine Zone:* ${config.quarantineNewMembers ? "✅ Enabled" : "❌ Disabled"}\n` +
                 `• *Anti-Crash Shield:* ${config.anticrash ? "✅ Enabled" : "❌ Disabled"}\n` +
                 `• *Anti-Forward Shield:* ${config.antiforward ? "✅ Enabled" : "❌ Disabled"}\n` +
                 `• *VIP Trusted Users:* ${config.vipList.size} member(s)\n` +
                 `• *Night Schedule:* ${config.schedule.active ? `${config.schedule.lock} - ${config.schedule.unlock}` : "Disabled"}\n` +
                 `━━━━━━━━━━━━━━━━━━━━━━\n` +
                 `⚡ _Powered by KingBot_`;
        }

        if (subCommand === "antilink") {
          const mode = args[1]?.toLowerCase();
          if (mode === "on") {
            config.antilink = true;
            saveGroupConfigs();
            logAuditAction(ctx.sock, ctx.remoteJid, `Enabled Anti-Link shield.`);
            return `🛡️ *KINGBOT SECURITY:* Anti-Link filter is now *ENABLED*. Group invite links and external URLs will be blocked.`;
          } else if (mode === "off") {
            config.antilink = false;
            saveGroupConfigs();
            logAuditAction(ctx.sock, ctx.remoteJid, `Disabled Anti-Link shield.`);
            return `🛡️ *KINGBOT SECURITY:* Anti-Link filter is now *DISABLED*.`;
          }
          return `⚠️ *Usage:* \`${PREFIX}ks antilink <on|off>\``;
        }

        if (subCommand === "quarantine") {
          const mode = args[1]?.toLowerCase();
          if (mode === "on") {
            config.quarantineNewMembers = true;
            saveGroupConfigs();
            logAuditAction(ctx.sock, ctx.remoteJid, `Enabled Quarantine Zone.`);
            return `🛡️ *KINGBOT SECURITY:* Quarantine Zone is *ENABLED*. New members are restricted to read-only mode until they pass captcha verification.`;
          } else if (mode === "off") {
            config.quarantineNewMembers = false;
            saveGroupConfigs();
            logAuditAction(ctx.sock, ctx.remoteJid, `Disabled Quarantine Zone.`);
            return `🛡️ *KINGBOT SECURITY:* Quarantine Zone is *DISABLED*.`;
          }
          return `⚠️ *Usage:* \`${PREFIX}ks quarantine <on|off>\``;
        }

        if (subCommand === "threshold") {
          const msgs = parseInt(args[1]);
          const secs = parseInt(args[2]);
          if (!msgs || !secs || msgs < 2 || secs < 3) {
            return `⚠️ *Usage:* \`${PREFIX}ks threshold <messages> <seconds>\`\nExample: \`${PREFIX}ks threshold 4 10\``;
          }
          config.thresholdMsgs = msgs;
          config.thresholdWindowSec = secs;
          saveGroupConfigs();
          logAuditAction(ctx.sock, ctx.remoteJid, `Updated anti-spam threshold to ${msgs} msgs in ${secs}s.`);
          return `✅ *KINGBOT SECURITY:* Anti-spam limit updated to *${msgs} messages* within *${secs} seconds*.`;
        }

        if (subCommand === "slowmode") {
          const opt = args[1]?.toLowerCase();
          if (opt === "off" || opt === "0") {
            config.slowmodeSec = 0;
            saveGroupConfigs();
            logAuditAction(ctx.sock, ctx.remoteJid, `Disabled slowmode.`);
            return `✅ *KINGBOT SECURITY:* Group slowmode has been *disabled*.`;
          }
          const secs = parseInt(opt);
          if (!secs || secs <= 0) return `⚠️ *Usage:* \`${PREFIX}ks slowmode <seconds|off>\``;
          config.slowmodeSec = secs;
          saveGroupConfigs();
          logAuditAction(ctx.sock, ctx.remoteJid, `Enabled slowmode with ${secs}s delay.`);
          return `⏳ *KINGBOT SECURITY:* Slowmode enabled! Non-admin members must wait *${secs} second(s)* between messages.`;
        }

        if (subCommand === "lockfor") {
          const durationObj = parseDuration(args[1]);
          if (!durationObj || durationObj.ms <= 0) {
            return `⚠️ *Invalid time format!*\n\n*Usage:* \`${PREFIX}ks lockfor <time>\`\n*Examples:* \`${PREFIX}ks lockfor 30m\` (minutes), \`2h\` (hours), or \`45s\` (seconds)`;
          }

          const botIsAdmin = await checkBotAdmin(ctx.sock, ctx.remoteJid);
          if (!botIsAdmin) return "❌ *KINGBOT ERROR:* I need Admin privileges to lock group settings!";

          try {
            await ctx.sock.groupSettingUpdate(ctx.remoteJid, "announcement");
            logAuditAction(ctx.sock, ctx.remoteJid, `Timed lock initiated for ${durationObj.label}.`);
            await ctx.sock.sendMessage(ctx.remoteJid, {
              text: `🔒 *KINGBOT SECURITY*\n\nThis group has been temporarily closed for *${durationObj.label}*. It will automatically reopen once time expires.`
            });

            setTimeout(async () => {
              try {
                await ctx.sock.groupSettingUpdate(ctx.remoteJid, "not_announcement");
                logAuditAction(ctx.sock, ctx.remoteJid, `Timed lock expired after ${durationObj.label}. Group reopened.`);
                await ctx.sock.sendMessage(ctx.remoteJid, {
                  text: `🔓 *KINGBOT SECURITY*\n\nThe ${durationObj.label} timer has finished. Group chat is open again!`
                });
              } catch (e) {
                console.error("KingBot Lockdown Expiry Error:", e);
              }
            }, durationObj.ms);

            return null;
          } catch (err) {
            return "❌ *KINGBOT ERROR:* Failed to lock the group. Check permissions.";
          }
        }

        if (subCommand === "panic") {
          const mode = args[1]?.toLowerCase();
          if (mode === "on") {
            config.panic = true;
            config.slowmodeSec = 10;
            saveGroupConfigs();
            logAuditAction(ctx.sock, ctx.remoteJid, `🚨 PANIC MODE ACTIVATED.`);
            const botIsAdmin = await checkBotAdmin(ctx.sock, ctx.remoteJid);
            if (botIsAdmin) {
              await ctx.sock.groupSettingUpdate(ctx.remoteJid, "announcement").catch(() => {});
            }
            return `🚨 *KINGBOT EMERGENCY PANIC ACTIVATED!* 🚨\n\nGroup locked down and strict security filters engaged!`;
          } else if (mode === "off") {
            config.panic = false;
            config.slowmodeSec = 0;
            saveGroupConfigs();
            logAuditAction(ctx.sock, ctx.remoteJid, `❇️ PANIC MODE DEACTIVATED.`);
            const botIsAdmin = await checkBotAdmin(ctx.sock, ctx.remoteJid);
            if (botIsAdmin) {
              await ctx.sock.groupSettingUpdate(ctx.remoteJid, "not_announcement").catch(() => {});
            }
            return `❇️ *KINGBOT PANIC DEACTIVATED:* Group returned to normal operation.`;
          }
          return `⚠️ *Usage:* \`${PREFIX}ks panic <on|off>\``;
        }

        if (subCommand === "captcha") {
          const mode = args[1]?.toLowerCase();
          if (mode === "on") {
            config.captcha = true;
            saveGroupConfigs();
            logAuditAction(ctx.sock, ctx.remoteJid, `Enabled Captcha verification.`);
            return `🛡️ *KINGBOT SECURITY:* Captcha verification is now *ENABLED*.`;
          } else if (mode === "off") {
            config.captcha = false;
            saveGroupConfigs();
            logAuditAction(ctx.sock, ctx.remoteJid, `Disabled Captcha verification.`);
            return `🛡️ *KINGBOT SECURITY:* Captcha verification is now *DISABLED*.`;
          }
          return `⚠️ *Usage:* \`${PREFIX}ks captcha <on|off>\``;
        }

        if (subCommand === "anticrash") {
          const mode = args[1]?.toLowerCase();
          if (mode === "on") {
            config.anticrash = true;
            saveGroupConfigs();
            return `🛡️ *KINGBOT SECURITY:* Anti-Crash text filter is now *ENABLED*.`;
          } else if (mode === "off") {
            config.anticrash = false;
            saveGroupConfigs();
            return `🛡️ *KINGBOT SECURITY:* Anti-Crash text filter is now *DISABLED*.`;
          }
          return `⚠️ *Usage:* \`${PREFIX}ks anticrash <on|off>\``;
        }

        if (subCommand === "antiforward") {
          const mode = args[1]?.toLowerCase();
          if (mode === "on") {
            config.antiforward = true;
            saveGroupConfigs();
            return `🛡️ *KINGBOT SECURITY:* Mass-Forwarded message shield is now *ENABLED*.`;
          } else if (mode === "off") {
            config.antiforward = false;
            saveGroupConfigs();
            return `🛡️ *KINGBOT SECURITY:* Mass-Forwarded message shield is now *DISABLED*.`;
          }
          return `⚠️ *Usage:* \`${PREFIX}ks antiforward <on|off>\``;
        }

        if (subCommand === "vip") {
          const action = args[1]?.toLowerCase();
          const target = ctx.msg?.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || args[2];

          if (action === "list") {
            if (config.vipList.size === 0) return `📋 *KINGBOT SECURITY:* No VIP users added yet.`;
            let text = `👑 *KINGBOT VIP TRUSTED USERS* 👑\n\n`;
            config.vipList.forEach(user => text += `• @${user.split("@")[0]}\n`);
            return ctx.sock.sendMessage(ctx.remoteJid, { text, mentions: Array.from(config.vipList) });
          }

          if (!target) return `⚠️ *Usage:* \`${PREFIX}ks vip <add|remove|list> @user\``;
          const cleanJid = target.replace(/:\d+@/, "@");

          if (action === "add") {
            config.vipList.add(cleanJid);
            saveGroupConfigs();
            logAuditAction(ctx.sock, ctx.remoteJid, `Added VIP immunity to @${cleanJid.split("@")[0]}`);
            return `🌟 *KINGBOT SECURITY:* Granted VIP security immunity to @${cleanJid.split("@")[0]}!`;
          } else if (action === "remove") {
            config.vipList.delete(cleanJid);
            saveGroupConfigs();
            logAuditAction(ctx.sock, ctx.remoteJid, `Removed VIP status from @${cleanJid.split("@")[0]}`);
            return `🗑️ *KINGBOT SECURITY:* Removed VIP status from @${cleanJid.split("@")[0]}.`;
          }
          return `⚠️ *Usage:* \`${PREFIX}ks vip <add|remove|list>\``;
        }

        if (subCommand === "schedule") {
          const lockTime = args[1];
          const unlockTime = args[2];

          if (lockTime === "off") {
            config.schedule.active = false;
            config.schedule.lastState = null;
            saveGroupConfigs();
            logAuditAction(ctx.sock, ctx.remoteJid, `Disabled Night Schedule.`);
            return `🌙 *KINGBOT SECURITY:* Auto-lock Night Schedule has been *disabled*.`;
          }

          if (!lockTime || !unlockTime || !lockTime.includes(":") || !unlockTime.includes(":")) {
            return `⚠️ *Usage:* \`${PREFIX}ks schedule <lockHH:MM> <unlockHH:MM>\` (or \`${PREFIX}ks schedule off\`)\nExample: \`${PREFIX}ks schedule 23:00 06:00\``;
          }

          config.schedule = { active: true, lock: lockTime, unlock: unlockTime, lastState: null };
          saveGroupConfigs();
          logAuditAction(ctx.sock, ctx.remoteJid, `Set Night Schedule: Lock at ${lockTime}, Unlock at ${unlockTime}`);
          return `🌙 *KINGBOT SECURITY:* Group will auto-lock at *${lockTime}* and reopen at *${unlockTime}* every day.`;
        }

        if (subCommand === "welcome") {
          const mode = args[1]?.toLowerCase();
          if (mode === "on") {
            config.welcome = true;
            saveGroupConfigs();
            return `🎉 *KINGBOT SECURITY:* Automated Welcome Banner for new members is now *ENABLED*.`;
          } else if (mode === "off") {
            config.welcome = false;
            saveGroupConfigs();
            return `🎉 *KINGBOT SECURITY:* Automated Welcome Banner is now *DISABLED*.`;
          }
          return `⚠️ *Usage:* \`${PREFIX}ks welcome <on|off>\``;
        }

        return `⚠️ Unknown option. Type \`${PREFIX}ks help\` for commands.`;
      }
    }
  },

  autoRaidCheck: async function (ctx) {
    const isGroup = ctx.remoteJid.endsWith("@g.us");
    const rawSender = ctx.sender || ctx.msg?.key?.participant || ctx.remoteJid;
    const sender = rawSender.replace(/:\d+@/, "@");
    const isFromMe = ctx.msg?.key?.fromMe === true;

    if (isFromMe || sender.includes(ctx.sock.user?.id?.split(":")[0])) return;

    const config = getGroupConfig(ctx.remoteJid);

    // Quarantine Zone Check: If member is pending captcha verification, delete their messages (read-only mode)
    const captchaKey = `${ctx.remoteJid}_${sender}`;
    if (config.quarantineNewMembers && pendingCaptchas.has(captchaKey)) {
      try {
        await ctx.sock.sendMessage(ctx.remoteJid, { delete: ctx.msg.key });
      } catch {}
    }

    // Handle Captcha Answer
    if (pendingCaptchas.has(captchaKey)) {
      const captchaData = pendingCaptchas.get(captchaKey);
      const textMsg = (ctx.msg?.message?.conversation || ctx.msg?.message?.extendedTextMessage?.text || "").trim();
      
      if (textMsg === captchaData.answer) {
        clearTimeout(captchaData.timeout);
        pendingCaptchas.delete(captchaKey);
        await ctx.sock.sendMessage(ctx.remoteJid, {
          text: `✅ *KINGBOT VERIFICATION PASSED!* Welcome to the group @${sender.split("@")[0]}!`,
          mentions: [sender]
        });
        return;
      }
    }

    const scamKeywords = [
      "double your money", "crypto investment", "send your code", 
      "loan without collateral", "win cash prize", "telegram giveaway",
      "whatsapp verification code", "invest ₦", "invest $"
    ];
    const textLower = (ctx.msg?.message?.conversation || ctx.msg?.message?.extendedTextMessage?.text || "").toLowerCase();

    // Scam Catcher
    if (scamKeywords.some(keyword => textLower.includes(keyword))) {
      try {
        await ctx.sock.sendMessage(ctx.remoteJid, { delete: ctx.msg.key });
        if (isGroup) {
          const botIsAdmin = await checkBotAdmin(ctx.sock, ctx.remoteJid);
          if (botIsAdmin) {
            await ctx.sock.groupParticipantsUpdate(ctx.remoteJid, [sender], "remove");
          }
        }
        try { await ctx.sock.updateBlockStatus(sender, 'block'); } catch {}

        const targetJid = isGroup ? ctx.remoteJid : sender;
        await ctx.sock.sendMessage(targetJid, {
          text: `🚨 *KINGBOT ABSOLUTE SHIELD ENGAGED* 🚨\n\n` +
                `@${sender.split("@")[0]} attempted a scam/phishing attack. They have been permanently removed, flagged, and blocked! 🛡️`,
          mentions: [sender]
        });
        return;
      } catch (err) {
        console.error("KingBot Scam Catcher Error:", err);
      }
    }

    // Anti-Link Shield
    if (config.antilink && isGroup) {
      const urlRegex = /(https?:\/\/[^\s]+|chat\.whatsapp\.com\/[^\s]+|t\.me\/[^\s]+)/gi;
      if (urlRegex.test(textLower)) {
        const isVip = config.vipList.has(sender);
        let isAdmin = false;
        try {
          const meta = await ctx.sock.groupMetadata(ctx.remoteJid);
          const participant = meta.participants.find(p => p.id.replace(/:\d+@/, "@").includes(sender.split("@")[0]));
          isAdmin = participant && (participant.admin === "admin" || participant.admin === "superadmin");
        } catch {}

        if (!isAdmin && !isVip && !isOwner(ctx)) {
          try {
            await ctx.sock.sendMessage(ctx.remoteJid, { delete: ctx.msg.key });
            await ctx.sock.sendMessage(ctx.remoteJid, {
              text: `🚫 *KINGBOT ANTI-LINK SHIELD:* Links are not allowed in this group, @${sender.split("@")[0]}! Message removed.`,
              mentions: [sender]
            });
            return;
          } catch {}
        }
      }
    }

    const now = Date.now();
    const isVip = config.vipList.has(sender);
    let isAdmin = false;
    if (isGroup) {
      try {
        const meta = await ctx.sock.groupMetadata(ctx.remoteJid);
        const participant = meta.participants.find(p => p.id.replace(/:\d+@/, "@").includes(sender.split("@")[0]));
        isAdmin = participant && (participant.admin === "admin" || participant.admin === "superadmin");
      } catch {}
    }

    if (isAdmin || isVip || isOwner(ctx)) return;

    if (config.anticrash) {
      const text = ctx.msg?.message?.conversation || ctx.msg?.message?.extendedTextMessage?.text || "";
      if (text.length > 4000 || /[\u200B-\u200D\uFEFF]/g.test(text) && text.length > 500) {
        try {
          await ctx.sock.sendMessage(ctx.remoteJid, { delete: ctx.msg.key });
          await ctx.sock.sendMessage(ctx.remoteJid, {
            text: `🛡️ *KINGBOT SECURITY:* Detected malicious crash-code from @${sender.split("@")[0]}! Message erased.`,
            mentions: [sender]
          });
          return;
        } catch {}
      }
    }

    if (config.antiforward) {
      const contextInfo = ctx.msg?.message?.extendedTextMessage?.contextInfo;
      if (contextInfo?.isForwarded || (contextInfo?.forwardingScore && contextInfo.forwardingScore > 1)) {
        try {
          await ctx.sock.sendMessage(ctx.remoteJid, { delete: ctx.msg.key });
          await ctx.sock.sendMessage(ctx.remoteJid, {
            text: `🚫 *KINGBOT SECURITY:* Mass forwarded messages are not allowed in this group!`,
          });
          return;
        } catch {}
      }
    }

    if (isGroup && config.slowmodeSec > 0) {
      const userKey = `${ctx.remoteJid}_${sender}`;
      const lastSent = slowmodeTracker.get(userKey) || 0;
      if (now - lastSent < config.slowmodeSec * 1000) {
        try {
          await ctx.sock.sendMessage(ctx.remoteJid, { delete: ctx.msg.key });
          return;
        } catch {}
      } else {
        slowmodeTracker.set(userKey, now);
      }
    }

    if (isGroup) {
      const userKey = `${ctx.remoteJid}_${sender}`;
      if (!groupUserTracker.has(userKey)) groupUserTracker.set(userKey, []);

      const timestamps = groupUserTracker.get(userKey);
      const windowMs = config.thresholdWindowSec * 1000;
      const recent = timestamps.filter(ts => now - ts < windowMs);
      recent.push(now);
      groupUserTracker.set(userKey, recent);

      if (recent.length >= config.thresholdMsgs) {
        groupUserTracker.set(userKey, []);

        const botIsAdmin = await checkBotAdmin(ctx.sock, ctx.remoteJid);
        if (botIsAdmin) {
          try {
            await ctx.sock.sendMessage(ctx.remoteJid, {
              text: `🚨 *KINGBOT ANTI-SPAM PROTECTION* 🚨\n\n@${sender.split("@")[0]} exceeded the threshold (${config.thresholdMsgs} messages in ${config.thresholdWindowSec}s) and has been removed!`,
              mentions: [sender]
            });
            await ctx.sock.groupParticipantsUpdate(ctx.remoteJid, [sender], "remove");
          } catch (err) {
            console.error("KingBot Kick Failure:", err);
          }
        }
      }
    }
  },

  handleGroupParticipantsUpdate: async function (sock, update) {
    const { id: jid, participants, action } = update;
    if (action !== "add") return;

    const config = getGroupConfig(jid);

    for (const participant of participants) {
      const cleanJid = participant.replace(/:\d+@/, "@");

      if (config.welcome) {
        await sock.sendMessage(jid, {
          text: `👑 *WELCOME TO THE GROUP!* 👑\n\nWelcome @${cleanJid.split("@")[0]}! We are glad to have you join us.\nPlease make sure to respect the rules and stay safe!`,
          mentions: [cleanJid]
        }).catch(() => {});
      }

      if (config.captcha) {
        const num1 = Math.floor(Math.random() * 8) + 1;
        const num2 = Math.floor(Math.random() * 8) + 1;
        const answer = (num1 + num2).toString();

        const captchaKey = `${jid}_${cleanJid}`;

        const timeout = setTimeout(async () => {
          if (pendingCaptchas.has(captchaKey)) {
            pendingCaptchas.delete(captchaKey);
            const botIsAdmin = await checkBotAdmin(sock, jid);
            if (botIsAdmin) {
              await sock.sendMessage(jid, {
                text: `⏰ *KINGBOT CAPTCHA EXPIRED:* @${cleanJid.split("@")[0]} failed to verify within 60 seconds and was removed.`,
                mentions: [cleanJid]
              }).catch(() => {});
              await sock.groupParticipantsUpdate(jid, [cleanJid], "remove").catch(() => {});
            }
          }
        }, 60000);

        pendingCaptchas.set(captchaKey, { answer, timeout });

        // Reliable Text-Based Math Verification
        await sock.sendMessage(jid, {
          text: `🛡️ *KINGBOT SECURITY VERIFICATION* 🛡️\n\n` +
                `Hello @${cleanJid.split("@")[0]}, please reply with the correct answer within *60 seconds* to verify you are human:\n\n` +
                `👉 *What is ${num1} + ${num2}?*`,
          mentions: [cleanJid]
        }).catch(() => {});
      }
    }
  }
};