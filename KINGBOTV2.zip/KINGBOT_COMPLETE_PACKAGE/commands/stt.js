const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');

module.exports = {
  category: "tools",
  description: "Transcribe voice notes or audio messages to text",
  commands: {
    stt: {
      category: "tools",
      description: "Reply to a voice note with .stt to transcribe it",
      async run(ctx) {
        const { sock, msg, remoteJid } = ctx;

        const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
        const quotedStanzaId = msg.message?.extendedTextMessage?.contextInfo?.stanzaId;

        if (!quotedMsg) {
          return { text: "⚠️ Please reply to a voice note or audio message with `.stt` to transcribe it." };
        }

        const isAudio = quotedMsg.audioMessage || quotedMsg.pttMessage;
        if (!isAudio) {
          return { text: "⚠️ The message you replied to is not an audio or voice note." };
        }

        const pseudoMsg = {
          key: {
            remoteJid: remoteJid,
            id: quotedStanzaId,
            participant: quotedParticipant
          },
          message: quotedMsg
        };

        try {
          await sock.sendMessage(remoteJid, { text: "🎙️ *Transcribing audio... Please wait.*" });

          const buffer = await downloadMediaMessage(
            pseudoMsg,
            'buffer',
            {},
            { 
              logger: console,
              reuploadRequest: sock.updateMediaMessage
            }
          );

          if (!buffer) {
            return { text: "❌ Failed to download the audio file from WhatsApp." };
          }

          const tempDir = path.join(__dirname, '../data');
          if (!fs.existsSync(tempDir)) {
            try { fs.mkdirSync(tempDir, { recursive: true }); } catch (e) {}
          }

          const tempFilePath = path.join(tempDir, `audio_${Date.now()}.ogg`);
          fs.writeFileSync(tempFilePath, buffer);

          // Fixed with lowercase 'gsk_' prefix
          const apiKey = "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";
          const apiBaseUrl = "https://api.groq.com/openai/v1/audio/transcriptions";

          const form = new FormData();
          form.append('file', fs.createReadStream(tempFilePath), { filename: 'audio.ogg', contentType: 'audio/ogg' });
          form.append('model', 'whisper-large-v3');

          const response = await axios.post(apiBaseUrl, form, {
            headers: {
              ...form.getHeaders(),
              'Authorization': `Bearer ${apiKey}`
            }
          });

          if (fs.existsSync(tempFilePath)) fs.unlinkSync(tempFilePath);

          const transcript = response.data?.text || "";
          if (!transcript.trim()) {
            return { text: "⚠️ Transcription returned empty text." };
          }

          return { 
            text: `📝 *AUDIO TRANSCRIPTION*\n\n"${transcript}"` 
          };

        } catch (err) {
          return { text: `❌ Error transcribing audio: ${err.message || err}` };
        }
      }
    }
  }
};