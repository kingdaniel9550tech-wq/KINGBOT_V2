const db = require("../db");
const axios = require("axios");

// ==========================================================
// 🔑 API CONFIGURATION (FROM ENVIRONMENT VARIABLES)
// ==========================================================
const CONFIG = {
  PAYSTACK_SECRET: process.env.PAYSTACK_SECRET_KEY || process.env.PAYSTACK_SECRET,
  VTPASS_API_KEY: process.env.VTPASS_API_KEY,
  VTPASS_SECRET_KEY: process.env.VTPASS_SECRET_KEY,
  MONO_SECRET_KEY: process.env.MONO_SECRET_KEY
};

// Validate critical keys
if (!CONFIG.PAYSTACK_SECRET) {
  console.warn('⚠️ [Finance] PAYSTACK_SECRET_KEY not configured - payment features disabled');
}

// Helper: Format currency in Naira
const formatNaira = (amount) => {
  return `₦${Number(amount).toLocaleString('en-NG', { minimumFractionDigits: 2 })}`;
};

// Helper: Get or create user wallet record
async function getWallet(phoneNumber) {
  let res = await db.query("SELECT * FROM user_wallets WHERE phone_number = $1", [phoneNumber]);
  if (res.rows.length === 0) {
    const insertRes = await db.query(
      "INSERT INTO user_wallets (phone_number, balance) VALUES ($1, 0.00) RETURNING *",
      [phoneNumber]
    );
    return insertRes.rows[0];
  }
  return res.rows[0];
}

module.exports = {
  category: "Elite Fintech & Utilities",
  commands: {

    // 1. SET TRANSACTION PIN
    setpin: {
      description: "Set your 4-digit transaction security PIN. Format: .setpin <4_digit_pin>",
      run: async ({ sender, args }) => {
        const phoneNumber = sender.replace(/[^0-9]/g, "");
        const pin = args[0];

        if (!pin || pin.length !== 4 || isNaN(pin)) {
          return `⚠️ *Invalid PIN Format!*\n\nPlease provide a secure 4-digit number.\nFormat: \`.setpin 1234\``;
        }

        await getWallet(phoneNumber);
        await db.query("UPDATE user_wallets SET pin = $1 WHERE phone_number = $2", [pin, phoneNumber]);

        return `🔐 *Transaction PIN Set Successfully!*\n\nYour 4-digit security PIN is now active.`;
      }
    },

    // 2. GENERATE FUNDING PAYMENT LINK (Paystack Checkout)
    fund: {
      description: "Generate an instant payment link to fund your wallet. Format: .fund <amount>",
      run: async ({ sender, args }) => {
        const phoneNumber = sender.replace(/[^0-9]/g, "");
        const amount = args[0];

        if (!amount || isNaN(amount) || Number(amount) <= 0) {
          return `⚠️ *Usage Error!*\n\nFormat: \`.fund <amount>\`\nExample: \`.fund 2000\``;
        }

        const fundAmount = Number(amount);

        try {
          await getWallet(phoneNumber);
          const paystackSecret = CONFIG.PAYSTACK_SECRET;

          const response = await axios.post(
            "https://api.paystack.co/transaction/initialize",
            {
              email: `user_${phoneNumber}@kingbot.ng`,
              amount: fundAmount * 100, // Convert to kobo
              metadata: { phone_number: phoneNumber }
            },
            { headers: { Authorization: `Bearer ${paystackSecret}` } }
          );

          if (response.data.status) {
            const data = response.data.data;
            return `💳 *Wallet Funding Link Generated!*\n\n` +
                   `💵 *Amount:* ${formatNaira(fundAmount)}\n\n` +
                   `🔗 *Click to pay via Bank Transfer, USSD, or Card:*\n${data.authorization_url}\n\n` +
                   `_After paying, copy your payment reference and type:_\n\`.verify <reference>\``;
          } else {
            return `❌ Paystack Error: ${response.data.message}`;
          }

        } catch (err) {
          console.error("Fund link error:", err.response?.data || err.message);
          return `❌ Gateway Error: ${err.response?.data?.message || err.message}`;
        }
      }
    },

    // 3. VERIFY PAYMENT AND CREDIT WALLET
    verify: {
      description: "Verify your payment reference and credit your wallet. Format: .verify <reference>",
      run: async ({ sender, args }) => {
        const phoneNumber = sender.replace(/[^0-9]/g, "");
        const reference = args[0];

        if (!reference) {
          return `⚠️ *Usage Error!*\n\nFormat: \`.verify <payment_reference>\``;
        }

        try {
          const paystackSecret = CONFIG.PAYSTACK_SECRET;
          const res = await axios.get(
            `https://api.paystack.co/transaction/verify/${reference}`,
            { headers: { Authorization: `Bearer ${paystackSecret}` } }
          );

          const tx = res.data.data;
          if (tx.status === "success") {
            const amountPaid = tx.amount / 100; // Convert from kobo

            // Credit wallet
            await db.query("UPDATE user_wallets SET balance = balance + $1 WHERE phone_number = $2", [amountPaid, phoneNumber]);

            return `✅ *Payment Verified Successfully!* 🎉\n\n` +
                   `💰 *Credited to Wallet:* ${formatNaira(amountPaid)}\n` +
                   `🆔 *Ref:* \`${reference}\``;
          } else {
            return `❌ Transaction status is currently: *${tx.status}*`;
          }
        } catch (err) {
          console.error("Verify error:", err.response?.data || err.message);
          return `❌ Verification Failed: ${err.response?.data?.message || err.message}`;
        }
      }
    },

    // 4. CHECK BOT WALLET BALANCE
    balance: {
      description: "Check your live bot wallet balance",
      run: async ({ sender }) => {
        const phoneNumber = sender.replace(/[^0-9]/g, "");
        const wallet = await getWallet(phoneNumber);

        return `💰 *Your Bot Wallet Balance*\n\n` +
               `📱 *Phone:* \`${phoneNumber}\`\n` +
               `💵 *Balance:* *${formatNaira(wallet.balance)}*\n\n` +
               `_Type \`.fund <amount>\` to top up your wallet._`;
      }
    },

    // 5. REAL BANK TRANSFER
    transfer: {
      description: "Send money to any bank. Format: .transfer <amount> <account_number> <bank_code> <pin>",
      run: async ({ args, sender }) => {
        const amount = args[0];
        const accountNumber = args[1];
        const bankCode = args[2];
        const pin = args[3];
        const phoneNumber = sender.replace(/[^0-9]/g, "");

        if (!amount || !accountNumber || !bankCode || !pin) {
          return `⚠️ *Usage Error!*\n\nFormat: \`.transfer <amount> <account_number> <bank_code> <pin>\``;
        }

        const wallet = await getWallet(phoneNumber);
        if (!wallet.pin || wallet.pin !== pin) return `❌ Incorrect transaction PIN.`;

        const transferAmount = Number(amount);
        if (parseFloat(wallet.balance) < transferAmount) return `❌ Insufficient funds.`;

        try {
          const paystackSecret = CONFIG.PAYSTACK_SECRET;
          const recipientRes = await axios.post(
            "https://api.paystack.co/transferrecipient",
            { type: "nuban", name: `User ${phoneNumber}`, account_number: accountNumber, bank_code: bankCode, currency: "NGN" },
            { headers: { Authorization: `Bearer ${paystackSecret}` } }
          );

          if (!recipientRes.data.status) return `❌ Failed to resolve recipient bank details.`;
          const recipientCode = recipientRes.data.data.recipient_code;

          const transferRes = await axios.post(
            "https://api.paystack.co/transfer",
            { source: "balance", amount: transferAmount * 100, recipient: recipientCode, reason: "Bot Transfer" },
            { headers: { Authorization: `Bearer ${paystackSecret}` } }
          );

          if (transferRes.data.status) {
            await db.query("UPDATE user_wallets SET balance = balance - $1 WHERE phone_number = $2", [transferAmount, phoneNumber]);
            return `💸 *Transfer Successful!*\nAmount: ${formatNaira(transferAmount)}\nRef: \`${transferRes.data.data.reference}\``;
          } else {
            return `❌ Transfer failed: ${transferRes.data.message}`;
          }
        } catch (err) {
          return `❌ Transfer Error: ${err.response?.data?.message || err.message}`;
        }
      }
    },

    // 6. ELECTRICITY METER TOKEN VENDING
    electricity: {
      description: "Buy prepaid electricity tokens. Format: .electricity <meter_number> <disco> <amount> <pin>",
      run: async ({ args, sender }) => {
        const meterNumber = args[0];
        const disco = args[1]?.toLowerCase();
        const amount = args[2];
        const pin = args[3];
        const phoneNumber = sender.replace(/[^0-9]/g, "");

        if (!meterNumber || !disco || !amount || !pin) {
          return `⚡ Format: \`.electricity <meter> <disco> <amount> <pin>\``;
        }

        const wallet = await getWallet(phoneNumber);
        if (!wallet.pin || wallet.pin !== pin) return `❌ Incorrect PIN.`;

        const utilityAmount = Number(amount);
        if (parseFloat(wallet.balance) < utilityAmount) return `❌ Insufficient balance.`;

        try {
          const response = await axios.post(
            "https://vtpass.com/api/pay",
            { serviceID: disco, request_id: `REQ-${Date.now()}`, billersCode: meterNumber, variation_code: "prepaid", amount: utilityAmount, phone: phoneNumber },
            { headers: { "api-key": CONFIG.VTPASS_API_KEY, "secret-key": CONFIG.VTPASS_SECRET_KEY, "Content-Type": "application/json" } }
          );

          const result = response.data;
          if (result.code === "000") {
            await db.query("UPDATE user_wallets SET balance = balance - $1 WHERE phone_number = $2", [utilityAmount, phoneNumber]);
            return `⚡ *Electricity Token Generated!*\nToken: \`\`\`${result.purchased_code || result.token}\`\`\``;
          } else {
            return `❌ Vending Failed: ${result.response_description}`;
          }
        } catch (err) {
          return `❌ Utility error: ${err.message}`;
        }
      }
    },

    // 7. AIRTIME
    airtime: {
      description: "Buy airtime. Format: .airtime <network> <phone> <amount>",
      run: async ({ args, sender }) => {
        const network = args[0]?.toLowerCase();
        const phone = args[1];
        const amount = args[2];
        const phoneNumber = sender.replace(/[^0-9]/g, "");

        if (!network || !phone || !amount) return `📱 Format: \`.airtime <network> <phone> <amount>\``;

        const wallet = await getWallet(phoneNumber);
        const cost = Number(amount);
        if (parseFloat(wallet.balance) < cost) return `❌ Insufficient balance.`;

        try {
          const response = await axios.post(
            "https://vtpass.com/api/pay",
            { serviceID: network, request_id: `AIR-${Date.now()}`, amount: cost, phone: phone },
            { headers: { "api-key": CONFIG.VTPASS_API_KEY, "Content-Type": "application/json" } }
          );

          if (response.data.code === "000") {
            await db.query("UPDATE user_wallets SET balance = balance - $1 WHERE phone_number = $2", [cost, phoneNumber]);
            return `📱 *Airtime Sent Successfully!*\nAmount: ${formatNaira(cost)}`;
          } else {
            return `❌ Airtime failed: ${response.data.response_description}`;
          }
        } catch (err) {
          return `❌ Airtime error: ${err.message}`;
        }
      }
    },

    // 8. LINK BANK
    linkbank: {
      description: "Link external bank/OPay via Open Banking",
      run: async () => {
        return `🔐 Link your bank/OPay here: https://connect.withmono.com/?key=live_pk_your_mono_public_key`;
      }
    },

    // 9. BANK BALANCE
    bankbalance: {
      description: "Check linked external bank balance",
      run: async ({ sender }) => {
        const phoneNumber = sender.replace(/[^0-9]/g, "");
        const wallet = await getWallet(phoneNumber);

        if (!wallet.mono_account_id) return `⚠️ No external bank linked. Use \`.linkbank\` first.`;

        try {
          const res = await axios.get(
            `https://api.withmono.com/v2/accounts/${wallet.mono_account_id}/balance`,
            { headers: { "mono-sec-key": CONFIG.MONO_SECRET_KEY, "Content-Type": "application/json" } }
          );
          return `🏛️ External Real-Time Balance: *${formatNaira(res.data.balance / 100)}*`;
        } catch (err) {
          return `❌ Failed to fetch balance.`;
        }
      }
    }

  }
};
