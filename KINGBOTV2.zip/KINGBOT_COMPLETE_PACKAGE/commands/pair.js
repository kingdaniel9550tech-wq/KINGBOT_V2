const { default: makeWASocket, DisconnectReason, fetchLatestWaWebVersion, Browsers, initAuthCreds, BufferJSON } = require("@whiskeysockets/baileys");
const { Boom } = require("@hapi/boom");
const pino = require("pino");
const path = require("path");
const fs = require("fs");
const db = require("../db");

const userSessions = new Map();
const OWNER_PHONE = process.env.OWNER_NUMBER || "2349073828261"; // Your master owner number

// 1. Admin commands (Strictly for you)
const ADMIN_COMMANDS = ["addprem", "delprem", "stats", "sendmail", "post", "genkey", "resetbot", "allusers", "setreplyimage"];

// 2. EXPLICIT Premium commands (Only these require a premium license)
const PREMIUM_COMMANDS = [
  "adminme", "aichat", "ai3", "video", "kingai2", "pro", 
  "video", "tiktok", "certify", "play2", "kingchat", 
  "facebook", "fb", "getpp", "vv", "temp"
];

// Special modules tracking for user bot instances
let ussdModule = null;
let kingChatModule = null;
let antilinkModule = null;

// Anti-spam rate limiter tracking
const userCooldowns = new Map();

// Custom PostgreSQL Auth State Adapter for Baileys
async function usePostgresAuthState(tenantId) {
  const writeData = async (data, id) => {
    const jsonString = JSON.stringify(data, BufferJSON.replacer);
    await db.query(
      `INSERT INTO whatsapp_sessions (tenant_id, key_id, data) VALUES ($1, $2, $3)
       ON CONFLICT (tenant_id, key_id) DO UPDATE SET data = $3`,
      [tenantId, id, jsonString]
    );
  };

  const readData = async (id) => {
    try {
      const res = await db.query(`SELECT data FROM whatsapp_sessions WHERE tenant_id = $1 AND key_id = $2`, [tenantId, id]);
      if (res.rows.length === 0) return null;
      return JSON.parse(res.rows[0].data, BufferJSON.reviver);
    } catch (err) {
      return null;
    }
  };

  const removeData = async (id) => {
    try {
      await db.query(`DELETE FROM whatsapp_sessions WHERE tenant_id = $1 AND key_id = $2`, [tenantId, id]);
    } catch {}
  };

  const creds = await readData('creds') || initAuthCreds();

  return {
    state: {
      creds,
      keys: {
        get: async (type, ids) => {
          const data = {};
          for (const id of ids) {
            let value = await readData(`${type}-${id}`);
            data[id] = value;
          }
          return data;
        },
        set: async (data) => {
          const tasks = [];
          for (const category of Object.keys(data)) {
            for (const id of Object.keys(data[category])) {
              const value = data[category][id];
              const key = `${category}-${id}`;
              if (value) {
                tasks.push(writeData(value, key));
              } else {
                tasks.push(removeData(key));
              }
            }
          }
          await Promise.all(tasks);
        }
      }
    },
    saveCreds: () => writeData(creds, 'creds')
  };
}

// Check database for premium status
async function checkIsPremium(phoneNumber) {
  try {
    const res = await db.query("SELECT is_premium FROM licenses WHERE bound_number = $1", [phoneNumber]);
    if (res.rows.length > 0) {
      return res.rows[0].is_premium === true;
    }
  } catch (err) {
    console.error("Error checking premium status:", err);
  }
  return false;
}

// Load command registry and special module handlers
function loadUserRegistry(isOwnerUser) {
  const userRegistry = {};
  const commandsDir = path.join(__dirname);
  if (fs.existsSync(commandsDir)) {
    for (const file of fs.readdirSync(commandsDir)) {
      if (!file.endsWith(".js")) continue;
      const modPath = path.join(commandsDir, file);
      const mod = require(modPath);

      if (file === "ussd.js") ussdModule = mod;
      if (file === "kingchat.js") kingChatModule = mod;
      if (file === "antilink.js") antilinkModule = mod;

      if (mod.commands) {
        for (const [name, cmd] of Object.entries(mod.commands)) {
          const lowerName = name.toLowerCase();
          if (ADMIN_COMMANDS.includes(lowerName) && !isOwnerUser) continue;
          userRegistry[lowerName] = { ...cmd, category: mod.category };
        }
      }
    }
  }
  return userRegistry;
}

// Anti-ban safe reply helper with natural typing delay
async function safeReply(sock, remoteJid, content, msg) {
  try {
    await sock.presenceSubscribe(remoteJid);
    await sock.sendPresenceUpdate('composing', remoteJid);
    await new Promise(resolve => setTimeout(resolve, 1000)); // 1-second human typing delay
    
    if (typeof content === "string") {
      await sock.sendMessage(remoteJid, { text: content }, { quoted: msg });
    } else {
      await sock.sendMessage(remoteJid, content, { quoted: msg });
    }
  } catch (err) {
    console.error("Safe reply execution error:", err);
  }
}

async function startUserBotSession(tenantId, phoneNumber, replyJid = null, masterSock = null) {
  if (userSessions.has(tenantId)) return; // Prevent duplicate concurrent instances

  const { state: authState, saveCreds } = await usePostgresAuthState(tenantId);
  const { version } = await fetchLatestWaWebVersion();

  const sock = makeWASocket({
    version,
    auth: authState,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    browser: Browsers.macOS("Chrome"),
    markOnlineOnConnect: true,
    emitOwnEvents: false,
  });

  userSessions.set(tenantId, sock);
  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;
    
    if (connection === "close") {
      userSessions.delete(tenantId);
      let statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
      if (statusCode !== DisconnectReason.loggedOut) {
        console.log(`[Watchdog] User session ${tenantId} reconnecting safely with backoff...`);
        setTimeout(() => startUserBotSession(tenantId, phoneNumber, replyJid, masterSock), 10000);
      }
    } else if (connection === "open") {
      console.log(`[Watchdog] User session ${tenantId} connected successfully!`);
      if (masterSock && replyJid) {
        try {
          await masterSock.sendMessage(replyJid, { text: `🎉 *Success!* Your personal bot instance is active, online, and anti-ban protected!` });
        } catch {}
      }
    }
  });

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    const msg = messages[0];
    if (!msg.message) return;

    // IGNORE OLD MESSAGES: Discard history sync or messages older than 30 seconds
    const messageTimestamp = msg.messageTimestamp;
    if (messageTimestamp) {
      const msgTime = (typeof messageTimestamp === 'object' && messageTimestamp.low) ? messageTimestamp.low * 1000 : Number(messageTimestamp) * 1000;
      if (Date.now() - msgTime > 30000) return;
    }

    const remoteJid = msg.key.remoteJid;
    const isFromMe = msg.key.fromMe === true;
    const sender = msg.key.participant || remoteJid;
    const senderNumber = sender.replace(/[^0-9]/g, "");

    const bodyText = msg.message.conversation || msg.message.extendedTextMessage?.text || "";
    if (!bodyText) return;

    // 1. Run Anti-Link Security Check if available
    if (antilinkModule && typeof antilinkModule.handleAntiLink === "function") {
      await antilinkModule.handleAntiLink({ sock, msg, remoteJid, sender, isFromMe, body: bodyText }).catch(() => {});
    }

    // 2. Run KingChat integration check
    if (kingChatModule && typeof kingChatModule.handleKingChat === "function") {
      const handled = await kingChatModule.handleKingChat({ sock, msg, remoteJid, sender, isFromMe });
      if (handled) return;
    }

    // 3. USSD Active Session Handler (Matches ussd.js structure)
    if (ussdModule && ussdModule.ussdSessions && ussdModule.ussdSessions.has(remoteJid) && typeof ussdModule.processUSSDInput === "function") {
      try {
        const res = await ussdModule.processUSSDInput({ sock, remoteJid, msg }, bodyText);
        if (res) {
          const replyText = typeof res === "string" ? res : res.text;
          if (replyText) {
            await safeReply(sock, remoteJid, replyText, msg);
          }
        }
        return; // Successfully handled USSD step without requiring a prefix!
      } catch (err) {
        console.error("USSD active session execution error:", err);
      }
    }

    const usedPrefix = bodyText.startsWith(".") ? "." : (bodyText.startsWith("!") ? "!" : null);
    if (!usedPrefix) return;

    const [rawCmd, ...args] = bodyText.slice(usedPrefix.length).trim().split(/\s+/);
    const cmdName = rawCmd.toLowerCase();

    // Anti-Spam Rate Limiting (1 message per 1.5 seconds per user)
    const now = Date.now();
    const lastUserMsg = userCooldowns.get(senderNumber) || 0;
    if (now - lastUserMsg < 1500) return; 
    userCooldowns.set(senderNumber, now);

    const isOwner = senderNumber === OWNER_PHONE;
    const isPremium = await checkIsPremium(phoneNumber);

    const isAdminCmd = ADMIN_COMMANDS.includes(cmdName);
    const isPremiumCmd = PREMIUM_COMMANDS.includes(cmdName);

    // 1. Block Admin commands if not owner
    if (isAdminCmd && !isOwner) {
      await safeReply(sock, remoteJid, "❌ Access Denied: This command is restricted to the bot owner.", msg);
      return;
    }

    // 2. Block specific Premium commands if user is not premium or owner
    if (isPremiumCmd && !isOwner && !isPremium) {
      await safeReply(sock, remoteJid, `⭐ *Premium Feature Locked!*\n\nThis command is visible in your menu, but requires a *Premium License* to execute.\n\nContact the bot owner to upgrade your license and unlock all features!`, msg);
      return;
    }

    const activeRegistry = loadUserRegistry(isOwner);
    const cmd = activeRegistry[cmdName];
    if (!cmd) return;

    const ctx = { sock, msg, args, remoteJid, sender, registry: activeRegistry, isFromMe };

    try {
      const result = await cmd.run(ctx);
      if (result) {
        await safeReply(sock, remoteJid, result, msg);
      }
    } catch (err) {
      console.error(`Error running command "${cmdName}" on session ${tenantId}:`, err);
      await safeReply(sock, remoteJid, `❌ Error executing command: ${err.message}`, msg);
    }
  });

  if (!authState.creds.registered && masterSock && replyJid) {
    try {
      while (!sock.ws || !sock.ws.isOpen) {
        await new Promise(resolve => setTimeout(resolve, 500));
      }

      const cleanNumber = phoneNumber.replace(/[^0-9]/g, "");
      const pairingCode = await sock.requestPairingCode(cleanNumber);
      
      await masterSock.sendMessage(replyJid, { 
        text: `👑 *KingBot SaaS Portal*\n\nLicense verified & session saved to database!\n\nYour 8-digit Pairing Code is:\n\`\`\`${pairingCode}\`\`\`\n\n_Go to WhatsApp > Linked Devices > Link with phone number and enter this code._` 
      });
    } catch (err) {
      console.error("Pairing code generation error:", err);
      await masterSock.sendMessage(replyJid, { text: `❌ Failed to generate pairing code: ${err.message}` });
    }
  }
}

// AUTO-RESTART RECOVERY: Automatically reload all paired user sessions from Postgres on server boot
async function restoreAllUserSessions() {
  try {
    const res = await db.query("SELECT DISTINCT tenant_id FROM whatsapp_sessions");
    if (res.rows.length > 0) {
      console.log(`[SaaS Bootloader] Restoring ${res.rows.length} user bot session(s) from database...`);
      for (const row of res.rows) {
        const tenantId = row.tenant_id;
        const phoneNumber = tenantId.replace("bot_", "");
        startUserBotSession(tenantId, phoneNumber);
      }
    }
  } catch (err) {
    console.error("[SaaS Bootloader] Failed to restore user sessions:", err);
  }
}

// Trigger recovery on boot
setTimeout(restoreAllUserSessions, 3000);

module.exports = {
  category: "SaaS",
  commands: {
    pair: {
      description: "Link your bot using your license token and phone number",
      run: async ({ sock, msg, args, remoteJid }) => {
        const licenseKey = args[0];
        const phoneNumber = args[1];

        if (!licenseKey || !phoneNumber) {
          return "⚠️ *Usage Error!*\nFormat: `.pair <YOUR_LICENSE_KEY> <PHONE_NUMBER>`\nExample: `.pair KING-TEST321 2348012345678`";
        }

        try {
          const res = await db.query("SELECT * FROM licenses WHERE token = $1", [licenseKey]);
          
          if (res.rows.length === 0) {
            return "❌ *Access Denied:* Invalid license token. Please check your key or purchase a valid one.";
          }

          const licenseData = res.rows[0];
          if (licenseData.is_used && licenseData.bound_number && licenseData.bound_number !== phoneNumber) {
            return "❌ *Access Denied:* This license token is already tied to a different phone number.";
          }

          await db.query(
            "UPDATE licenses SET bound_number = $1, is_used = TRUE, is_premium = COALESCE(is_premium, FALSE) WHERE token = $2", 
            [phoneNumber, licenseKey]
          );

          const tenantId = `bot_${phoneNumber}`;
          await sock.sendMessage(remoteJid, { text: "⏳ Valid license accepted! Setting up your cloud database session..." }, { quoted: msg });
          
          startUserBotSession(tenantId, phoneNumber, remoteJid, sock);

          return; 
        } catch (err) {
          console.error("Database or pairing execution error:", err);
          return `❌ Database Error: ${err.message}`;
        }
      }
    }
  }
};
