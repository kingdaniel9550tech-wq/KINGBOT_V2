const fs = require('fs');
const path = require('path');

module.exports = {
  category: "owner",
  description: "Create and reveal self-destructing secure notes with auto-deletion",
  commands: {
    burn: {
      category: "owner",
      description: "Create a secret note (Owner only). Usage: .burn <your secret message>",
      async run(ctx) {
        const { sock, remoteJid, msg, args } = ctx;

        // Strict Owner Verification Check (.burn is restricted)
        const ownerJid = sock.user?.id || "";
        const ownerPhoneNum = ownerJid ? ownerJid.split("@")[0].split(":")[0] : "";
        const configOwnerNum = process.env.OWNER_NUMBER || "2349073828261";
        const sender = msg.key.participant || remoteJid;
        const isOwner = msg.key.fromMe || (ownerPhoneNum && sender.includes(ownerPhoneNum)) || (configOwnerNum && sender.includes(configOwnerNum));

        if (!isOwner) {
          return { text: "⚠️ *Access Denied:* This command is restricted to the bot owner only." };
        }

        const secretText = args.join(" ").trim();

        if (!secretText) {
          return { 
            text: "⚠️ *Invalid Usage!*\n\n" +
                  "Please provide the secret message you want to lock.\n\n" +
                  "📌 *Example:*\n" +
                  "`.burn MyAdminPassword123`" 
          };
        }

        const senderJid = msg.key.participant || remoteJid;
        const burnId = "BURN-" + Math.floor(100000 + Math.random() * 900000);

        // Ensure data directory exists
        const dataDir = path.join(__dirname, '../data');
        if (!fs.existsSync(dataDir)) {
          fs.mkdirSync(dataDir, { recursive: true });
        }

        const burnFile = path.join(dataDir, 'burn_notes.json');
        let notes = [];

        if (fs.existsSync(burnFile)) {
          try {
            notes = JSON.parse(fs.readFileSync(burnFile, 'utf8'));
          } catch (e) {
            notes = [];
          }
        }

        notes.push({
          id: burnId,
          message: secretText,
          createdAt: new Date().toISOString()
        });

        fs.writeFileSync(burnFile, JSON.stringify(notes, null, 2));

        // Send the sensitive code ONLY to the owner's private DM
        try {
          await sock.sendMessage(senderJid, {
            text: `🔥 *Your Secure Burn Note Created!*\n\n` +
                  `Secret Code: *${burnId}*\n\n` +
                  `💬 *Secret Message:* "${secretText}"\n\n` +
                  `_Share only the code (*${burnId}*) with your recipient. When they type \`.reveal ${burnId}\`, it will display once and self-destruct permanently._`
          });
        } catch (err) {
          console.log("Failed to send DM:", err.message);
        }

        return {
          text: `🔥 *Secure Note Generated Successfully!*\n\n` +
                `I have sent the secret burn code directly to your **private messages (DM)** for security.`
        };
      }
    },
    reveal: {
      category: "tools",
      description: "Read and auto-delete a self-destructing note. Usage: .reveal <BURN-CODE>",
      async run(ctx) {
        const { sock, remoteJid, args } = ctx;
        const code = args[0] ? args[0].trim().toUpperCase() : "";

        if (!code) {
          return { text: "⚠️ *Usage:* `.reveal BURN-XXXXXX`" };
        }

        const dataDir = path.join(__dirname, '../data');
        const burnFile = path.join(dataDir, 'burn_notes.json');

        if (!fs.existsSync(burnFile)) {
          return { text: "❌ *Error:* No secure notes found in the system." };
        }

        let notes = [];
        try {
          notes = JSON.parse(fs.readFileSync(burnFile, 'utf8'));
        } catch (e) {
          return { text: "❌ *Error:* Failed to read secure database." };
        }

        const noteIndex = notes.findIndex(n => n.id === code);

        if (noteIndex === -1) {
          return { text: "❌ *Error:* This secret note either does not exist, has already been read, or has been destroyed." };
        }

        const targetNote = notes[noteIndex];

        // 🔥 DESTROY IT IMMEDIATELY FROM DATABASE SO IT CAN NEVER BE USED AGAIN
        notes.splice(noteIndex, 1);
        fs.writeFileSync(burnFile, JSON.stringify(notes, null, 2));

        // Send the message and auto-delete it after 15 seconds for everyone
        try {
          const sentMsg = await sock.sendMessage(remoteJid, {
            text: `🔓 *Secure Note Unlocked & Destroyed*\n\n` +
                  `"${targetNote.message}"\n\n` +
                  `_⏳ This message will self-destruct and disappear for everyone in 15 seconds..._`
          });

          // Set a timer to delete the message for everyone after 15 seconds (15000ms)
          setTimeout(async () => {
            try {
              if (sentMsg && sentMsg.key) {
                await sock.sendMessage(remoteJid, { delete: sentMsg.key });
              }
            } catch (delErr) {
              console.log("Failed to auto-delete burn message:", delErr.message);
            }
          }, 15000);

        } catch (err) {
          console.log("Error sending reveal message:", err.message);
        }

        return;
      }
    }
  }
};