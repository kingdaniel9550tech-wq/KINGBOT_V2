const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');
const { isOwner } = require("../utils");

const OWNER_PHONE = '2349073828261';
const BRANDING = '\n\n⚡️_POWERED BY KINGBOT_⚡️';

// Configure your email transporter
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'kingdaniel9550@gmail.com',
        pass: 'wyqwvidfiadlhogg'
    }
});

module.exports = {
  category: "Owner",
  commands: {
    sendmail: {
      desc: "Sends an email with optional HTML and quoted file attachments (Owner only)",
      run: async (ctx) => {
        const senderId = ctx.sender || ctx.from || ctx.key?.remoteJid || '';
        
        // Restrict command to you (the owner) for security
        const userIsOwner = senderId.includes(OWNER_PHONE) || (typeof isOwner === 'function' && isOwner(ctx));
        if (!userIsOwner) {
            return `⚠️ This command is strictly for my owner!${BRANDING}`;
        }

        let args = ctx.args || [];
        if (typeof ctx.text === 'string') {
            const parts = ctx.text.trim().split(/\s+/);
            args = parts.slice(1);
        }

        const recipient = args[0];
        const messageBody = args.slice(1).join(' ');

        if (!recipient || !recipient.includes('@')) {
            return `⚠️ Usage error: !sendmail <email> <message text>${BRANDING}`;
        }

        try {
            let mailOptions = {
                from: 'kingdaniel9550@gmail.com',
                to: recipient,
                subject: 'Message from KingBot',
                text: messageBody || 'Here is your automated message/file.',
                html: messageBody ? messageBody.replace(/\n/g, '<br>') : '<p>Here is your automated file from KingBot.</p>'
            };

            // Check if there is a quoted message or media attached to download and forward
            const quotedMsg = ctx.quoted || ctx.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (quotedMsg && typeof client !== 'undefined' && typeof client.downloadAndSaveMediaMessage === 'function') {
                const mediaPath = await client.downloadAndSaveMediaMessage(quotedMsg, 'temp_attachment');
                if (mediaPath && fs.existsSync(mediaPath)) {
                    mailOptions.attachments = [{
                        path: mediaPath
                    }];
                }
            }

            await transporter.sendMail(mailOptions);

            // Clean up temporary local media file if created
            if (mailOptions.attachments && mailOptions.attachments[0]?.path) {
                try { fs.unlinkSync(mailOptions.attachments[0].path); } catch(e) {}
            }

            return `✅ Email successfully sent to *${recipient}*!${BRANDING}`;

        } catch (error) {
            console.error("SendMail Error:", error);
            return `❌ Failed to send email: ${error.message}${BRANDING}`;
        }
      }
    }
  }
};