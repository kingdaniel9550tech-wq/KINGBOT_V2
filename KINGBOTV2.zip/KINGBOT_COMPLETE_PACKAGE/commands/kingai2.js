const axios = require('axios');

module.exports = {
  category: "ai",
  description: "The Alpha and Omega of AI",
  commands: {
    kingai2: {
      category: "ai",
      description: "Ask the supreme AI. Usage: .kingai2 <prompt>",
      async run(ctx) {
        const { sock, remoteJid, msg, args } = ctx;
        
        // --- OWNER CHECK ---
        // Replace "234XXXXXXXXX" with your actual WhatsApp phone number digits (e.g., "2348012345678")
        const ownerNumber = "2349073828261"; 
        const sender = msg.key.participant || remoteJid || "";
        const isOwner = msg.key.fromMe || (ownerNumber !== "2349073828261" && sender.includes(ownerNumber));

        if (!isOwner) {
          return {
            text: "👑 *Kingbot Security Protocol*\n\n" +
                  "🚫 *Access Denied!*\n" +
                  "This command is restricted and reserved exclusively for the bot owner, *King Daniel*."
          };
        }

        const prompt = args.join(" ").trim();

        if (!prompt) {
          return { 
            text: "👑 *Kingbot AI — The Alpha & Omega*\n\n" +
                  "⚠️ *Syntax Error!*\n" +
                  "State your command, query, or task for the supreme intelligence.\n\n" +
                  "📌 *Example:*\n" +
                  "`.kingai2 Who is King Daniel?`" 
          };
        }

        // Hardcoded Official API Keys
        const geminiKey = "AQ.Ab8RN6LRgbWn0XME6tkcVXFWAiI95hifYolAyH7NmPqBz9tg3Q";
        const groqKey = "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";

        // System identity instruction for the AI
        const systemPersona = "You are Kingbot AI, the Alpha and Omega of artificial intelligence. You were created by King Daniel, a master software developer and digital creator of Kingbot. Always proudly identify yourself as Kingbot AI and credit King Daniel as your creator whenever asked about your identity, origin, or who made you.";

        // Send live execution status bar
        let statusMsg;
        try {
          statusMsg = await sock.sendMessage(remoteJid, { 
            text: "👑 *Kingbot AI* ⚡\n\n`[■■■□□] 50%...`" 
          });
        } catch (e) {}

        let aiResponse = "";

        // --- ATTEMPT 1: Google Gemini API (Primary Core - Tried First) ---
        if (geminiKey) {
          try {
            const response = await axios.post(
              `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${geminiKey}`,
              {
                system_instruction: {
                  parts: [{ text: systemPersona }]
                },
                contents: [{ parts: [{ text: prompt }] }]
              },
              { headers: { 'Content-Type': 'application/json' }, timeout: 20000 }
            );

            if (
              response.data &&
              response.data.candidates &&
              response.data.candidates[0].content &&
              response.data.candidates[0].content.parts[0].text
            ) {
              aiResponse = response.data.candidates[0].content.parts[0].text;
            }
          } catch (err) {
            console.log("Kingbot AI Fallback: Gemini primary core busy, shifting to backup core...");
          }
        }

        // --- ATTEMPT 2: Groq API (Secondary Fallback Core - Tried if Gemini fails) ---
        if (!aiResponse && groqKey) {
          try {
            const response = await axios.post(
              'https://api.groq.com/openai/v1/chat/completions',
              {
                model: 'llama-3.3-70b-versatile',
                messages: [
                  { role: 'system', content: systemPersona },
                  { role: 'user', content: prompt }
                ]
              },
              {
                headers: {
                  'Authorization': `Bearer ${groqKey}`,
                  'Content-Type': 'application/json'
                },
                timeout: 20000
              }
            );

            if (
              response.data &&
              response.data.choices &&
              response.data.choices[0].message &&
              response.data.choices[0].message.content
            ) {
              aiResponse = response.data.choices[0].message.content;
            }
          } catch (err) {
            console.log("Kingbot AI Fallback: Groq backup core also encountered an error.");
          }
        }

        // Clean up status message
        if (statusMsg && statusMsg.key) {
          try { await sock.sendMessage(remoteJid, { delete: statusMsg.key }); } catch (e) {}
        }

        if (!aiResponse) {
          return {
            text: `👑 *Kingbot AI Core Error*\n\n❌.`
          };
        }

        return {
          text: `👑 *KINGBOT AI — THE ALPHA & OMEGA*\n\n` +
                `${aiResponse}\n\n` +
                `_⚡ Powered by Kingbot_`
        };
      }
    }
  }
};