module.exports = {
  category: "tools",
  commands: {
    react: {
      description: "Owner-only command to send 30 automated reactions to a WhatsApp Channel link or replied message",
      async run(ctx) {
        const { sock, remoteJid, msg, args } = ctx;
        
        // --- OWNER SECURITY CHECK ---
        const ownerJid = sock.user?.id || "";
        const ownerPhoneNum = ownerJid ? ownerJid.split("@")[0].split(":")[0] : "";
        const configOwnerNum = process.env.OWNER_NUMBER || "";

        const sender = msg.key.participant || remoteJid;
        const isOwner = msg.key.fromMe || 
          (ownerPhoneNum && sender.includes(ownerPhoneNum)) || 
          (configOwnerNum && sender.includes(configOwnerNum));

        if (!isOwner) {
          return { text: "⛔ Access Denied! This command is restricted to the bot owner." };
        }
        // -----------------------------

        if (args.length === 0) {
          return { 
            text: `⚠️ Please provide a channel link or reply to a message!\n\n` +
                  `*Usage 1 (Channel Link):* \`.react <channel_link> 👍 ❤️ 🔥\`\n` +
                  `*Usage 2 (Replied Message):* Reply to a message and type \`.react 👍\` or \`.react 👍 ❤️\`\n` +
                  `_(Note: The bot will automatically cycle your emojis to send a total of 30 reactions!)_` 
            };
        }

        const firstArg = args[0];
        const isChannelLink = firstArg.includes("whatsapp.com/channel/");

        // --- PREPARE 30 REACTIONS (CYCLING THROUGH INPUT EMOJIS) ---
        const rawEmojis = isChannelLink ? args.slice(1) : args;
        const baseEmojis = rawEmojis.length > 0 ? rawEmojis : ["👍", "❤️", "🔥", "🚀", "👏", "💯", "🎉", "⭐"];
        
        const totalReactions = 30;
        const targetEmojis = [];
        for (let i = 0; i < totalReactions; i++) {
          targetEmojis.push(baseEmojis[i % baseEmojis.length]);
        }

        // --- CASE 1: CHANNEL LINK REACT LOOP ---
        if (isChannelLink) {
          const link = firstArg;

          try {
            const urlPath = link.split("whatsapp.com/channel/")[1];
            if (!urlPath) {
              return { text: `❌ Invalid channel link format.` };
            }

            const urlParts = urlPath.split("/");
            const inviteCodeOrId = urlParts[0];
            const messageId = urlParts[1]; // Optional specific post ID

            let newsletterJid = inviteCodeOrId;

            // Resolve channel JID via invite code if needed
            if (!newsletterJid.endsWith("@newsletter")) {
              const metadata = await sock.newsletterMetadata("invite", inviteCodeOrId);
              if (metadata && metadata.id) {
                newsletterJid = metadata.id;
              } else {
                return { text: `❌ Could not resolve the channel from this link.` };
              }
            }

            // Get target message ID (latest if not specified in link)
            let targetMsgId = messageId;
            if (!targetMsgId) {
              const fetchedMsgs = await sock.newsletterFetchMessages(newsletterJid, 1);
              if (fetchedMsgs && fetchedMsgs.length > 0) {
                targetMsgId = fetchedMsgs[0].id;
              } else {
                return { text: `❌ No recent messages found in this channel to react to.` };
              }
            }

            // Send all 30 reactions sequentially with a 400ms delay to keep it stable
            for (const emoji of targetEmojis) {
              await sock.newsletterReactMessage(newsletterJid, targetMsgId, emoji);
              await new Promise(resolve => setTimeout(resolve, 400)); 
            }

            return { 
              text: `✅ Successfully deployed all **30 reactions** to the channel update!` 
            };

          } catch (err) {
            console.error("Failed to react to channel link:", err);
            return { text: `❌ Failed to process the channel link. Check console for details.` };
          }
        } 
        
        // --- CASE 2: REPLIED MESSAGE REACT LOOP ---
        else {
          const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
          
          if (!contextInfo || !contextInfo.stanzaId) {
            return { 
              text: `⚠️ Invalid usage! Either provide a channel link or reply to a message.\n*Usage:* \`.react 👍 ❤️ 🔥\`` 
            };
          }

          const targetKey = {
            remoteJid: remoteJid,
            id: contextInfo.stanzaId,
            participant: contextInfo.participant || remoteJid,
            fromMe: contextInfo.participant ? (contextInfo.participant === sock.user?.id) : false
          };

          try {
            for (const emoji of targetEmojis) {
              await sock.sendMessage(remoteJid, {
                react: {
                  text: emoji,
                  key: targetKey
                }
              });
              await new Promise(resolve => setTimeout(resolve, 400)); // 400ms delay between reactions
            }
            return; // Suppress text response if reactions deploy successfully
          } catch (err) {
            console.error("Failed to send message reactions:", err);
            return { text: `❌ Failed to send reactions to the message.` };
          }
        }
      }
    }
  }
};