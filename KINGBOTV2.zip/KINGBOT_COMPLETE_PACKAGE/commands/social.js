const axios = require('axios');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

// Hardcoded permanent TikTok Access Token
const TIKTOK_TOKEN = "act.AakjgJDxgiK2J02Ty5xB2Lsm074FuV1H7XflzCjbq1pCODk9lgS8H3tHe9CM!5736.s1";

module.exports = {
  commands: {
    post: {
      desc: "Post a video directly to TikTok",
      run: async (ctx) => {
        let caption = ctx.args.join(" ");

        const rawMessage = ctx.quoted ? ctx.quoted : ctx.msg;
        const videoMessage = rawMessage?.message?.videoMessage || rawMessage?.videoMessage;

        if (!videoMessage) {
          return "⚠️ *Usage:* Please reply directly to a video file with `.post <optional caption>`!";
        }

        try {
          // Step 1: Query creator info first (Mandatory requirement for TikTok API)
          const creatorRes = await axios.post("https://open.tiktokapis.com/v2/post/publish/creator_info/query/", {}, {
            headers: {
              "Authorization": `Bearer ${TIKTOK_TOKEN}`,
              "Content-Type": "application/json; charset=UTF-8"
            }
          });

          const creatorData = creatorRes.data?.data;
          if (!creatorData || !creatorData.privacy_level_options) {
            return `❌ *Creator Info Failed:* \`\`\`json\n${JSON.stringify(creatorRes.data, null, 2)}\n\`\`\``;
          }

          // Force SELF_ONLY since the app is currently in sandbox/unaudited mode
          const allowedPrivacy = creatorData.privacy_level_options.includes("SELF_ONLY") 
            ? "SELF_ONLY" 
            : creatorData.privacy_level_options[0];

          // Step 2: Download media using standard Baileys stream
          const stream = await downloadContentFromMessage(videoMessage, 'video');
          let buffer = Buffer.from([]);
          for await(const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
          }
          const videoBuffer = buffer;
          const videoSize = videoBuffer.length;
          const mimeType = videoMessage.mimetype || "video/mp4";
          
          caption = caption || videoMessage.caption || "Posted via Kingbot 🚀";

          if (videoSize === 0) return "❌ *Error:* Failed to download video from WhatsApp.";

          // Step 3: Initialize upload with TikTok FILE_UPLOAD using the allowed sandbox privacy level
          const initRes = await axios.post("https://open.tiktokapis.com/v2/post/publish/video/init/", {
            post_info: {
              title: caption,
              privacy_level: allowedPrivacy,
              disable_duet: false,
              disable_comment: false,
              disable_stitch: false
            },
            source_info: {
              source: "FILE_UPLOAD",
              video_size: videoSize,
              chunk_size: videoSize,
              total_chunk_count: 1
            }
          }, {
            headers: {
              "Authorization": `Bearer ${TIKTOK_TOKEN}`,
              "Content-Type": "application/json; charset=UTF-8"
            }
          });

          const uploadUrl = initRes.data?.data?.upload_url;
          const publishId = initRes.data?.data?.publish_id;

          if (!uploadUrl || !publishId) {
            return `❌ *File Upload Init Failed:* \`\`\`json\n${JSON.stringify(initRes.data, null, 2)}\n\`\`\``;
          }

          // Step 4: Upload the binary video buffer to TikTok's upload_url via PUT request
          await axios.put(uploadUrl, videoBuffer, {
            headers: {
              "Content-Type": mimeType,
              "Content-Length": videoSize,
              "Content-Range": `bytes 0-${videoSize - 1}/${videoSize}`
            }
          });

          return `✅ *Direct Video Upload Complete!* \n\nPublish ID: \`${publishId}\`\nPrivacy: \`${allowedPrivacy}\` (Sandbox Mode)\nTikTok is processing your video. Check your private drafts/profile on TikTok in a few minutes!`;
          
        } catch (e) {
          const errorMsg = e.response?.data ? JSON.stringify(e.response.data, null, 2) : e.message;
          return `❌ *Error:* \n\`\`\`json\n${errorMsg}\n\`\`\``;
        }
      }
    }
  }
};