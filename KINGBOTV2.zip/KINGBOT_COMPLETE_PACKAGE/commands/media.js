const { downloadMediaMessage } = require("@whiskeysockets/baileys");
const sharp = require("sharp");
const { PREFIX } = require("../config");

function getQuotedOrDirectMedia(ctx) {
  const quoted = ctx.msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  return quoted ? { message: quoted, key: ctx.msg.key } : ctx.msg;
}

module.exports = {
  category: "Media",
  commands: {
    sticker: {
      desc: "Reply to an image with .sticker to convert it into a sticker (image only, no video/GIF)",
      run: async (ctx) => {
        const target = getQuotedOrDirectMedia(ctx);
        if (!target.message?.imageMessage) {
          return `Reply to an image with ${PREFIX}sticker\n(Video/animated stickers aren't supported yet.)`;
        }
        try {
          const buffer = await downloadMediaMessage(target, "buffer", {});
          const webp = await sharp(buffer)
            .resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
            .webp()
            .toBuffer();
          return { sticker: webp };
        } catch (err) {
          return `⚠️ Couldn't convert that to a sticker: ${err.message}`;
        }
      },
    },
    toimg: {
      desc: "Reply to a sticker with .toimg to convert it back into a regular image",
      run: async (ctx) => {
        const target = getQuotedOrDirectMedia(ctx);
        if (!target.message?.stickerMessage) return `Reply to a sticker with ${PREFIX}toimg`;
        try {
          const buffer = await downloadMediaMessage(target, "buffer", {});
          const jpeg = await sharp(buffer).jpeg().toBuffer();
          return { image: jpeg, caption: "✅ Converted back to image" };
        } catch (err) {
          return `⚠️ Couldn't convert that sticker: ${err.message}`;
        }
      },
    },
  },
};