const { isOwner } = require("../utils");
const state = require("../state");

// Initialize default services in state if not already present
if (!state.businessServices) {
  state.businessServices = `🏢 *OFFICIAL BUSINESS SERVICES* 🏢\n\n` +
    `Welcome! Here is our available service catalog:\n\n` +
    `📌 *1. Registration & Pins*\n` +
    `- UTME Registration Pin\n` +
    `- Result Checker Scratch Cards\n\n` +
    `🔍 *2. Result Checking*\n` +
    `- Checking of O'Level Results\n` +
    `- Checking of JAMB Results\n\n` +
    `🎓 *3. Academic Services*\n` +
    `- Admission Processing\n\n` +
    `💳 *4. Financial & Digital Services*\n` +
    `- Online Payment Services\n` +
    `- Ebook Sales\n\n` +
    `💻 *5. Tech & Development*\n` +
    `- Custom Website Development for Clients\n\n` +
    `💬 *To place an order reply with ussd or to make inquiries, reply directly to this chat or message the management!*`;
}

module.exports = {
  category: "Business",
  commands: {
    services: {
      desc: "View or update the business service catalog",
      run: async (ctx) => {
        const { args } = ctx;
        
        // Update on the fly: !services set <new text>
        if (args[0]?.toLowerCase() === "set") {
          if (!isOwner(ctx)) {
            return "⚠️ Only the bot owner can update the business service catalog.";
          }
          const newText = args.slice(1).join(" ");
          if (!newText) {
            return "⚠️ Please provide the new services text.";
          }
          state.businessServices = newText;
          return "✅ Business service catalog has been successfully updated!";
        }

        // Default action: display the current catalog
        return state.businessServices;
      },
    },
  },
};