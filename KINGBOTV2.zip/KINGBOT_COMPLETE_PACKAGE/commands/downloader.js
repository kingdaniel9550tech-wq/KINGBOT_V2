// commands/downloader.js
const axios = require('axios');
const fs = require('fs');
const path = require('path');

// API Configurations
const API_BASE = 'https://apis.davidcyril.name.ng';
const FB_API_TIMEOUT_MS = 45000;
const SONG_API_TIMEOUT_MS = 90000;
const MAX_VIDEO_BYTES = 50 * 1024 * 1024; // 50MB WhatsApp-friendly limit

// Ensure temporary storage directory exists for disk management
const TMP_DIR = path.join(__dirname, "../tmp");
if (!fs.existsSync(TMP_DIR)) {
    fs.mkdirSync(TMP_DIR, { recursive: true });
}

// Helper: Safely delete temp files to prevent ENOSPC disk space errors
function cleanupFile(filePath) {
    try {
        if (filePath && fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }
    } catch (err) {
        console.error("Failed to clean up temp file:", err);
    }
}

// Helper: Check if user is the bot owner
function checkOwner(m) {
    const sender = m.sender || m.key?.participant || m.chat || '';
    const cleanSender = sender.replace(/[^0-9]/g, '');
    const owners = global.owner || global.owners || [];
    
    return m.key?.fromMe || m.isOwner || owners.some(o => cleanSender.includes(o.replace(/[^0-9]/g, '')));
}

// ==========================================
// FACEBOOK HELPERS
// ==========================================
async function resolveFacebookUrl(inputUrl) {
    let url = inputUrl.trim();
    if (url.includes('/share/')) {
        try {
            const response = await axios.get(url, {
                maxRedirects: 5,
                timeout: 8000,
                headers: { 
                    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.5 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1' 
                }
            });
            const finalUrl = response.request?.res?.responseUrl;
            if (finalUrl && !finalUrl.includes('/share/')) {
                url = finalUrl;
            } else if (typeof response.data === 'string') {
                const ogMatch = response.data.match(/property="og:url"\s+content="([^"]+)"/);
                if (ogMatch && ogMatch[1]) url = ogMatch[1];
            }
        } catch (_) {}
    }
    return url;
}

async function fetchFacebookMedia(inputUrl) {
    const resolvedUrl = await resolveFacebookUrl(inputUrl);

    const { data } = await axios.get(`${API_BASE}/facebook`, {
        params: { url: resolvedUrl },
        timeout: FB_API_TIMEOUT_MS,
    });

    if (!data || !data.status || !data.result) {
        throw new Error('No valid response from the Facebook API.');
    }

    const res = data.result;
    const mediaUrl = 
        (res.downloads && res.downloads.hd && res.downloads.hd.url) || 
        (res.downloads && res.downloads.sd && res.downloads.sd.url) || 
        res.download_url || 
        res.url ||
        res.image ||
        (res.images && res.images[0]);

    if (!mediaUrl) {
        throw new Error('Could not extract media download link. Make sure the link is public.');
    }

    return {
        title: res.title || res.caption || 'Facebook Media',
        duration: res.duration || 'N/A',
        mediaUrl
    };
}

// ==========================================
// SONG / PLAY2 HELPERS
// ==========================================
async function fetchSong(query) {
    const { data } = await axios.get(`${API_BASE}/song`, {
        params: { query },
        timeout: SONG_API_TIMEOUT_MS,
    });

    if (!data || !data.status || !data.result || !data.result.audio || !data.result.audio.download_url) {
        throw new Error('Song not found. Try a different title or artist.');
    }

    return data.result; 
}

// ==========================================
// VIDEO HELPERS
// ==========================================
async function fetchVideoSong(query) {
    const { data } = await axios.get(`${API_BASE}/song`, {
        params: { query },
        timeout: SONG_API_TIMEOUT_MS,
    });

    const videoUrl = data?.result?.video?.download_url || data?.result?.video_url;
    if (!data || !data.status || !videoUrl) {
        throw new Error('Video not found. Try a different title or artist.');
    }

    try {
        const head = await axios.head(videoUrl, { timeout: 15000 });
        const size = Number(head.headers['content-length']);
        if (size && size > MAX_VIDEO_BYTES) {
            throw new Error(`That video is too large to send (${(size / 1024 / 1024).toFixed(1)}MB, limit ${MAX_VIDEO_BYTES / 1024 / 1024}MB). Try a different title match.`);
        }
    } catch (e) {
        if (e.message && e.message.startsWith('That video is too large')) throw e;
    }

    return {
        title: data.result.title || 'Unknown Title',
        artist: data.result.artist || data.result.channel || 'Unknown Artist',
        duration: data.result.duration || 'N/A',
        views: data.result.views || data.result.viewCount || 'N/A',
        likes: data.result.likes || 'N/A',
        thumbnail: data.result.thumbnail || null,
        videoUrl,
    };
}

module.exports = {
  category: "downloaders",
  commands: {
    // ==========================================
    // 1. FACEBOOK / FB COMMAND (Public)
    // ==========================================
    facebook: {
      aliases: ["fb"],
      description: "Download public Facebook videos, reels, and photos",
      run: async (ctx) => {
        const { sock, msg, args, remoteJid, usedPrefix = "." } = ctx;
        const link = args.join(' ').trim();

        if (!link || (!link.includes('facebook.com') && !link.includes('fb.watch') && !link.includes('fb.me'))) {
          return `┏━━━〔 *🔍 FACEBOOK DOWNLOADER* 〕━━━\n┃\n┃ Please provide a valid Facebook link!\n┃\n┗━━━ *Example:* \`${usedPrefix}fb https://www.facebook.com/reel/...\``;
        }

        try {
          await sock.sendMessage(remoteJid, { react: { text: '⏳', key: msg.key } });
        } catch (_) {}

        let result;
        try {
          result = await fetchFacebookMedia(link);
        } catch (err) {
          try {
            await sock.sendMessage(remoteJid, { react: { text: '❌', key: msg.key } });
          } catch (_) {}

          const isTimeout = err.code === 'ECONNABORTED' || /timeout/i.test(err.message || '');
          const friendly = isTimeout
            ? 'The Facebook service took too long to respond. Try again in a moment.'
            : (err.message || 'Something went wrong fetching that media.');

          return `┏━━━〔 *❌ DOWNLOAD FAILED* 〕━━━\n┃\n┃ ${friendly}\n┗━━━━━━━━━━━━━━━━━━━━`;
        }

        const caption = 
            `┏━━━〔 👑 *KINGBOT FB DOWNLOADER* 👑 〕━━━\n` +
            `┃\n` +
            `┃ 🎬 *Title:* ${result.title}\n` +
            `┃ ⏱️ *Duration:* ${result.duration}\n` +
            `┃ 📂 *Format:* High Quality Media\n` +
            `┃\n` +
            `┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `> _⚡ Powered by KingBot_`;

        try {
          const mediaResponse = await axios.get(result.mediaUrl, {
            responseType: 'arraybuffer',
            timeout: 60000
          });
          
          const buffer = Buffer.from(mediaResponse.data);
          const contentType = mediaResponse.headers['content-type'] || '';

          if (contentType.includes('image')) {
            await sock.sendMessage(remoteJid, { image: buffer, caption }, { quoted: msg });
          } else {
            await sock.sendMessage(remoteJid, { video: buffer, mimetype: 'video/mp4', caption }, { quoted: msg });
          }

          try {
            await sock.sendMessage(remoteJid, { react: { text: '✅', key: msg.key } });
          } catch (_) {}

          return;
        } catch (err) {
          try {
            await sock.sendMessage(remoteJid, { react: { text: '❌', key: msg.key } });
          } catch (_) {}
          return `❌ Found media metadata, but failed to download/send the file: ${err.message || 'unknown error'}`;
        }
      }
    },

    fb: {
      description: "Alias for facebook downloader",
      run: async (ctx) => {
        return module.exports.commands.facebook.run(ctx);
      }
    },

    // ==========================================
    // 2. PLAY2 COMMAND (Owner Only)
    // ==========================================
    play2: {
      description: "Search and download audio tracks with views, likes, and rich UI (Owner Only)",
      run: async (ctx) => {
        const { sock, msg, args, remoteJid, usedPrefix = "." } = ctx;

        if (!checkOwner(msg)) {
          return `┏━━━〔 🔒 *ACCESS DENIED* 〕━━━\n┃\n┃ This command is restricted to the *Bot Owner* only!\n┃\n┗━━━━━━━━━━━━━━━━━━━━`;
        }

        const query = args.join(' ').trim();
        if (!query) {
          return `┏━━━〔 *🔍 SONG SEARCH ERROR* 〕━━━\n┃\n┃ Please provide a track name or artist!\n┃\n┗━━━ *Example:* \`${usedPrefix}play2 baba\`\n`;
        }

        try {
          await sock.sendMessage(remoteJid, { react: { text: '⏳', key: msg.key } });
        } catch (_) {}

        let result;
        try {
          result = await fetchSong(query);
        } catch (err) {
          try {
            await sock.sendMessage(remoteJid, { react: { text: '❌', key: msg.key } });
          } catch (_) {}

          const isTimeout = err.code === 'ECONNABORTED' || /timeout/i.test(err.message || '');
          const friendly = isTimeout
            ? 'The song service took too long to respond. Try again in a moment.'
            : (err.message || 'Something went wrong fetching that song.');

          return `┏━━━〔 *❌ DOWNLOAD FAILED* 〕━━━\n┃\n┃ ${friendly}\n┗━━━━━━━━━━━━━━━━━━━━`;
        }

        const title = result.title || 'Unknown';
        const duration = result.duration || 'N/A';
        const views = result.views || result.viewCount || 'N/A';
        const likes = result.likes || 'N/A';
        const artist = result.artist || result.channel || 'N/A';

        try {
          const caption = 
            `┏━━━〔 👑 *KINGBOT MUSIC DOWNLOADER* 👑 〕━━━\n` +
            `┃\n` +
            `┃ 🎵 *Track:* ${title}\n` +
            `┃ 👤 *Artist:* ${artist}\n` +
            `┃ ⏱️ *Duration:* ${duration}\n` +
            `┃ 👀 *Views:* ${views}\n` +
            `┃ 👍 *Likes:* ${likes}\n` +
            `┃ 📂 *Format:* High Quality MP3\n` +
            `┃\n` +
            `┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `> _⚡ Powered by KingBot_`;

          if (result.thumbnail) {
            await sock.sendMessage(remoteJid, { image: { url: result.thumbnail }, caption }, { quoted: msg });
          } else {
            await sock.sendMessage(remoteJid, { text: caption }, { quoted: msg });
          }
        } catch (err) {
          console.error('play2: failed to send info card:', err.message || err);
        }

        try {
          await sock.sendMessage(remoteJid, {
            audio: { url: result.audio.download_url },
            mimetype: 'audio/mpeg',
            ptt: false
          }, { quoted: msg });

          try {
            await sock.sendMessage(remoteJid, { react: { text: '✅', key: msg.key } });
          } catch (_) {}

          return;
        } catch (err) {
          try {
            await sock.sendMessage(remoteJid, { react: { text: '❌', key: msg.key } });
          } catch (_) {}
          return `❌ Found the track info, but failed to stream the audio file: ${err.message || 'unknown error'}`;
        }
      }
    },

    // ==========================================
    // 3. VIDEO COMMAND (Public)
    // ==========================================
    video: {
      description: "Search and download video tracks with views, likes, and rich KingBot UI",
      run: async (ctx) => {
        const { sock, msg, args, remoteJid, usedPrefix = "." } = ctx;
        const query = args.join(' ').trim();

        if (!query) {
          return `┏━━━〔 *🔍 VIDEO SEARCH ERROR* 〕━━━\n┃\n┃ Please provide a video title or artist!\n┃\n┗━━━ *Example:* \`${usedPrefix}video kingdaniel9550\`\n`;
        }

        try {
          await sock.sendMessage(remoteJid, { react: { text: '⏳', key: msg.key } });
        } catch (_) {}

        let result;
        try {
          result = await fetchVideoSong(query);
        } catch (err) {
          try {
            await sock.sendMessage(remoteJid, { react: { text: '❌', key: msg.key } });
          } catch (_) {}

          const isTimeout = err.code === 'ECONNABORTED' || /timeout/i.test(err.message || '');
          const friendly = isTimeout
            ? 'The video service took too long to respond. Try again in a moment.'
            : (err.message || 'Something went wrong fetching that video.');

          return `┏━━━〔 *❌ DOWNLOAD FAILED* 〕━━━\n┃\n┃ ${friendly}\n┗━━━━━━━━━━━━━━━━━━━━`;
        }

        try {
          const caption = 
            `┏━━━〔 👑 *KINGBOT VIDEO DOWNLOADER* 👑 〕━━━\n` +
            `┃\n` +
            `┃ 🎬 *Title:* ${result.title}\n` +
            `┃ 👤 *Artist:* ${result.artist}\n` +
            `┃ ⏱️ *Duration:* ${result.duration}\n` +
            `┃ 👀 *Views:* ${result.views}\n` +
            `┃ 👍 *Likes:* ${result.likes}\n` +
            `┃ 📂 *Format:* High Quality MP4\n` +
            `┃\n` +
            `┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `> _⚡ Powered by KingBot_`;

          if (result.thumbnail) {
            await sock.sendMessage(remoteJid, { image: { url: result.thumbnail }, caption }, { quoted: msg });
          } else {
            await sock.sendMessage(remoteJid, { text: caption }, { quoted: msg });
          }
        } catch (err) {
          console.error('video: failed to send info card:', err.message || err);
        }

        try {
          await sock.sendMessage(remoteJid, {
            video: { url: result.videoUrl },
            mimetype: 'video/mp4',
            caption: `🎬 *Now Playing:* ${result.title}`
          }, { quoted: msg });

          try {
            await sock.sendMessage(remoteJid, { react: { text: '✅', key: msg.key } });
          } catch (_) {}

          return;
        } catch (err) {
          try {
            await sock.sendMessage(remoteJid, { react: { text: '❌', key: msg.key } });
          } catch (_) {}
          return `❌ Found the video info, but failed to stream the video file: ${err.message || 'unknown error'}`;
        }
      }
    },

    // ==========================================
    // 4. CLEARCACHE COMMAND (Utility)
    // ==========================================
    clearcache: {
      description: "Manually clear temporary cache files from server storage",
      run: async () => {
        try {
          if (!fs.existsSync(TMP_DIR)) {
            return `📁 Temporary folder is already empty.`;
          }
          const files = fs.readdirSync(TMP_DIR);
          let count = 0;
          for (const file of files) {
            fs.unlinkSync(path.join(TMP_DIR, file));
            count++;
          }
          return `🧹 Successfully cleared ${count} temporary file(s) from server storage!`;
        } catch (err) {
          return `❌ Error clearing cache: ${err.message}`;
        }
      }
    }
  }
};