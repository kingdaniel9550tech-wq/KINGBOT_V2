const fs = require('fs');
const path = require('path');

module.exports = {
  category: "business",
  commands: {
    sales: {
      description: "View total business revenue and financial breakdown (Owner only)",
      async run(ctx) {
        const { sock, remoteJid, msg } = ctx;

        // Owner verification check
        const ownerJid = sock.user?.id || "";
        const ownerPhoneNum = ownerJid ? ownerJid.split("@")[0].split(":")[0] : "";
        const configOwnerNum = process.env.OWNER_NUMBER || "";
        const sender = msg.key.participant || remoteJid;
        const isOwner = msg.key.fromMe || 
          (ownerPhoneNum && sender.includes(ownerPhoneNum)) || 
          (configOwnerNum && sender.includes(configOwnerNum));

        if (!isOwner) return { text: "⛔ Access Denied!" };

        // Load orders directly from persistent storage
        const ordersFile = path.join(__dirname, '../data/orders.json');
        let orders = [];
        try {
          if (fs.existsSync(ordersFile)) {
            const raw = JSON.parse(fs.readFileSync(ordersFile, 'utf8'));
            // Handles Map entries format [[id, data], ...]
            orders = raw.map(entry => Array.isArray(entry) ? entry[1] : entry);
          }
        } catch (e) {
          console.error("Error reading orders database:", e);
        }

        let totalRevenue = 0;
        let completedCount = 0;
        let pendingCount = 0;

        for (const order of orders) {
          const numericAmount = parseInt(String(order.amount || "0").replace(/[^0-9]/g, "")) || 0;
          const status = String(order.status || "").toLowerCase();

          if (status.includes("completed") || status.includes("verified") || status.includes("dispensed")) {
            totalRevenue += numericAmount;
            completedCount++;
          } else {
            pendingCount++;
          }
        }

        return {
          text: `📊 *K I N G D A N I E L  •  S A L E S  R E P O R T*\n` +
                `─────────────────────────────\n\n` +
                `💰 *Total Revenue:* \`₦${totalRevenue.toLocaleString()}\`\n` +
                `📦 *Total Orders:* ${orders.length}\n` +
                `✅ *Successful / Paid:* ${completedCount}\n` +
                `⏳ *Pending / Queued:* ${pendingCount}\n\n` +
                `─────────────────────────────\n` +
                `⚡ _POWERED BY KINGBOT_`
        };
      }
    }
  }
};