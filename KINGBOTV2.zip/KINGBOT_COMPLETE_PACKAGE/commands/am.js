const axios = require("axios");

module.exports = {
  category: "downloader",
  commands: {
    am: {
      description: "Download music tracks from Audiomack",
      async run(ctx) {
        const { sock, remoteJid, args, msg } = ctx;
        const url = args[0];

        if (!url || !url.includes("audiomack.com")) {
          return {
            text: "⚠️ Please provide a valid Audiomack song URL!\n*Usage:* `!am https://audiomack.com/...`"
          };
        }

        await sock.sendMessage(remoteJid, { text: "⏳ Fetching your Audiomack track, please wait..." }, { quoted: msg });

        // Updated array of alternative active public scraper endpoints
        const apis = [
          `https://api.ryzendesu.vip/api/downloader/audiomack?url=${encodeURIComponent(url)}`,
          `https://deliriussapi-v2.fly.dev/download/audiomack?url=${encodeURIComponent(url)}`,
          `https://api.siputzx.my.id/api/down/audiomack?url=${encodeURIComponent(url)}`
        ];

        let trackData = null;

        for (const endpoint of apis) {
          try {
            const res = await axios.get(endpoint, { timeout: 7000 });
            const data = res.data;
            
            // Handle different possible JSON structural responses from public APIs
            if (data && (data.status || data.success || data.data)) {
              trackData = data.data || data.result || data;
              if (trackData && (trackData.download || trackData.url || trackData.audio)) {
                break;
              }
            }
          } catch (e) {
            // Silently continue to the next fallback endpoint
          }
        }

        if (!trackData) {
          return { 
            text: "❌ Failed." 
          };
        }

        const audioUrl = trackData.download || trackData.url || trackData.audio;
        const title = trackData.title || trackData.name || "Audiomack Track";
        const artist = trackData.artist || trackData.creator || "Unknown Artist";

        if (!audioUrl) {
          return { text: "❌ Could not retrieve the direct audio stream for this track." };
        }

        try {
          await sock.sendMessage(
            remoteJid,
            {
              audio: { url: audioUrl },
              mimetype: "audio/mpeg",
              fileName: `${artist} - ${title}.mp3`,
              caption: `🎵 *Title:* ${title}\n👤 *Artist:* ${artist}\n🤖 *Powered by ${process.env.BOT_NAME || "KingBot"}*`
            },
            { quoted: msg }
          );
        } catch (err) {
          console.error("Audiomack send error:", err);
          return { text: "⚠️ Failed to send the downloaded audio file to chat." };
        }
      }
    },
    audiomack: {
      description: "Alias for am download",
      async run(ctx) {
        return module.exports.commands.am.run(ctx);
      }
    }
  }
};