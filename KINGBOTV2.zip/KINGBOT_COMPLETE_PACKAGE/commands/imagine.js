module.exports = {
  category: "ai",
  description: "Generate AI images (Owner only)",
  commands: {
    imagine: {
      category: "ai",
      description: "Generate an AI image from text (Owner only). Usage: .imagine a futuristic city",
      async run(ctx) {
        const { sock, remoteJid, msg, args } = ctx;

        // Strict Owner Verification Check
        const ownerJid = sock.user?.id || "";
        const ownerPhoneNum = ownerJid ? ownerJid.split("@")[0].split(":")[0] : "";
        const configOwnerNum = process.env.OWNER_NUMBER || "";
        const sender = msg.key.participant || remoteJid;
        const isOwner = msg.key.fromMe || (ownerPhoneNum && sender.includes(ownerPhoneNum)) || (configOwnerNum && sender.includes(configOwnerNum));

        if (!isOwner) {
          return { text: "⚠️ *Access Denied:* This command is restricted to the bot owner only." };
        }

        const prompt = args.join(" ").trim();

        if (!prompt) {
          return { text: "⚠️ Usage: `.imagine <description>`" };
        }

        try {
          await sock.sendMessage(remoteJid, { text: "🎨 *Kingbot is painting your masterpiece... Please wait.*" });

          const encodedPrompt = encodeURIComponent(prompt);
          const imageUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}`;

          await sock.sendMessage(remoteJid, {
            image: { url: imageUrl },
            caption: `👑 *Kingbot Generated:* "${prompt}"`
          });

          return;

        } catch (err) {
          return { text: `❌ Error generating image: ${err.message || err}` };
        }
      }
    }
  }
};