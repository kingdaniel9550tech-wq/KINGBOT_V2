const { PREFIX } = require("../config");
const { isOwner } = require("../utils");
const state = require("../state");

state.lidMap = state.lidMap || {};

let groupScheduleIdCounter = 1;

function getMentionedOrQuoted(ctx) {
  const mentioned = ctx.msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
  const quotedParticipant = ctx.msg.message?.extendedTextMessage?.contextInfo?.participant;
  if (mentioned.length) return mentioned;
  if (quotedParticipant) return [quotedParticipant];
  return [];
}

function stripDevice(id) {
  return id.replace(/:\d+@/, "@");
}

function getMyIds(ctx) {
  const sources = [
    ctx.sock.user?.id,
    ctx.sock.user?.lid,
    ctx.sock.authState?.creds?.me?.id,
    ctx.sock.authState?.creds?.me?.lid,
  ];
  return [...new Set(sources.filter(Boolean).map(stripDevice))];
}

function resolveDisplayId(sock, participant, ctx) {
  let pid = participant.id || participant.jid;
  if (!pid) return "unknown";

  if (state.lidMap[pid]) {
    return state.lidMap[pid];
  }

  if (pid.endsWith("@lid")) {
    if (sock.signalRepository?.lidMapping && typeof sock.signalRepository.lidMapping.getPNForLID === "function") {
      const pn = sock.signalRepository.lidMapping.getPNForLID(pid);
      if (pn) {
        state.lidMap[pid] = pn;
        return pn;
      }
    }
  }

  if (participant.phoneNumber && !participant.phoneNumber.endsWith("@lid")) {
    state.lidMap[pid] = participant.phoneNumber;
    return participant.phoneNumber;
  }
  if (participant.participantAlt && !participant.participantAlt.endsWith("@lid")) {
    state.lidMap[pid] = participant.participantAlt;
    return participant.participantAlt;
  }

  if (ctx && ctx.sender && !ctx.sender.endsWith("@lid")) {
    if (ctx.sender.includes(pid.split("@")[0])) {
      state.lidMap[pid] = ctx.sender;
      return ctx.sender;
    }
  }

  return pid;
}

async function requireGroupAdmin(ctx) {
  if (!ctx.remoteJid.endsWith("@g.us")) return "⚠️ This command only works in groups.";
  const meta = await ctx.sock.groupMetadata(ctx.remoteJid);
  const myIds = getMyIds(ctx);
  const me = meta.participants.find((p) => myIds.includes(stripDevice(p.id)));
  if (!me || (me.admin !== "admin" && me.admin !== "superadmin")) {
    return "⚠️ I need to be an admin access required.";
  }
  return null;
}

module.exports = {
  category: "Group Admin",
  commands: {
    kick: {
      desc: "Reply to or mention a user with !kick to remove them from the group",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const err = await requireGroupAdmin(ctx);
        if (err) return err;
        const targets = getMentionedOrQuoted(ctx);
        if (!targets.length) return `Mention or reply to a user with ${PREFIX}kick`;
        await ctx.sock.groupParticipantsUpdate(ctx.remoteJid, targets, "remove");
        return "✅ Removed from the group.";
      },
    },
    add: {
      desc: "(Owner only) Add a user by number, e.g. !add 2348012345678",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const err = await requireGroupAdmin(ctx);
        if (err) return err;
        const number = ctx.args[0];
        if (!number) return `Usage: ${PREFIX}add <number>`;
        await ctx.sock.groupParticipantsUpdate(ctx.remoteJid, [`${number}@s.whatsapp.net`], "add");
        return "✅ Added to the group.";
      },
    },
    promote: {
      desc: "(Owner only) Reply to or mention a user with !promote to make them admin",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const err = await requireGroupAdmin(ctx);
        if (err) return err;
        const targets = getMentionedOrQuoted(ctx);
        if (!targets.length) return `Mention or reply to a user with ${PREFIX}promote`;
        await ctx.sock.groupParticipantsUpdate(ctx.remoteJid, targets, "promote");
        return "✅ Promoted to admin.";
      },
    },
    demote: {
      desc: "(Owner only) Reply to or mention a user with !demote to remove admin",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const err = await requireGroupAdmin(ctx);
        if (err) return err;
        const targets = getMentionedOrQuoted(ctx);
        if (!targets.length) return `Mention or reply to a user with ${PREFIX}demote`;
        await ctx.sock.groupParticipantsUpdate(ctx.remoteJid, targets, "demote");
        return "✅ Demoted from admin.";
      },
    },
    mute: {
      desc: "(Owner only) Restrict the group so only admins can send messages",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const err = await requireGroupAdmin(ctx);
        if (err) return err;
        await ctx.sock.groupSettingUpdate(ctx.remoteJid, "announcement");
        return "🔇 Group muted — only admins can send messages.";
      },
    },
    unmute: {
      desc: "(Owner only) Allow all participants to send messages again",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const err = await requireGroupAdmin(ctx);
        if (err) return err;
        await ctx.sock.groupSettingUpdate(ctx.remoteJid, "not_announcement");
        return "🔊 Group unmuted — everyone can send messages.";
      },
    },
    tag: {
      desc: "(Admin & Owner) Tag all group members cleanly with a royal broadcast layout",
      run: async (ctx) => {
        if (!ctx.remoteJid.endsWith("@g.us")) return "⚠️ This command only works in groups.";
        const meta = await ctx.sock.groupMetadata(ctx.remoteJid);
        
        const senderJid = ctx.msg.key.participant || ctx.msg.participant || ctx.sender || "";
        const participant = meta.participants.find((p) => stripDevice(p.id) === stripDevice(senderJid));
        const isAdmin = participant && (participant.admin === "admin" || participant.admin === "superadmin");
        const ownerCheck = isOwner(ctx);

        if (!ownerCheck && !isAdmin) {
          return "⚠️ This command is restricted to Group Admins and the Bot Owner only.";
        }

        const reason = ctx.args.join(" ").trim() || "Attention Required, Royals!";

        const senderDisplay = resolveDisplayId(ctx.sock, { id: senderJid }, ctx);
        const senderNum = senderDisplay.split("@")[0];
        const senderMentionJid = senderDisplay.includes("@") ? senderDisplay : `${senderNum}@s.whatsapp.net`;

        let text = `╔═══════════════════════════╗\n`;
        text += `║   👑 *KING DANIEL* 👑   \n`;
        text += `╚═══════════════════════════╝\n\n`;
        text += `📢 *Group:* ${meta.subject}\n`;
        text += `👑 *Sender:* @${senderNum}\n`;
        text += `💬 *Notice:* ${reason}\n\n`;
        text += `👥 *Audience:* All ${meta.participants.length} Members (@all)\n\n`;
        text += `> _⚡ Powered by KingBot_`;

        const mentions = [];
        for (let p of meta.participants) {
          const displayId = resolveDisplayId(ctx.sock, p, ctx);
          const phoneNum = displayId.split("@")[0];
          const mentionJid = displayId.includes("@") ? displayId : `${phoneNum}@s.whatsapp.net`;
          mentions.push(mentionJid);
        }

        if (senderJid && !mentions.includes(senderMentionJid)) {
          mentions.push(senderMentionJid);
        }

        return { text, mentions };
      },
    },
    hidetag: {
      desc: "(Owner only) Send a message that pings everyone without listing them, e.g. !hidetag Meeting now",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        if (!ctx.remoteJid.endsWith("@g.us")) return "⚠️ This command only works in groups.";
        const meta = await ctx.sock.groupMetadata(ctx.remoteJid);
        const mentions = meta.participants.map((p) => p.id || p.jid);
        const text = ctx.args.join(" ") || "📢 Attention everyone";
        return { text, mentions };
      },
    },
    setgname: {
      desc: "(Owner only) Change the group name, e.g. !setgname New Name",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const err = await requireGroupAdmin(ctx);
        if (err) return err;
        const name = ctx.args.join(" ");
        if (!name) return `Usage: ${PREFIX}setgname <new name>`;
        await ctx.sock.groupUpdateSubject(ctx.remoteJid, name);
        return "✅ Group name updated.";
      },
    },
    setgdesc: {
      desc: "(Owner only) Change the group description",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const err = await requireGroupAdmin(ctx);
        if (err) return err;
        const desc = ctx.args.join(" ");
        if (!desc) return `Usage: ${PREFIX}setgdesc <new description>`;
        await ctx.sock.groupUpdateDescription(ctx.remoteJid, desc);
        return "✅ Group description updated.";
      },
    },
    grouplink: {
      desc: "(Owner only) Get the group's invite link",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const err = await requireGroupAdmin(ctx);
        if (err) return err;
        const code = await ctx.sock.groupInviteCode(ctx.remoteJid);
        return `🔗 https://chat.whatsapp.com/${code}`;
      },
    },
    revokelink: {
      desc: "(Owner only) Revoke the current invite link and generate a new one",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const err = await requireGroupAdmin(ctx);
        if (err) return err;
        const code = await ctx.sock.groupRevokeInvite(ctx.remoteJid);
        return `🔄 New invite link: https://chat.whatsapp.com/${code}\nThe old link no longer works.`;
      },
    },
    groupinfo: {
      desc: "(Owner only) Show group name, description, and participant count",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        if (!ctx.remoteJid.endsWith("@g.us")) return "⚠️ This command only works in groups.";
        const meta = await ctx.sock.groupMetadata(ctx.remoteJid);
        const adminCount = meta.participants.filter((p) => p.admin === "admin" || p.admin === "superadmin").length;
        return `📋 *${meta.subject}*\n${meta.desc ? meta.desc + "\n" : ""}👥 Participants: ${meta.participants.length}\n👑 Admins: ${adminCount}`;
      },
    },
    listadmins: {
      desc: "(Owner only) List all admins in the group",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        if (!ctx.remoteJid.endsWith("@g.us")) return "⚠️ This command only works in groups.";
        const meta = await ctx.sock.groupMetadata(ctx.remoteJid);
        const admins = meta.participants.filter((p) => p.admin === "admin" || p.admin === "superadmin");
        if (!admins.length) return "No admins found.";
        const mentions = admins.map((p) => p.id || p.jid);
        const text = "👑 *Group Admins*\n" + admins.map((p) => {
          const displayId = resolveDisplayId(ctx.sock, p, ctx);
          return `@${displayId.split("@")[0]}`;
        }).join("\n");
        return { text, mentions };
      },
    },
    leavegroup: {
      desc: "(Owner only) Make the bot leave the current group",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        if (!ctx.remoteJid.endsWith("@g.us")) return "⚠️ This command only works in groups.";
        await ctx.sock.groupLeave(ctx.remoteJid);
        return "👋 Left the group.";
      },
    },
    botstatus: {
      desc: "(Owner only) Debug: show how the bot's own identity compares against this group's participant list",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        if (!ctx.remoteJid.endsWith("@g.us")) return "⚠️ This command only works in groups.";
        const meta = await ctx.sock.groupMetadata(ctx.remoteJid);
        const myIds = getMyIds(ctx);
        const me = meta.participants.find((p) => myIds.includes(stripDevice(p.id)));
        const sample = meta.participants.slice(0, 5).map((p) => `${p.id} (${p.admin || "member"})`).join("\n");
        return `🤖 sock.user.id: ${ctx.sock.user?.id}\n🤖 sock.user.lid: ${ctx.sock.user?.lid || "(none)"}\n🤖 creds.me.id: ${ctx.sock.authState?.creds?.me?.id || "(none)"}\n🤖 creds.me.lid: ${ctx.sock.authState?.creds?.me?.lid || "(none)"}\n🤖 all IDs checked: ${myIds.join(", ")}\n\n👥 First few participants:\n${sample}\n\n${me ? `✅ Matched as: ${me.id} (${me.admin || "member"})` : "❌ Could not find myself in the participant list."}`;
      },
    },
    creategroup: {
      desc: "(Owner only) Create a new group: !creategroup <name> | <2348012345678,2348098765432>",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const rest = ctx.args.join(" ");
        const [name, numbersStr] = rest.split("|").map((s) => s.trim());
        if (!name || !numbersStr) return `Usage: ${PREFIX}creategroup <name> | <comma-separated numbers>`;
        const participants = numbersStr.split(",").map((n) => `${n.trim()}@s.whatsapp.net`);
        try {
          const meta = await ctx.sock.groupCreate(name, participants);
          const code = await ctx.sock.groupInviteCode(meta.id).catch(() => null);
          return `✅ Group created: *${name}*\n${code ? `🔗 https://chat.whatsapp.com/${code}` : ""}`;
        } catch (err) {
          return `⚠️ Couldn't create the group: ${err.message}`;
        }
      },
    },
    createchannel: {
      desc: "(Owner only) Create a WhatsApp Channel: !createchannel <name> | <description>",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const rest = ctx.args.join(" ");
        const [name, description] = rest.split("|").map((s) => s.trim());
        if (!name) return `Usage: ${PREFIX}createchannel <name> | <description>`;
        if (typeof ctx.sock.newsletterCreate !== "function") {
          return "⚠️ Channel creation isn't supported by the installed Baileys version — this is a newer feature that may need a library update.";
        }
        try {
          const channel = await ctx.sock.newsletterCreate(name, description || "");
          return `✅ Channel created: *${name}*\nID: ${channel.id}`;
        } catch (err) {
          return `⚠️ Couldn't create the channel: ${err.message}`;
        }
      },
    },
    groupschedule: {
      desc: "(Owner only) Auto close/open this group at a set daily time: !groupschedule close|open <HH:MM>, !groupschedule list, !groupschedule remove <id>",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const sub = (ctx.args[0] || "").toLowerCase();
        if (sub === "list") {
          if (!state.groupSchedules.length) return "No group open/close schedules set.";
          return "⏰ *Group schedules*\n" + state.groupSchedules.map((j) => `#${j.id} — ${j.action} at ${j.time} — chat ...${j.jid.slice(-8)}`).join("\n");
        }
        if (sub === "remove") {
          const id = parseInt(ctx.args[1]);
          const before = state.groupSchedules.length;
          const filtered = state.groupSchedules.filter((j) => j.id !== id);
          state.groupSchedules.length = 0;
          state.groupSchedules.push(...filtered);
          if (state.groupSchedules.length === before) return `No group schedule with id #${id}.`;
          return `✅ Removed group schedule #${id}.`;
        }
        if (sub === "close" || sub === "open") {
          if (!ctx.remoteJid.endsWith("@g.us")) return "⚠️ This command only works in groups.";
          const time = ctx.args[1];
          if (!/^\d{2}:\d{2}$/.test(time || "")) {
            return `Usage: ${PREFIX}groupschedule ${sub} <HH:MM>\nTime uses the server's clock (same as .schedule messages).\nAt that time daily, this group will be set to ${sub === "close" ? "admins-only messaging" : "everyone can message"}.`;
          }
          const job = { id: groupScheduleIdCounter++, jid: ctx.remoteJid, action: sub, time, lastFired: null };
          state.groupSchedules.push(job);
          return `✅ Scheduled #${job.id}: this group will *${sub}* daily at ${time}.\n(Note: I still need to be a group admin at that time for this to actually take effect, and this resets if the bot restarts.)`;
        }
        return `Usage:\n${PREFIX}groupschedule close <HH:MM>\n${PREFIX}groupschedule open <HH:MM>\n${PREFIX}groupschedule list\n${PREFIX}groupschedule remove <id>`;
      },
    },
    activemembers: {
      desc: "(Owner only) List members active recently, based on messages seen since the bot started: !activemembers [minutes=60]",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        if (!ctx.remoteJid.endsWith("@g.us")) return "⚠️ This command only works in groups.";
        const minutes = parseInt(ctx.args[0]) || 60;
        const cutoff = Date.now() - minutes * 60000;
        const activity = ctx.groupActivity.get(ctx.remoteJid) || new Map();
        const active = [...activity.entries()].filter(([, ts]) => ts >= cutoff).map(([jid]) => jid);
        if (!active.length) {
          return `No tracked activity in the last ${minutes} minutes.\n(This only counts messages sent since the bot last started, and it's message activity — not true online/offline presence, which WhatsApp doesn't reliably expose via the API.)`;
        }
        const text = `🟢 *Active in the last ${minutes}m* (${active.length})\n` + active.map((j) => {
          let pid = j;
          if (pid.endsWith("@lid") && ctx.sock.signalRepository?.lidMapping?.getPNForLID) {
            const pn = ctx.sock.signalRepository.lidMapping.getPNForLID(pid);
            if (pn) pid = pn;
          }
          return `@${pid.split("@")[0]}`;
        }).join("\n");
        return { text, mentions: active };
      },
    },
  },
};