const {
  jokes, quotes, facts, memes, compliments, insults, truths, dares, wyr,
  pickuplines, fortunes, excuses, advices, tonguetwisters, superheroes, villains,
  catfacts, dogfacts, horoscopes,
} = require("../data");
const { PREFIX } = require("../config");

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

module.exports = {
  category: "Fun",
  commands: {
    joke: { desc: "Get a random joke", run: async () => `😂 ${pick(jokes)}` },
    quote: { desc: "Get an inspirational quote", run: async () => `💬 ${pick(quotes)}` },
    fact: { desc: "Get a random fun fact", run: async () => `🧠 ${pick(facts)}` },
    meme: { desc: "Get a random meme (text)", run: async () => `${pick(memes)}` },
    eightball: {
      desc: "Ask the magic 8-ball a question, e.g. !eightball will it rain?",
      run: async (ctx) => {
        const answers = ["Yes, definitely.", "No way.", "Ask again later.", "It is certain.", "Very doubtful.", "Signs point to yes.", "Cannot predict now."];
        if (!ctx.args.length) return `Usage: ${PREFIX}eightball <question>`;
        return `🎱 ${pick(answers)}`;
      },
    },
    roll: {
      desc: "Roll a dice (1-6), or !roll <sides>",
      run: async (ctx) => {
        const sides = parseInt(ctx.args[0]) || 6;
        return `🎲 You rolled a ${Math.floor(Math.random() * sides) + 1} (out of ${sides})`;
      },
    },
    flip: {
      desc: "Flip a coin",
      run: async () => `🪙 ${Math.random() < 0.5 ? "Heads" : "Tails"}!`,
    },
    ship: {
      desc: "Ship two names together, e.g. !ship John Jane",
      run: async (ctx) => {
        if (ctx.args.length < 2) return `Usage: ${PREFIX}ship <name1> <name2>`;
        const [a, b] = ctx.args;
        const name = a.slice(0, Math.ceil(a.length / 2)) + b.slice(Math.floor(b.length / 2));
        const pct = Math.floor(Math.random() * 101);
        return `💘 ${a} + ${b} = *${name}*\nCompatibility: ${pct}%`;
      },
    },
    truth: { desc: "Get a truth question", run: async () => `🤔 Truth: ${pick(truths)}` },
    dare: { desc: "Get a dare", run: async () => `🔥 Dare: ${pick(dares)}` },
    wyr: { desc: "Get a 'would you rather' question", run: async () => `🤷 ${pick(wyr)}` },
    rate: {
      desc: "Rate anything out of 10, e.g. !rate pizza",
      run: async (ctx) => {
        if (!ctx.args.length) return `Usage: ${PREFIX}rate <something>`;
        return `⭐ I rate "${ctx.args.join(" ")}" a ${Math.floor(Math.random() * 11)}/10`;
      },
    },
    compliment: { desc: "Get a random compliment", run: async () => `💖 ${pick(compliments)}` },
    insult: { desc: "Get a playful (friendly) roast", run: async () => `😏 ${pick(insults)}` },
    roast: {
      desc: "Playfully roast someone by name, e.g. !roast John",
      run: async (ctx) => {
        const name = ctx.args.join(" ");
        if (!name) return `Usage: ${PREFIX}roast <name>`;
        return `🔥 ${name}, ${pick(insults).charAt(0).toLowerCase() + pick(insults).slice(1)}`;
      },
    },
    pickupline: { desc: "Get a cheesy pickup line", run: async () => `😘 ${pick(pickuplines)}` },
    fortune: { desc: "Get a fortune-cookie style message", run: async () => `🥠 ${pick(fortunes)}` },
    excuse: { desc: "Get a random excuse", run: async () => `🙈 ${pick(excuses)}` },
    advice: { desc: "Get a piece of random life advice", run: async () => `💡 ${pick(advices)}` },
    tonguetwister: { desc: "Get a tongue twister to try out loud", run: async () => `👅 ${pick(tonguetwisters)}` },
    superhero: {
      desc: "Get assigned a random superhero identity, e.g. !superhero (or !superhero <name> to personalize)",
      run: async (ctx) => {
        const name = ctx.args.join(" ");
        const hero = pick(superheroes);
        return name ? `🦸 ${name}, your superhero identity is: *${hero}*` : `🦸 Your superhero identity is: *${hero}*`;
      },
    },
    villain: {
      desc: "Get assigned a random villain identity, e.g. !villain (or !villain <name> to personalize)",
      run: async (ctx) => {
        const name = ctx.args.join(" ");
        const villain = pick(villains);
        return name ? `🦹 ${name}, your villain identity is: *${villain}*` : `🦹 Your villain identity is: *${villain}*`;
      },
    },
    catfact: { desc: "Get a random cat fact", run: async () => `🐱 ${pick(catfacts)}` },
    dogfact: { desc: "Get a random dog fact", run: async () => `🐶 ${pick(dogfacts)}` },
    horoscope: {
      desc: "Get today's horoscope for a zodiac sign, e.g. !horoscope leo",
      run: async (ctx) => {
        const sign = (ctx.args[0] || "").toLowerCase();
        if (!sign || !horoscopes[sign]) {
          return `Usage: ${PREFIX}horoscope <sign>\nSigns: ${Object.keys(horoscopes).join(", ")}`;
        }
        return `🔮 *${sign.charAt(0).toUpperCase() + sign.slice(1)}*: ${horoscopes[sign]}`;
      },
    },
    slogan: {
      desc: "Generate a fun slogan for a word/business, e.g. !slogan CoffeeShop",
      run: async (ctx) => {
        const word = ctx.args.join(" ");
        if (!word) return `Usage: ${PREFIX}slogan <word or business name>`;
        const templates = [
          `${word}: Because ordinary just isn't good enough.`,
          `${word} — where quality meets simplicity.`,
          `Life's better with ${word}.`,
          `${word}: You'll wonder how you lived without it.`,
          `Think ${word}. Think ahead.`,
        ];
        return `📣 ${pick(templates)}`;
      },
    },
  },
};
