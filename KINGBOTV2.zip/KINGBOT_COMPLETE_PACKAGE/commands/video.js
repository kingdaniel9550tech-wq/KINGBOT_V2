// commands/video.js
const axios = require('axios');

const VIDEO_API_BASE = 'https://apis.davidcyril.name.ng';
const VIDEO_API_PATH = '/song'; // Returns both audio and video data
const VIDEO_API_TIMEOUT_MS = 90000; // 90s timeout
const MAX_VIDEO_BYTES = 50 * 1024 * 1024; // 50MB WhatsApp-friendly limit

async function fetchVideoSong(query) {
    const { data } = await axios.get(`${VIDEO_API_BASE}${VIDEO_API_PATH}`, {
        params: { query },
        timeout: VIDEO_API_TIMEOUT_MS,
    });

    const videoUrl = data?.result?.video?.download_url || data?.result?.video_url;
    if (!data || !data.status || !videoUrl) {
        throw new Error('Video not found. Try a different title or artist.');
    }

    // Pre-check file size via HEAD request to prevent crashing on large files
    try {
        const head = await axios.head(videoUrl, { timeout: 15000 });
        const size = Number(head.headers['content-length']);
        if (size && size > MAX_VIDEO_BYTES) {
            throw new Error(`That video is too large to send (${(size / 1024 / 1024).toFixed(1)}MB, limit ${MAX_VIDEO_BYTES / 1024 / 1024}MB). Try a different title match.`);
        }
    } catch (e) {
        if (e.message && e.message.startsWith('That video is too large')) throw e;
        // Non-fatal if HEAD check fails (e.g. server blocks HEAD requests), proceed anyway
    }

    return {
        title: data.result.title || 'Unknown Title',
        artist: data.result.artist || data.result.channel || 'Unknown Artist',
        duration: data.result.duration || 'N/A',
        views: data.result.views || data.result.viewCount || 'N/A',
        likes: data.result.likes || 'N/A',
        thumbnail: data.result.thumbnail || null,
        videoUrl,
    };
}

module.exports = {
  category: "downloader",
  commands: {
    video: {
      description: "Search and download video tracks with views, likes, and rich KingBot UI",
      run: async (ctx) => {
        const { sock, msg, args, remoteJid, usedPrefix = "." } = ctx;
        const query = args.join(' ').trim();

        if (!query) {
          return `┏━━━〔 *🔍 VIDEO SEARCH ERROR* 〕━━━\n┃\n┃ Please provide a video title or artist!\n┃\n┗━━━ *Example:* \`${usedPrefix}video believer imagine dragons\`\n`;
        }

        try {
          await sock.sendMessage(remoteJid, { react: { text: '⏳', key: msg.key } });
        } catch (_) {}

        let result;
        try {
          result = await fetchVideoSong(query);
        } catch (err) {
          try {
            await sock.sendMessage(remoteJid, { react: { text: '❌', key: msg.key } });
          } catch (_) {}

          const isTimeout = err.code === 'ECONNABORTED' || /timeout/i.test(err.message || '');
          const friendly = isTimeout
            ? 'The video service took too long to respond. Try again in a moment.'
            : (err.message || 'Something went wrong fetching that video.');

          return `┏━━━〔 *❌ DOWNLOAD FAILED* 〕━━━\n┃\n┃ ${friendly}\n┗━━━━━━━━━━━━━━━━━━━━`;
        }

        // Rich KingBot UI Box Layout
        try {
          const caption = 
            `┏━━━〔 👑 *KINGBOT VIDEO DOWNLOADER* 👑 〕━━━\n` +
            `┃\n` +
            `┃ 🎬 *Title:* ${result.title}\n` +
            `┃ 👤 *Artist:* ${result.artist}\n` +
            `┃ ⏱️ *Duration:* ${result.duration}\n` +
            `┃ 👀 *Views:* ${result.views}\n` +
            `┃ 👍 *Likes:* ${result.likes}\n` +
            `┃ 📂 *Format:* High Quality MP4\n` +
            `┃\n` +
            `┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `> _⚡ Powered by KingBot Media Stream_`;

          if (result.thumbnail) {
            await sock.sendMessage(remoteJid, { image: { url: result.thumbnail }, caption }, { quoted: msg });
          } else {
            await sock.sendMessage(remoteJid, { text: caption }, { quoted: msg });
          }
        } catch (err) {
          console.error('video: failed to send info card:', err.message || err);
        }

        // Send the actual video file
        try {
          await sock.sendMessage(remoteJid, {
            video: { url: result.videoUrl },
            mimetype: 'video/mp4',
            caption: `🎬 *Now Playing:* ${result.title}`
          }, { quoted: msg });

          try {
            await sock.sendMessage(remoteJid, { react: { text: '✅', key: msg.key } });
          } catch (_) {}

          return;
        } catch (err) {
          try {
            await sock.sendMessage(remoteJid, { react: { text: '❌', key: msg.key } });
          } catch (_) {}
          return `❌ Found the video info, but failed to stream the video file: ${err.message || 'unknown error'}`;
        }
      }
    }
  }
};