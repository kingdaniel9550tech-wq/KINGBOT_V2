// commands/general.js
const { PREFIX, BOT_NAME, OWNER_NUMBER, OWNER_NAME } = require("../config");
const state = require("../state");
const os = require("os");

let startTime = Date.now();

function fmtUptime() {
  const s = Math.floor((Date.now() - startTime) / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${h}h ${m}m ${sec}s`;
}

function ramBar() {
  const total = os.totalmem();
  const free = os.freemem();
  const usedPercent = Math.round(((total - free) / total) * 100);
  const filled = Math.round(usedPercent / 10);
  const bar = "█".repeat(filled) + "░".repeat(10 - filled);
  return `${bar} ${usedPercent}%`;
}

module.exports = {
  category: "General",
  commands: {
    menu: {
      desc: "Show the full command menu",
      run: async (ctx) => {
        const { registry } = ctx;
        const byCat = {};
        
        // Normalize categories to uppercase to prevent duplicates
        for (const [name, cmd] of Object.entries(registry)) {
          const rawCat = cmd.category || "General";
          const cat = rawCat.trim().toUpperCase();
          byCat[cat] = byCat[cat] || [];
          byCat[cat].push(name);
        }

        // Accurate WAT (Africa/Lagos) time & date fix
        const now = new Date();
        const date = now.toLocaleDateString('en-CA', { timeZone: 'Africa/Lagos' });
        const time = now.toLocaleTimeString('en-GB', { timeZone: 'Africa/Lagos', hour12: false });

        let text = `╭━━━〔 👑 *KINGBOT* 👑 〕━━━⬡\n`;
        text += `┃ 🚀 *System*  : KINGBOT created by KING DANIEL\n`;
        text += `┃ 👤 *Owner*   : ${OWNER_NAME}\n`;
        text += `┃ 📞 *Contact* : wa.me/${OWNER_NUMBER}\n`;
        text += `┃ 📅 *Date*    : ${date}\n`;
        text += `┃ ⏰ *Time*    : ${time} WAT\n`;
        text += `┃ 📊 *Cmds*    : ${Object.keys(registry).length} Total\n`;
        text += `┃ ⚙️ *Prefix*  : [ ${PREFIX} ]\n`;
        text += `┃ 💽 *RAM*     : ${ramBar()}\n`;
        text += `┃ ⏱️ *Uptime*  : ${fmtUptime()}\n`;
        text += `╰━━━━━━━━━━━━━━━━━━━━━━━⬡\n\n`;

        text += `> _*KINGBOT ANNOUNCEMENT*: *“PLEASE SOME COMMANDS ARE DOWN AND ARE NOT WORKING PERFECTLY AT THE MOMENT, BUT WE'RE ALREADY WORKING TO FIX THEM AS SOON AS POSSIBLE, SORRY FOR ANY INCONVENIENCE YOU MIGHT EXPERIENCE.”*_\n\n`;

        for (const [cat, cmds] of Object.entries(byCat)) {
          text += `┏━━⟡ *${cat}* (${cmds.length}) ⟡━━┓\n`;
          
          // Render gorgeous, clean side-by-side command pills
          for (let i = 0; i < cmds.length; i += 2) {
            const cmd1 = `◈ \`${PREFIX}${cmds[i]}\``;
            const cmd2 = cmds[i + 1] ? `◈ \`${PREFIX}${cmds[i + 1]}\`` : "";
            text += `┃ ${cmd1.padEnd(20)} ${cmd2}\n`;
          }
          text += `┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n`;
        }

        text += `*⚡ Powered by KingBot*`;
        return text;
      },
    },
    help: {
      desc: "Show help for a command, e.g. !help sticker",
      run: async (ctx) => {
        const { args, registry } = ctx;
        if (!args[0]) return `Usage: ${PREFIX}help <command>\nOr use ${PREFIX}menu to see everything.`;
        const cmd = registry[args[0].toLowerCase()];
        if (!cmd) return `No such command: ${args[0]}`;
        return `*${PREFIX}${args[0]}*\n${cmd.desc}`;
      },
    },
    ping: {
      desc: "Check if the bot is alive and response speed",
      run: async () => {
        const start = Date.now();
        return `🏓 Pong! (${Date.now() - start}ms)`;
      },
    },
    alive: {
      desc: "Confirm the bot is online",
      run: async () => `${BOT_NAME} KingBot is alive and running!`,
    },
    owner: {
      desc: "Get the bot owner's contact",
      run: async () => `👑 Owner: ${OWNER_NAME}\nwa.me/${OWNER_NUMBER}`,
    },
    runtime: {
      desc: "Show how long the bot has been running",
      run: async () => `⏱️ Uptime: ${fmtUptime()}`,
    },
    info: {
      desc: "General info about the bot",
      run: async () => `${BOT_NAME} *KingBot*\nBuilt with Baileys (Node.js)\nPrefix: ${PREFIX}\nUse ${PREFIX}menu to see all commands.`,
    },
    jid: {
      desc: "Show the chat's WhatsApp JID",
      run: async (ctx) => `🆔 ${ctx.remoteJid}`,
    },
    credits: {
      desc: "Show credits",
      run: async () => `${BOT_NAME} KingBot — built for you by KING DANIEL with Baileys, Node.js, and a lot of commands.`,
    },
    report: {
      desc: "Report a bug or issue, e.g. !report <message>",
      run: async (ctx) => {
        if (!ctx.args.length) return `Usage: ${PREFIX}report <describe the issue>`;
        return `📩 Thanks, your report has been noted: "${ctx.args.join(" ")}"`;
      },
    },
    whoami: {
      desc: "Debug: show the sender ID the bot sees vs the configured OWNER_NUMBER",
      run: async (ctx) => {
        const numberMatch = ctx.sender.split("@")[0] === OWNER_NUMBER;
        const isOwner = ctx.isFromMe || numberMatch;
        return `🪪 sender: ${ctx.sender}\n🆔 chat (remoteJid): ${ctx.remoteJid}\n👑 configured OWNER_NUMBER: ${OWNER_NUMBER}\n📨 fromMe: ${ctx.isFromMe}\n${isOwner ? "✅ Recognized as owner — owner commands will work here." : "❌ NOT recognized as owner here."}`;
      },
    },
    mode: {
      desc: "Show whether the bot is currently in public or private mode",
      run: async () => `🔒 Bot mode: *${state.mode}*`,
    },
    gatecheck: {
      desc: "Debug: simulate whether the private-mode gate would block this sender",
      run: async (ctx) => {
        const numberMatch = ctx.sender.split("@")[0] === OWNER_NUMBER;
        const owner = ctx.isFromMe || numberMatch;
        const blocked = state.mode === "private" && !owner;
        return `🔒 mode: ${state.mode}\n📨 fromMe: ${ctx.isFromMe}\n👑 owner match: ${owner}\n${blocked ? "🚫 This sender WOULD be blocked in private mode." : "✅ This sender would be allowed through."}`;
      },
    },
  },
};