const axios = require('axios');

module.exports = {
  category: "Downloader",
  commands: {
    tiktok: {
      desc: "Download a TikTok video without watermark",
      run: async (ctx) => {
        const { args, msg } = ctx;
        const conn = ctx.client || ctx.sock || ctx.conn;
        
        // Comprehensive search for chat ID across different bot structures
        const chatId = ctx.from || ctx.chat || msg?.key?.remoteJid || msg?.chatId || msg?.from;
        const url = args[0];

        if (!url || !url.includes("tiktok.com")) {
          return "⚠️ Please provide a valid TikTok video link.\nExample: `.tiktok https://vm.tiktok.com/...`";
        }

        try {
          // Fetch video data from TikWM API
          const response = await axios.get(`https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
              'Accept': 'application/json, text/plain, */*'
            },
            timeout: 15000
          });
          
          const resData = response.data;

          if (!resData || resData.code !== 0 || !resData.data || !resData.data.play) {
            return `❌ API Error: ${resData?.msg || "Failed to fetch video. Make sure the link is public."}`;
          }

          const videoUrl = resData.data.play;
          const title = resData.data.title || "TikTok Video";
          const author = resData.data.author?.nickname || "Unknown Creator";
          const caption = `🎬 *Kingbot Downloader*\n\n*Title:* ${title}\n*Creator:* ${author}\n\n⚡️ _Powered by Kingbot⚡️_`;

          // If valid connection and chat ID exist, send video file directly
          if (conn && conn.sendMessage && chatId && typeof chatId === 'string') {
            await conn.sendMessage(chatId, {
              video: { url: videoUrl },
              caption: caption
            }, { quoted: msg });
            return;
          } 
          
          // Fallback response with your branded watermark and direct stream link
          return `✅ *Kingbot Downloader*\n\n*Title:* ${title}\n*Creator:* ${author}\n\n📥 *Direct Video Link:* ${videoUrl}\n\n🤖 _⚡️Powered by Kingbot⚡️`;

        } catch (error) {
          console.error("TikTok download detailed error:", error);
          return `❌ Download Error: ${error.response?.data?.message || error.message || "Unknown error occurred"}`;
        }
      },
    },
  },
};