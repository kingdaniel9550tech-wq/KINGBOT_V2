const db = require('../db');

// Ensure required database tables and columns exist automatically on startup
async function initTables() {
  try {
    await db.query(`
      CREATE TABLE IF NOT EXISTS licenses (
        token TEXT PRIMARY KEY,
        is_used BOOLEAN DEFAULT FALSE,
        is_premium BOOLEAN DEFAULT FALSE,
        bound_number TEXT
      );
    `);
    await db.query(`
      CREATE TABLE IF NOT EXISTS premium_users (
        whatsapp_jid TEXT PRIMARY KEY
      );
    `);
    // Auto-patch missing columns if table already existed
    await db.query(`ALTER TABLE premium_users ADD COLUMN IF NOT EXISTS phone_number TEXT;`);

    await db.query(`
      CREATE TABLE IF NOT EXISTS active_users (
        whatsapp_jid TEXT PRIMARY KEY,
        last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    await db.query(`ALTER TABLE active_users ADD COLUMN IF NOT EXISTS phone_number TEXT;`);
  } catch (err) {
    console.error("Failed to initialize license/user tables:", err);
  }
}
initTables();

module.exports = {
  category: "Admin",
  commands: {
    
    // 1. GENERATE LICENSE KEY
    genkey: {
      description: "Generate a new license token. Format: .genkey [prem]",
      async run({ args, isFromMe }) {
        if (!isFromMe) return "❌ Unauthorized.";
        
        const isPremKey = args[0]?.toLowerCase() === "prem" || args[0]?.toLowerCase() === "premium";
        const token = "KING-" + Math.random().toString(36).substring(2, 10).toUpperCase();
        
        try {
          await db.query("INSERT INTO licenses (token, is_used, is_premium) VALUES ($1, $2, $3)", [token, false, isPremKey]);
          return `🔑 *New ${isPremKey ? '⭐ Premium ' : ''}License Generated:*\n\`${token}\``;
        } catch (err) {
          return `❌ Database Error: ${err.message}`;
        }
      }
    },

    // 2. ADD PREMIUM (Works for both paired and unpaired numbers)
    addprem: {
      description: "Add any user (paired or unpaired) to premium. Format: .addprem <phone>",
      async run({ args, isFromMe }) {
        if (!isFromMe) return "❌ Unauthorized.";
        const phone = args[0]?.replace(/[^0-9]/g, "");
        if (!phone) return "❌ Provide a phone number: `.addprem 2348123456789`";
        
        const whatsappJid = `${phone}@s.whatsapp.net`;
        
        try {
          await db.query(
            `INSERT INTO premium_users (whatsapp_jid, phone_number) VALUES ($1, $2) 
             ON CONFLICT (whatsapp_jid) DO UPDATE SET phone_number = $2`,
            [whatsappJid, phone]
          );

          await db.query(
            "UPDATE licenses SET is_premium = TRUE WHERE bound_number = $1", 
            [phone]
          );

          return `⭐ Successfully added *${phone}* to Premium!\n_Works universally for both paired and unpaired users._`;
        } catch (err) {
          return `❌ Error: ${err.message}`;
        }
      }
    },

    // 3. REMOVE PREMIUM
    delprem: {
      description: "Revoke premium status from a phone number. Format: .delprem <phone>",
      async run({ args, isFromMe }) {
        if (!isFromMe) return "❌ Unauthorized.";
        const phone = args[0]?.replace(/[^0-9]/g, "");
        if (!phone) return "❌ Provide a phone number: `.delprem 2348123456789`";
        
        const whatsappJid = `${phone}@s.whatsapp.net`;
        
        try {
          await db.query("DELETE FROM premium_users WHERE whatsapp_jid = $1 OR phone_number = $2", [whatsappJid, phone]);
          await db.query("UPDATE licenses SET is_premium = FALSE WHERE bound_number = $1", [phone]);

          return `🗑️ Revoked Premium status from *${phone}*.`;
        } catch (err) {
          return `❌ Error: ${err.message}`;
        }
      }
    },

    // 4. RESET BOT SESSION & FREE TOKEN
    resetbot: {
      description: "Wipe a user's bot session and free their license. Format: .resetbot <phone>",
      async run({ args, isFromMe }) {
        if (!isFromMe) return "❌ Unauthorized.";
        const phone = args[0]?.replace(/[^0-9]/g, "");
        if (!phone) return "❌ Provide a phone number: `.resetbot 2347032151106`";

        const tenantId = `bot_${phone}`;

        try {
          await db.query("DELETE FROM whatsapp_sessions WHERE tenant_id = $1", [tenantId]);
          const res = await db.query(
            "UPDATE licenses SET bound_number = NULL, is_used = FALSE, is_premium = FALSE WHERE bound_number = $1 RETURNING token",
            [phone]
          );

          return `🧹 *Bot Session Reset Successful!*\n\n` +
                 `📱 Phone: \`${phone}\`\n` +
                 `🔓 Token Released: \`${res.rows[0]?.token || 'None linked'}\``;
        } catch (err) {
          return `❌ Error resetting bot: ${err.message}`;
        }
      }
    },

    // 5. VIEW ALL TOTAL USERS (Paired & Unpaired)
    allusers: {
      description: "View total users in database (paired, unpaired, and active)",
      async run({ isFromMe }) {
        if (!isFromMe) return "❌ Unauthorized.";

        try {
          const pairedRes = await db.query("SELECT COUNT(*) FROM licenses WHERE bound_number IS NOT NULL");
          const activeRes = await db.query("SELECT COUNT(*) FROM active_users");
          const premRes = await db.query("SELECT COUNT(*) FROM premium_users");
          const totalLicensesRes = await db.query("SELECT COUNT(*) FROM licenses");

          return `📊 *Database User Statistics*\n\n` +
                 `📱 Paired Bot Instances: *${pairedRes.rows[0].count}*\n` +
                 `💬 Active / Unpaired Users (Messaged Bot): *${activeRes.rows[0].count}*\n` +
                 `⭐ Total Premium Users: *${premRes.rows[0].count}*\n` +
                 `🔑 Total Generated Licenses: *${totalLicensesRes.rows[0].count}*`;
        } catch (err) {
          return `❌ Error fetching user stats: ${err.message}`;
        }
      }
    },

    // 6. STATS COMMAND
    stats: {
      description: "Check general bot and license metrics",
      async run({ isFromMe }) {
        if (!isFromMe) return "❌ Unauthorized.";
        
        try {
          const totalRes = await db.query("SELECT COUNT(*) FROM licenses");
          const usedRes = await db.query("SELECT COUNT(*) FROM licenses WHERE is_used = TRUE");
          const premRes = await db.query("SELECT COUNT(*) FROM premium_users");
          const activeRes = await db.query("SELECT COUNT(*) FROM active_users");
          
          return `📊 *Bot & License Statistics*\n\n` +
                 `🔑 Total Licenses: ${totalRes.rows[0].count}\n` +
                 `📱 Paired Instances: ${usedRes.rows[0].count}\n` +
                 `💬 Interacted Users: ${activeRes.rows[0].count}\n` +
                 `⭐ Total Premium Users: ${premRes.rows[0].count}`;
        } catch (err) {
          return `❌ Error fetching stats: ${err.message}`;
        }
      }
    }

  }
};
