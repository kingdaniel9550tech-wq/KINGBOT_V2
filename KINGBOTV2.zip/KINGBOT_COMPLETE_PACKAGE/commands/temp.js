const fs = require('fs');
const path = require('path');
const { isOwner } = require("../utils");

const LIMIT_FILE = path.join(__dirname, '../data/temp_limits.json');
const CRED_FILE = path.join(__dirname, '../data/temp_creds.json');
const MAX_FREE_USES = 2;
const OWNER_PHONE = '2349073828261';
const BRANDING = '\n\n⚡️POWERED BY KINGBOT⚡️';

function cleanSender(id) {
    if (!id) return '';
    return id.toString().split('@')[0].split(':')[0].replace(/\D/g, '');
}

function saveCreds(email, password, senderId) {
    let data = {};
    if (fs.existsSync(CRED_FILE)) {
        try { data = JSON.parse(fs.readFileSync(CRED_FILE, 'utf8')); } catch(e) {}
    }
    const cleanOwner = cleanSender(senderId);
    data[email] = { password, owner: cleanOwner };
    const dir = path.dirname(CRED_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(CRED_FILE, JSON.stringify(data, null, 2));
}

function getAccountDetails(email) {
    if (!fs.existsSync(CRED_FILE)) return null;
    try {
        const data = JSON.parse(fs.readFileSync(CRED_FILE, 'utf8'));
        const entry = data[email];
        if (!entry) return null;
        if (typeof entry === 'string') {
            return { password: entry, owner: '' };
        }
        return entry;
    } catch(e) {
        return null;
    }
}

function checkAndIncrementLimit(senderId) {
    const cleanId = cleanSender(senderId);
    if (cleanId && cleanId.includes(OWNER_PHONE)) {
        return { allowed: true, remaining: 'Unlimited (Owner)' };
    }

    let data = {};
    if (fs.existsSync(LIMIT_FILE)) {
        try {
            data = JSON.parse(fs.readFileSync(LIMIT_FILE, 'utf8'));
        } catch (e) {
            data = {};
        }
    }

    const today = new Date().toISOString().split('T')[0];
    if (!data[senderId] || data[senderId].date !== today) {
        data[senderId] = { date: today, count: 0 };
    }

    if (data[senderId].count >= MAX_FREE_USES) {
        return { allowed: false, remaining: 0 };
    }

    data[senderId].count += 1;
    
    const dir = path.dirname(LIMIT_FILE);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    
    fs.writeFileSync(LIMIT_FILE, JSON.stringify(data, null, 2));
    return { allowed: true, remaining: MAX_FREE_USES - data[senderId].count };
}

module.exports = {
  category: "Utility",
  commands: {
    temp: {
      desc: "Generates private temporary emails, checks inboxes, and deletes messages with clean King IDs",
      run: async (ctx) => {
        const rawSender = ctx.sender || ctx.from || ctx.key?.remoteJid || ctx.key?.participant || '';
        const senderClean = cleanSender(rawSender);
        const userIsOwner = senderClean.includes(OWNER_PHONE) || (typeof isOwner === 'function' && isOwner(ctx));
        
        let args = ctx.args || [];
        if (typeof ctx.text === 'string') {
            const parts = ctx.text.trim().split(/\s+/);
            args = parts.slice(1);
        }

        const subAction = args[0] ? args[0].toLowerCase() : '';

        // Handle inbox checking with clean King-X IDs
        if (subAction === 'inbox') {
            const emailAddress = args[1];
            if (!emailAddress || !emailAddress.includes('@')) {
                return `⚠️ Usage error: !temp inbox <email_address>${BRANDING}`;
            }

            try {
                const account = getAccountDetails(emailAddress);
                if (!account) {
                    return `⚠️ Cannot check inbox: Session not found locally for this address.${BRANDING}`;
                }

                if (!userIsOwner) {
                    if (!account.owner || !senderClean || account.owner !== senderClean) {
                        return `🔒 *Privacy Alert:* Access denied. This temporary email is private and locked to its creator!${BRANDING}`;
                    }
                }

                const password = account.password;

                const tokenRes = await fetch('https://api.mail.tm/token', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ address: emailAddress, password: password })
                });
                const tokenData = await tokenRes.json();
                if (!tokenData.token) {
                    return `❌ Failed to authenticate with mail provider.${BRANDING}`;
                }

                const msgRes = await fetch('https://api.mail.tm/messages', {
                    headers: { 'Authorization': `Bearer ${tokenData.token}` }
                });
                const messagesList = await msgRes.json();
                const messages = Array.isArray(messagesList) ? messagesList : (messagesList['hydra:member'] || []);

                if (messages.length === 0) {
                    return `📭 Inbox for *${emailAddress}* is currently empty.${BRANDING}`;
                }

                let replyText = `📬 *Inbox for ${emailAddress} (${messages.length} messages):*\n\n`;
                let index = 1;
                for (const msg of messages.slice(0, 5)) {
                    const kingId = `King-${index}`;
                    replyText += `🆔 *ID:* \`${kingId}\`\n`;
                    replyText += `👤 *From:* ${msg.from?.address || 'Unknown'}\n`;
                    replyText += `📌 *Subject:* ${msg.subject || 'No Subject'}\n`;
                    replyText += `💬 *Message:* ${msg.intro || 'No text preview'}\n`;
                    replyText += `📅 *Date:* ${msg.createdAt || 'N/A'}\n`;
                    replyText += `--- \n`;
                    index++;
                }
                return replyText + BRANDING;

            } catch (error) {
                return `❌ Inbox Error: ${error.message}${BRANDING}`;
            }
        }

        // Handle single message deletion using King-X format
        if (subAction === 'delete') {
            const emailAddress = args[1];
            const targetId = args[2] ? args[2].toUpperCase() : '';

            if (!emailAddress || !targetId) {
                return `⚠️ Usage error: !temp delete <email_address> King-1${BRANDING}`;
            }

            try {
                const account = getAccountDetails(emailAddress);
                if (!account) {
                    return `⚠️ Cannot delete: Session not found locally for this email.${BRANDING}`;
                }

                if (!userIsOwner) {
                    if (!account.owner || !senderClean || account.owner !== senderClean) {
                        return `🔒 *Privacy Alert:* Access denied. You cannot delete messages from a temporary email you did not create!${BRANDING}`;
                    }
                }

                const password = account.password;

                const tokenRes = await fetch('https://api.mail.tm/token', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ address: emailAddress, password: password })
                });
                const tokenData = await tokenRes.json();
                if (!tokenData.token) {
                    return `❌ Failed to authenticate with mail provider.${BRANDING}`;
                }

                // Fetch messages to map King-X back to the API's real internal ID
                const msgRes = await fetch('https://api.mail.tm/messages', {
                    headers: { 'Authorization': `Bearer ${tokenData.token}` }
                });
                const messagesList = await msgRes.json();
                const messages = Array.isArray(messagesList) ? messagesList : (messagesList['hydra:member'] || []);

                let matchIndex = -1;
                if (targetId.startsWith('KING-')) {
                    const num = parseInt(targetId.replace('KING-', ''), 10);
                    if (!isNaN(num)) matchIndex = num - 1;
                }

                if (matchIndex < 0 || matchIndex >= messages.length) {
                    return `❌ Invalid ID reference (*${targetId}*). Check your inbox again using \`!temp inbox ${emailAddress}\` to see valid IDs.${BRANDING}`;
                }

                const realMessageId = messages[matchIndex].id;

                const delRes = await fetch(`https://api.mail.tm/messages/${realMessageId}`, {
                    method: 'DELETE',
                    headers: { 'Authorization': `Bearer ${tokenData.token}` }
                });

                if (delRes.status === 204 || delRes.ok) {
                    return `✅ Message *${targetId}* was successfully deleted from *${emailAddress}*.${BRANDING}`;
                } else {
                    return `❌ Failed to delete message from server.${BRANDING}`;
                }

            } catch (error) {
                return `❌ Delete Error: ${error.message}${BRANDING}`;
            }
        }

        const limitStatus = checkAndIncrementLimit(rawSender);
        if (!userIsOwner && !limitStatus.allowed) {
            return `⚠️ You have reached your free daily limit of 2 temporary emails. Try again tomorrow!${BRANDING}`;
        }

        try {
            const domainRes = await fetch('https://api.mail.tm/domains');
            const domainData = await domainRes.json();
            const domains = Array.isArray(domainData) ? domainData : (domainData['hydra:member'] || []);
            
            if (!domains || domains.length === 0) {
                throw new Error("No mail domains available.");
            }

            const domain = domains[0].domain;
            const randomName = 'king' + Math.random().toString(36).substring(2, 10);
            const emailAddress = `${randomName}@${domain}`;
            const password = Math.random().toString(36).substring(2, 12) + 'A1!';

            const createRes = await fetch('https://api.mail.tm/accounts', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ address: emailAddress, password: password })
            });

            if (!createRes.ok) {
                const errText = await createRes.text();
                throw new Error(`Failed to create account: ${errText}`);
            }

            saveCreds(emailAddress, password, rawSender);

            let replyText = `✅ *Private Temporary Email Generated!*\n\n`;
            replyText += `📧 *Address:* \`${emailAddress}\`\n`;
            replyText += `🔒 *Privacy:* Strict lock active.\n`;
            replyText += `📥 *To check inbox:* \`!temp inbox ${emailAddress}\`\n`;
            replyText += `🗑️ *To delete a message:* \`!temp delete ${emailAddress} King-1\`\n\n`;
            
            if (userIsOwner) {
                replyText += `👑 *Status:* Owner Access (Unlimited, Master Override)`;
            } else {
                replyText += `🔄 *Remaining free uses today:* ${limitStatus.remaining}`;
            }
            return replyText + BRANDING;

        } catch (error) {
            return `❌ Generation Error: ${error.message}${BRANDING}`;
        }
      }
    }
  }
};