const { PREFIX } = require("../config");

const need = (ctx) => ctx.args.join(" ");

module.exports = {
  category: "Text Tools",
  commands: {
    reverse: {
      desc: "Reverse text, e.g. !reverse hello",
      run: async (ctx) => {
        const t = need(ctx);
        if (!t) return `Usage: ${PREFIX}reverse <text>`;
        return t.split("").reverse().join("");
      },
    },
    upper: {
      desc: "Convert text to uppercase",
      run: async (ctx) => {
        const t = need(ctx);
        if (!t) return `Usage: ${PREFIX}upper <text>`;
        return t.toUpperCase();
      },
    },
    lower: {
      desc: "Convert text to lowercase",
      run: async (ctx) => {
        const t = need(ctx);
        if (!t) return `Usage: ${PREFIX}lower <text>`;
        return t.toLowerCase();
      },
    },
    count: {
      desc: "Count characters and words in text",
      run: async (ctx) => {
        const t = need(ctx);
        if (!t) return `Usage: ${PREFIX}count <text>`;
        const words = t.trim().split(/\s+/).filter(Boolean).length;
        return `📏 Characters: ${t.length}\n📝 Words: ${words}`;
      },
    },
    b64encode: {
      desc: "Encode text to Base64",
      run: async (ctx) => {
        const t = need(ctx);
        if (!t) return `Usage: ${PREFIX}b64encode <text>`;
        return Buffer.from(t, "utf8").toString("base64");
      },
    },
    b64decode: {
      desc: "Decode Base64 to text",
      run: async (ctx) => {
        const t = need(ctx);
        if (!t) return `Usage: ${PREFIX}b64decode <base64 text>`;
        try {
          return Buffer.from(t, "base64").toString("utf8");
        } catch {
          return "⚠️ Invalid Base64 input.";
        }
      },
    },
    tohex: {
      desc: "Convert text to hexadecimal",
      run: async (ctx) => {
        const t = need(ctx);
        if (!t) return `Usage: ${PREFIX}tohex <text>`;
        return Buffer.from(t, "utf8").toString("hex");
      },
    },
    tobinary: {
      desc: "Convert text to binary",
      run: async (ctx) => {
        const t = need(ctx);
        if (!t) return `Usage: ${PREFIX}tobinary <text>`;
        return t
          .split("")
          .map((c) => c.charCodeAt(0).toString(2).padStart(8, "0"))
          .join(" ");
      },
    },
    ascii: {
      desc: "Turn short text into a simple ASCII banner",
      run: async (ctx) => {
        const t = need(ctx);
        if (!t) return `Usage: ${PREFIX}ascii <short text>`;
        const line = "*".repeat(t.length + 4);
        return `${line}\n* ${t.toUpperCase()} *\n${line}`;
      },
    },
  },
};
