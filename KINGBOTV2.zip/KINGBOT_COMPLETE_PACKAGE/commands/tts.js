const axios = require('axios');

module.exports = {
  category: "tools",
  description: "Convert text into an audio message",
  commands: {
    tts: {
      category: "tools",
      description: "Convert text to audio. Usage: .tts Hello world",
      async run(ctx) {
        const { sock, remoteJid, args } = ctx;
        const text = args.join(" ").trim();

        if (!text) {
          return { text: "⚠️ Usage: `.tts Your text message here`" };
        }

        if (text.length > 250) {
          return { text: "⚠️ Text is too long! Please keep it under 250 characters for audio conversion." };
        }

        try {
          await sock.sendMessage(remoteJid, { text: "🗣️ *Generating audio message...*" });

          // Google Translate TTS endpoint (100% free, no API key required)
          const ttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text)}&tl=en&client=tw-ob`;

          const response = await axios.get(ttsUrl, {
            responseType: 'arraybuffer'
          });

          const audioBuffer = Buffer.from(response.data);

          // Send as a clean MP3 audio file (fixes the corruption error)
          await sock.sendMessage(remoteJid, {
            audio: audioBuffer,
            mimetype: 'audio/mpeg',
            ptt: false
          });

          return;

        } catch (err) {
          return { text: `❌ Error generating text-to-speech: ${err.message || err}` };
        }
      }
    }
  }
};