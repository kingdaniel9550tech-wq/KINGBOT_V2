// Separate stores for single-player and multiplayer games per chat
const singleGames = {};
const multiGames = {};

const WIN_COMBOS = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
  [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
  [0, 4, 8], [2, 4, 6]            // Diagonals
];

function renderBoard(board) {
  return `${board[0]} | ${board[1]} | ${board[2]}\n` +
         `---------\n` +
         `${board[3]} | ${board[4]} | ${board[5]}\n` +
         `---------\n` +
         `${board[6]} | ${board[7]} | ${board[8]}`;
}

function checkWin(board, player) {
  return WIN_COMBOS.some(combo => combo.every(index => board[index] === player));
}

function isBoardFull(board) {
  return board.every(cell => cell === '❌' || cell === '⭕');
}

module.exports = {
  category: "Games",
  commands: {
    // ---------------------------------------------------------
    // .TTT (Play against the Bot)
    // ---------------------------------------------------------
    ttt: {
      description: "Play an interactive game of Tic Tac Toe against the bot: .ttt, .ttt <1-9>, or .ttt stop",
      async run(ctx) {
        const { remoteJid, args } = ctx;
        const action = (args[0] || "").toLowerCase();

        // Start a new game if none exists or user typed 'start'
        if (!singleGames[remoteJid] || action === 'start') {
          singleGames[remoteJid] = {
            board: ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣']
          };
          
          return {
            text: `🎮 *T I C  •  T A C  •  T O E* (vs Bot)\n` +
                  `─────────────────────────────\n` +
                  `You are ❌ | Bot is ⭕\n` +
                  `Type a number (1-9) to make your move!\n` +
                  `*Example:* \`.ttt 5\`\n\n` +
                  `\`\`\`\n${renderBoard(singleGames[remoteJid].board)}\n\`\`\`\n` +
                  `─────────────────────────────\n` +
                  `⚡ _POWERED BY KINGBOT`
          };
        }

        const game = singleGames[remoteJid];

        if (action === 'stop' || action === 'end') {
          delete singleGames[remoteJid];
          return { text: `🛑 *Tic Tac Toe (vs Bot) game ended.*` };
        }

        const move = parseInt(action, 10);
        if (isNaN(move) || move < 1 || move > 9) {
          return {
            text: `⚠️ *Invalid move!* Type a number from 1 to 9 (e.g., \`.ttt 5\`) or \`.ttt stop\` to quit.` +
                  `\n\n\`\`\`\n${renderBoard(game.board)}\n\`\`\``
          };
        }

        const index = move - 1;

        // Check if spot is already taken
        if (game.board[index] === '❌' || game.board[index] === '⭕') {
          return {
            text: `⚠️ *That spot is already taken! Choose an empty number.*\n\n\`\`\`\n${renderBoard(game.board)}\n\`\`\``
          };
        }

        // Place User's Move
        game.board[index] = '❌';

        // Check if user won
        if (checkWin(game.board, '❌')) {
          const finalBoard = renderBoard(game.board);
          delete singleGames[remoteJid];
          return {
            text: `🎉 *CONGRATULATIONS! YOU WIN!* 🎉\n\n\`\`\`\n${finalBoard}\n\`\`\`\n` +
                  `─────────────────────────────\n` +
                  `⚡ _POWERED BY KINGBOT`
          };
        }

        // Check if board is full (Tie)
        if (isBoardFull(game.board)) {
          const finalBoard = renderBoard(game.board);
          delete singleGames[remoteJid];
          return {
            text: `🤝 *IT'S A TIE!* 🤝\n\n\`\`\`\n${finalBoard}\n\`\`\`\n` +
                  `─────────────────────────────\n` +
                  `⚡ _POWERED BY KINGBOT_`
          };
        }

        // Bot's Turn
        const availableMoves = [];
        game.board.forEach((cell, idx) => {
          if (cell !== '❌' && cell !== '⭕') {
            availableMoves.push(idx);
          }
        });

        if (availableMoves.length > 0) {
          const botMoveIndex = availableMoves[Math.floor(Math.random() * availableMoves.length)];
          game.board[botMoveIndex] = '⭕';

          // Check if bot won
          if (checkWin(game.board, '⭕')) {
            const finalBoard = renderBoard(game.board);
            delete singleGames[remoteJid];
            return {
              text: `🤖 *BOT WINS! Better luck next time!* 🤖\n\n\`\`\`\n${finalBoard}\n\`\`\`\n` +
                    `─────────────────────────────\n` +
                    `⚡ _POWERED BY KINGBOT_`
            };
          }

          // Check if tie after bot move
          if (isBoardFull(game.board)) {
            const finalBoard = renderBoard(game.board);
            delete singleGames[remoteJid];
            return {
              text: `🤝 *IT'S A TIE!* 🤝\n\n\`\`\`\n${finalBoard}\n\`\`\`\n` +
                    `─────────────────────────────\n` +
                    `⚡ _POWERED BY KINGBOT_`
            };
          }
        }

        return {
          text: `🎮 *T I C  •  T A C  •  T O E* (vs Bot)\n` +
                `─────────────────────────────\n` +
                `Your turn! Type \`.ttt [1-9]\`\n\n` +
                `\`\`\`\n${renderBoard(game.board)}\n\`\`\`\n` +
                `─────────────────────────────\n` +
                `⚡ _POWERED BY KINGBOT_`
        };
      }
    },

    // ---------------------------------------------------------
    // .TTT2 (Multiplayer against another user)
    // ---------------------------------------------------------
    ttt2: {
      description: "Play multiplayer Tic Tac Toe against another user: !ttt2, !ttt2 join, !ttt2 <1-9>, or !ttt2 stop",
      async run(ctx) {
        const { remoteJid, args, sender: rawSender, msg } = ctx;
        const sender = rawSender || msg?.key?.participant || remoteJid;
        const action = (args[0] || "").toLowerCase();

        // 1. Start a new multiplayer game / waiting for opponent
        if (!action || action === 'start') {
          if (multiGames[remoteJid] && multiGames[remoteJid].status === 'playing') {
            return {
              text: `⚠️ *A multiplayer game is already active in this chat!* Type \`.ttt2 stop\` to end it.`
            };
          }

          multiGames[remoteJid] = {
            playerX: sender,
            playerO: null,
            turn: sender,
            board: ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'],
            status: 'waiting'
          };

          const senderTag = sender.split('@')[0];
          return {
            text: `🎮 *M U L T I P L A Y E R  •  T I C  •  T A C  •  T O E*\n` +
                  `─────────────────────────────\n` +
                  `@${senderTag} started a game as ❌!\n` +
                  `Waiting for a second player to join.\n` +
                  `Type \`.ttt2 join\` to play against them!\n\n` +
                  `\`\`\`\n${renderBoard(multiGames[remoteJid].board)}\n\`\`\`\n` +
                  `─────────────────────────────\n` +
                  `⚡ _POWERED BY KINGBOT_`,
            mentions: [sender]
          };
        }

        // 2. Join the waiting game
        if (action === 'join') {
          const game = multiGames[remoteJid];
          if (!game || game.status !== 'waiting') {
            return {
              text: `⚠️ There is no waiting multiplayer Tic Tac Toe game here. Type \`.ttt2\` to start one.`
            };
          }
          if (game.playerX === sender) {
            return {
              text: `⚠️ You already started this game! Wait for another player to join.`
            };
          }

          game.playerO = sender;
          game.status = 'playing';

          const playerXTag = game.playerX.split('@')[0];
          const playerOTag = game.playerO.split('@')[0];

          return {
            text: `🎮 *M U L T I P L A Y E R  •  T I C  •  T A C  •  T O E*\n` +
                  `─────────────────────────────\n` +
                  `❌ @${playerXTag}\nvs\n⭕ @${playerOTag}\n\n` +
                  `It's @${playerXTag}'s turn (❌)!\n` +
                  `Type \`.ttt2 [1-9]\` to make your move.\n\n` +
                  `\`\`\`\n${renderBoard(game.board)}\n\`\`\`\n` +
                  `─────────────────────────────\n` +
                  `⚡ _POWERED BY KINGBOT_`,
            mentions: [game.playerX, game.playerO]
          };
        }

        // 3. Stop / End game
        if (action === 'stop' || action === 'end') {
          if (!multiGames[remoteJid]) {
            return { text: `⚠️ No active multiplayer game to stop.` };
          }
          delete multiGames[remoteJid];
          return {
            text: `🛑 *Multiplayer Tic Tac Toe game ended.*\n─────────────────────────────\n⚡ _POWERED BY KINGBOT_`
          };
        }

        // 4. Make a move (1-9)
        const game = multiGames[remoteJid];
        if (!game || game.status !== 'playing') {
          return {
            text: `⚠️ No active multiplayer game playing right now. Type \`.ttt2\` to start and \`.ttt2 join\` to join.`
          };
        }

        if (game.turn !== sender) {
          const turnTag = game.turn.split('@')[0];
          return {
            text: `⚠️ It's not your turn! Waiting for @${turnTag}.\n\n\`\`\`\n${renderBoard(game.board)}\n\`\`\``,
            mentions: [game.turn]
          };
        }

        const move = parseInt(action, 10);
        if (isNaN(move) || move < 1 || move > 9) {
          return {
            text: `⚠️ *Invalid move!* Type a number from 1 to 9 (e.g., \`.ttt2 5\`) or \`.ttt2 stop\` to quit.` +
                  `\n\n\`\`\`\n${renderBoard(game.board)}\n\`\`\``
          };
        }

        const index = move - 1;
        if (game.board[index] === '❌' || game.board[index] === '⭕') {
          return {
            text: `⚠️ *That spot is already taken! Choose an open number.*\n\n\`\`\`\n${renderBoard(game.board)}\n\`\`\``
          };
        }

        const symbol = sender === game.playerX ? '❌' : '⭕';
        game.board[index] = symbol;

        // Check Win
        if (checkWin(game.board, symbol)) {
          const finalBoard = renderBoard(game.board);
          const winnerTag = sender.split('@')[0];
          delete multiGames[remoteJid];
          return {
            text: `🎉 *CONGRATULATIONS @${winnerTag} (${symbol}) WINS!* 🎉\n\n` +
                  `\`\`\`\n${finalBoard}\n\`\`\`\n` +
                  `─────────────────────────────\n` +
                  `⚡ _POWERED BY KINGBOT_`,
            mentions: [sender]
          };
        }

        // Check Tie
        if (isBoardFull(game.board)) {
          const finalBoard = renderBoard(game.board);
          delete multiGames[remoteJid];
          return {
            text: `🤝 *IT'S A TIE!* 🤝\n\n` +
                  `\`\`\`\n${finalBoard}\n\`\`\`\n` +
                  `─────────────────────────────\n` +
                  `⚡ _POWERED BY KINGBOT_`
          };
        }

        // Switch turn
        game.turn = sender === game.playerX ? game.playerO : game.playerX;
        const nextSymbol = game.turn === game.playerX ? '❌' : '⭕';
        const nextTag = game.turn.split('@')[0];

        return {
          text: `🎮 *M U L T I P L A Y E R  •  T I C  •  T A C  •  T O E*\n` +
                `─────────────────────────────\n` +
                `It's now @${nextTag}'s turn (${nextSymbol})!\n` +
                `Type \`.ttt2 [1-9]\`\n\n` +
                `\`\`\`\n${renderBoard(game.board)}\n\`\`\`\n` +
                `─────────────────────────────\n` +
                `⚡ _POWERED BY KINGBOT_`,
          mentions: [game.turn]
        };
      }
    }
  }
};