module.exports = {
  category: "business",
  commands: {
    broadcastb: {
      description: "Broadcast  Kingbot announcement to groups and channels",
      async run(ctx) {
        const { sock, remoteJid, msg, args } = ctx;
        
        // Owner verification check
        const ownerJid = sock.user?.id || "";
        const ownerPhoneNum = ownerJid ? ownerJid.split("@")[0].split(":")[0] : "";
        const configOwnerNum = process.env.OWNER_NUMBER || "";
        const sender = msg.key.participant || remoteJid;
        const isOwner = msg.key.fromMe || 
          (ownerPhoneNum && sender.includes(ownerPhoneNum)) || 
          (configOwnerNum && sender.includes(configOwnerNum));

        if (!isOwner) return { text: "⛔ Access Denied!" };

        const messageText = args.join(" ");
        if (!messageText) {
          return { 
            text: `⚠️ *Please provide a message to broadcast!*\n\n*Usage:* \`.broadcastb Your announcement message here\`` 
          };
        }

        // Beautifully styled Kingbot Broadcast Template
        const formattedBroadcast = 
          `👑 *K I N G B O T  A I  •  B R O A D C A S T* 👑\n` +
          `─────────────────────────────\n\n` +
          `${messageText}\n\n` +
          `─────────────────────────────\n` +
          `💡 *Powered by Kingbot*\n` +
          `⚡ _sponsored by KING_`;

        let successCount = 0;
        let targetList = [];

        try {
          // Fetch all groups the bot participates in directly from WhatsApp
          const groups = await sock.groupFetchAllParticipating();
          const groupJids = Object.keys(groups || {});
          targetList.push(...groupJids);
        } catch (e) {
          console.error("Failed to fetch groups:", e.message);
        }

        // Fallback check if sock.chats exists
        if (sock.chats) {
          const chats = Object.keys(sock.chats || {});
          for (const jid of chats) {
            if ((jid.endsWith('@g.us') || jid.endsWith('@newsletter')) && !targetList.includes(jid)) {
              targetList.push(jid);
            }
          }
        }

        // Loop through all collected unique destinations and send with a small safety delay
        for (const jid of targetList) {
          try {
            await sock.sendMessage(jid, { text: formattedBroadcast });
            successCount++;
            await new Promise(resolve => setTimeout(resolve, 1000)); // 1s delay to prevent flooding
          } catch (e) {
            console.error(`Failed to broadcast to ${jid}:`, e.message);
          }
        }

        return { 
          text: `✅ *Kingbot Broadcast Completed!* 🎉\n\n` +
                `🎯 *Target Type:* Groups & Channels\n` +
                `📬 *Successfully Delivered:* ${successCount} destinations` 
        };
      }
    }
  }
};