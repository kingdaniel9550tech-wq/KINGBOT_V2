const { PREFIX } = require("../config");
const { bibleVerses } = require("../data");
const yts = require('yt-search');

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

module.exports = {
  category: "Misc",
  commands: {
    play: {
      desc: "Search and get a song preview card from YouTube, e.g. !play Faded",
      run: async (ctx) => {
        const query = ctx.args.join(" ");
        if (!query) return `Usage: ${PREFIX}play <song or video name>`;

        const sock = ctx.sock || ctx.client;
        const chatId = ctx.chatId || ctx.from || ctx.remoteJid;
        const m = ctx.m || ctx.msg || ctx.quoted;

        if (!sock || !chatId) {
          return `⚠️ Bot execution context error. Please check your command handler structure.`;
        }

        const statusMsg = await sock.sendMessage(chatId, { text: `🔍 Searching for *${query}*... Please wait.` }, { quoted: m });

        try {
          const searchResult = await yts(query);
          const song = searchResult.videos[0];

          if (!song) {
            await sock.sendMessage(chatId, { text: '❌ No results found for your query.' }, { quoted: m });
            return;
          }

          const messageText = `🎵 *KINGBOT MEDIA FINDER* 🎵\n\n` +
            `📌 *Title:* ${song.title}\n` +
            `⏱ *Duration:* ${song.timestamp}\n` +
            `👁 *Views:* ${song.views.toLocaleString()}\n` +
            `🔗 *Listen/Watch:* ${song.url}\n\n` +
            `👤 *👑:* Kingbot media download\n` +
            `🔗 *Join our WhatsApp Channel:* https://whatsapp.com/channel/0029Vaj1zo6HVvTV3Sd4zd2k`;

          await sock.sendMessage(chatId, { text: messageText }, { quoted: m });

          try {
            await sock.sendMessage(chatId, { delete: statusMsg.key });
          } catch (e) {}

          return;
        } catch (error) {
          console.error('Play Command Error:', error);
          return `⚠️ Failed to search for audio. Please try again later.`;
        }
      },
    },
    lyrics: {
      desc: "Search for song lyrics, e.g. !lyrics Faded Alan Walker",
      run: async (ctx) => {
        const query = ctx.args.join(" ");
        if (!query) return `Usage: ${PREFIX}lyrics <song name and artist>`;

        try {
          const res = await fetch(`https://lrclib.net/api/search?q=${encodeURIComponent(query)}`);
          if (!res.ok) return "⚠️ Lyrics service is currently unavailable.";
          const data = await res.json();
          
          if (!data || data.length === 0 || !data[0].plainLyrics) {
            return `❌ No lyrics found for "${query}". Try adding the artist name.`;
          }

          const track = data[0];
          const lyricsText = track.plainLyrics.length > 3500 
            ? track.plainLyrics.substring(0, 3500) + "\n\n...(Lyrics truncated due to length)" 
            : track.plainLyrics;

          return `🎵 *${track.trackName}* - ${track.artistName}\n\n${lyricsText}\n\n👤 *Watermark:* Kingbot media download\n🔗 *Join our WhatsApp Channel:* https://whatsapp.com/channel/0029Vaj1zo6HVvTV3Sd4zd2k`;
        } catch (error) {
          console.error('Lyrics Error:', error);
          return "⚠️ Failed to fetch lyrics right now.";
        }
      },
    },
    bible: {
      desc: "Get a Bible verse, e.g. !bible john 3:16 (or just .bible for a random verse)",
      run: async (ctx) => {
        const reference = ctx.args.join(" ") || pick(bibleVerses);
        try {
          const res = await fetch(`https://bible-api.com/${encodeURIComponent(reference)}`);
          if (!res.ok) return `⚠️ Couldn't find that reference. Try a format like "${PREFIX}bible john 3:16".`;
          const data = await res.json();
          if (!data.text) return `⚠️ Couldn't find that reference. Try a format like "${PREFIX}bible john 3:16".`;
          return `📖 *${data.reference}* (${data.translation_name || "KJV"})\n${data.text.trim()}`;
        } catch {
          return "⚠️ Bible lookup service is unavailable right now.";
        }
      },
    },
  },
};