const fs = require('fs');
const path = require('path');
const https = require('https');
const { isOwner } = require('../utils');

const creditsFile = path.join(__dirname, '../data/credits.json');

function loadCredits() {
  try {
    if (fs.existsSync(creditsFile)) {
      return JSON.parse(fs.readFileSync(creditsFile, 'utf8'));
    }
  } catch (e) {}
  return {};
}

function saveCreditsData(data) {
  try {
    const dir = path.dirname(creditsFile);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(creditsFile, JSON.stringify(data, null, 2));
  } catch (e) {}
}

const creditsData = loadCredits();

function getCredits(userId) {
  if (!creditsData[userId]) {
    creditsData[userId] = 5; // Default 5 free credits for new users
    saveCreditsData(creditsData);
  }
  return creditsData[userId];
}

function deductCredit(userId) {
  let current = getCredits(userId);
  if (current > 0) {
    creditsData[userId] = current - 1;
    saveCreditsData(creditsData);
  }
}

function addCredits(userId, amount) {
  let current = getCredits(userId);
  creditsData[userId] = current + amount;
  saveCreditsData(creditsData);
}

const PLANS = {
  mini: { name: "Mini", amount: 20000, credits: 20 },      // ₦200
  starter: { name: "Starter", amount: 50000, credits: 50 }, // ₦500
  pro: { name: "Pro", amount: 120000, credits: 150 },       // ₦1,200
  mega: { name: "Mega", amount: 250000, credits: 350 }      // ₦2,500
};

function initializePaystack(secretKey, data) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(data);
    const options = {
      hostname: 'api.paystack.co',
      port: 443,
      path: '/transaction/initialize',
      method: 'POST',
      headers: {
        Authorization: `Bearer ${secretKey}`,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload)
      }
    };

    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => body += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(body)); } catch (e) { reject(new Error('Invalid JSON')); }
      });
    });

    req.on('error', (err) => reject(err));
    req.write(payload);
    req.end();
  });
}

module.exports = {
  category: "Kingbot AI Hub",
  commands: {
    // 1. Check Balance: .credits
    credits: {
      description: "Check your AI credit balance",
      run: async (ctx) => {
        const { sender } = ctx;
        const userId = sender.split('@')[0];
        const balance = getCredits(userId);
        return `💳 *AI Credit Balance*\n\n• Balance: *${balance} Credits*\n\n📌 *Commands:*\n• \`.buyai <mini/starter/pro/mega>\` - Buy plans\n• \`.daily\` - Claim daily free credit`;
      }
    },

    // 2. Buy Plans: .buyai mini / starter / pro / mega
    buyai: {
      description: "Buy AI credits using Paystack",
      run: async (ctx) => {
        const { sender, args } = ctx;
        const userId = sender.split('@')[0];
        const planKey = (args[0] || "").toLowerCase();
        const plan = PLANS[planKey];

        if (!plan) {
          return `🛒 *Available AI Credit Plans:*\n` +
                 `• \`.buyai mini\` - ₦200 (20 Credits)\n` +
                 `• \`.buyai starter\` - ₦500 (50 Credits)\n` +
                 `• \`.buyai pro\` - ₦1,200 (150 Credits)\n` +
                 `• \`.buyai mega\` - ₦2,500 (350 Credits)`;
        }

        const secretKey = process.env.PAYSTACK_SECRET_KEY || process.env.PAYSTACK_SECRET;
        
        if (!secretKey) {
          return `❌ Payment system is not configured. Please contact the bot owner.`;
        }

        const email = `${userId}@kingbot.pay`;

        try {
          const resData = await initializePaystack(secretKey, {
            email: email,
            amount: plan.amount,
            metadata: { userId: userId, credits: plan.credits }
          });

          if (resData.status && resData.data) {
            return `🛒 *Payment Link Generated (${plan.name} Plan)*\n\nClick below to pay ₦${plan.amount / 100} for ${plan.credits} AI credits:\n${resData.data.authorization_url}\n\n_Your credits will be added once payment is confirmed._`;
          } else {
            return `❌ Failed to initialize payment: ${resData.message || "Unknown error"}`;
          }
        } catch (err) {
          console.error("Paystack error:", err);
          return `❌ Payment initialization failed due to a network error.`;
        }
      }
    },

    // 3. Owner Add Credits: .addcredit <phone> <amount>
    addcredit: {
      description: "Owner command to add credits to a user",
      run: async (ctx) => {
        const { sender, args, isFromMe } = ctx;
        if (!isOwner(ctx) && !isFromMe) {
          return "❌ Owner only command.";
        }
        const target = args[0]?.replace(/[^0-9]/g, "");
        const amount = parseInt(args[1]);
        if (!target || isNaN(amount)) {
          return "⚠️ Usage: `.addcredit <phone_number> <amount>`";
        }
        addCredits(target, amount);
        return `✅ Successfully added ${amount} AI credits to @${target}.`;
      }
    },

    // 4. Claim Daily Credit: .daily
    daily: {
      description: "Claim your free daily AI credit",
      run: async (ctx) => {
        const { sender } = ctx;
        const userId = sender.split('@')[0];
        const today = new Date().toISOString().slice(0, 10);
        if (!creditsData.dailyClaims) creditsData.dailyClaims = {};
        if (creditsData.dailyClaims[userId] === today) {
          return "⏳ You have already claimed your free daily credit today! Check back tomorrow.";
        }
        creditsData.dailyClaims[userId] = today;
        addCredits(userId, 1);
        return "🎁 Claimed successfully! You received *1 free AI credit*.";
      }
    }
  },
  getCredits,
  deductCredit,
  addCredits
};