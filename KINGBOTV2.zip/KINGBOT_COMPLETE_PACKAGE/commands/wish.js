module.exports = {
  category: "fun",
  description: "Send daily greetings and love messages",
  commands: {
    wish: {
      category: "fun",
      description: "Send greetings or love notes. Usage: .wish gm, .wish ga, .wish gn, or .wish love",
      async run(ctx) {
        const { args } = ctx;
        const type = (args[0] || "").toLowerCase();

        const messages = {
          gm: [
            "☀️ Good morning! May your day be filled with endless smiles, positive energy, and great success.",
            "🌅 Rise and shine! Wishing you a beautiful morning and a wonderfully productive day ahead.",
            "☕ Good morning! Sending you warm hugs and positive vibes to kickstart your amazing day."
          ],
          ga: [
            "🌤️ Good afternoon! Just checking in to remind you to take a breather and stay hydrated. Keep shining!",
            "☀️ Hope your day is going wonderfully! Sending you a quick afternoon boost of energy and good vibes.",
            "🌻 Good afternoon! May the rest of your day be smooth, stress-free, and full of wins."
          ],
          gn: [
            "🌙 Good night! Rest well, clear your mind, and sweet dreams. Tomorrow is a brand new blessing.",
            "✨ Sleep tight and have wonderful dreams. May peace surround you through the night.",
            "🌌 Good night! Close your eyes, let go of today's worries, and wake up completely refreshed."
          ],
          love: [
            "💖 Every single moment thinking of you brings warmth to my heart. You are deeply cherished.",
            "🌹 You are the brightest spark in any room. Sending you all my love today and always.",
            "💫 In a world full of noise, your presence is peace. Sending you loads of love and affection!"
          ]
        };

        // If no valid category is provided, show the instruction menu
        if (!messages[type]) {
          return {
            text: "💌 *DAILY WISHES & LOVE PORTAL*\n\n" +
                  "Choose a category to send:\n" +
                  "• `.wish gm` — Good Morning wishes\n" +
                  "• `.wish ga` — Good Afternoon wishes\n" +
                  "• `.wish gn` — Good Night wishes\n" +
                  "• `.wish love` — Sweet Love messages"
          };
        }

        // Pick a random message from the selected category
        const categoryList = messages[type];
        const randomMessage = categoryList[Math.floor(Math.random() * categoryList.length)];

        return {
          text: `💌 *SPECIAL MESSAGE*\n\n${randomMessage}`
        };
      }
    }
  }
};