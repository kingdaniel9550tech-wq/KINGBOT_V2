// commands/kingai.js
const { isOwner } = require("../utils");

const API_KEY = process.env.GEMINI_API_KEY || "AQ.Ab8RN6Iho7eRYbkvDOa3lA2jNAlhj63d5B4ENqYPvNAr935evQ";

// Use global storage so PIN and unlocked states persist across file reloads
if (global.botPin === undefined) global.botPin = null;
if (!global.unlockedUsers) global.unlockedUsers = new Set();
if (!global.reportsList) global.reportsList = [];

// Helper to get sender JID
function getSender(ctx) {
  const msg = ctx.msg || {};
  return ctx.sender || msg.sender || msg.key?.participant || msg.key?.remoteJid || "";
}

// Helper for standard text requests to Gemini
async function callGemini(parts, useSearch = false) {
  if (!API_KEY) return "⚠️ Kingbot AI is missing its Gemini API key!";

  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=${API_KEY}`;
    const bodyData = { contents: [{ role: "user", parts: parts }] };
    if (useSearch) bodyData.tools = [{ google_search: {} }];

    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(bodyData)
    });

    const data = await res.json();
    return data?.candidates?.[0]?.content?.parts?.[0]?.text || "Hmm, I'm drawing a blank right now. Say that again?";
  } catch (err) {
    console.error("Gemini API Error:", err);
    return "Oops! I had a little hiccup connecting to my brain. Try again in a second.";
  }
}

module.exports = {
  category: "Kingbot AI Hub",
  commands: {
    // ==================== AI CATEGORY ====================
    kingai: {
      category: "AI",
      desc: "Chat directly with Kingbot AI. Usage: !kingai <message>",
      run: async (ctx) => {
        const { args, msg } = ctx;
        const conn = ctx.sock;
        const chatId = ctx.remoteJid;

        const prompt = args.join(" ");
        if (!prompt) return "🤖 *Usage:* \`.kingai Hello, how are you today?\`";

        if (conn && chatId) await conn.sendPresenceUpdate('composing', chatId);

        const systemPrompt = "System Instruction: You are Kingbot AI, a friendly, intelligent WhatsApp assistant built by King Daniel. Keep responses concise and engaging.\n\nUser: " + prompt;
        const replyText = await callGemini([{ text: systemPrompt }]);

        if (conn && chatId) {
          await conn.sendPresenceUpdate('paused', chatId);
          await conn.sendMessage(chatId, { text: replyText }, { quoted: msg });
          return;
        }
        return replyText;
      }
    },

    aisearch: {
      category: "AI",
      desc: "Search the live web using Gemini. Usage: !aisearch <query>",
      run: async (ctx) => {
        const { args, msg } = ctx;
        const conn = ctx.sock;
        const chatId = ctx.remoteJid;

        const query = args.join(" ");
        if (!query) return "🌍 *Usage:* \`!aisearch Latest tech news 2026\`";

        if (conn && chatId) await conn.sendPresenceUpdate('composing', chatId);

        const replyText = await callGemini([{ text: query }], true);

        if (conn && chatId) {
          await conn.sendPresenceUpdate('paused', chatId);
          await conn.sendMessage(chatId, { text: `🌐 *Web Search Result:*\n\n${replyText}` }, { quoted: msg });
          return;
        }
        return replyText;
      }
    },

    // ==================== OWNER CATEGORY (Security & Email) ====================
    setpin: {
      category: "Owner",
      desc: "Set a bot security PIN. Usage: !setpin <4-digit-pin>",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "❌ *Access Denied:* This is an owner-only command!";
        
        const { args } = ctx;
        const newPin = args[0];
        if (!newPin || newPin.length < 4) {
          return "🔒 *Usage:* \`!setpin 1234\` (Must be at least 4 digits)";
        }
        global.botPin = newPin;
        global.unlockedUsers.clear();
        
        const sender = getSender(ctx);
        if (sender) global.unlockedUsers.add(sender);

        return `🔒 *Bot Security PIN Set Successfully!*\nRandom users are now locked out until they enter \`!unlock <pin>\`.`;
      }
    },

    unlock: {
      category: "Owner",
      desc: "Unlock the bot with the security PIN. Usage: !unlock <pin>",
      run: async (ctx) => {
        const { args } = ctx;
        const pinInput = args[0];

        if (!global.botPin) {
          return "🔓 No bot PIN has been configured yet by the owner!";
        }
        if (pinInput !== global.botPin) {
          return "❌ *Incorrect PIN!* Access denied.";
        }

        const sender = getSender(ctx);
        if (sender) global.unlockedUsers.add(sender);

        return "🔓 *Bot Unlocked!* You now have full access to bot commands.";
      }
    },

    tempmail: {
      category: "Owner",
      desc: "Generate a fresh disposable temporary email address. Usage: !tempmail",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "❌ *Access Denied:* This is an owner-only command!";
        const { msg } = ctx;
        const conn = ctx.sock;
        const chatId = ctx.remoteJid;

        try {
          if (conn && chatId) await conn.sendPresenceUpdate('composing', chatId);

          const res = await fetch('https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1');
          const data = await res.json();
          
          if (!data || !data[0]) {
            return "❌ Failed to generate a temporary email. Try again!";
          }

          const email = data[0];
          const responseText = `📧 *Temporary Email Generated!*\n\n` +
                               `Your Email:\n\`\`\`${email}\`\`\`\n\n` +
                               `📥 *How to check inbox:*\n` +
                               `Type \`!checkmail ${email}\``;

          if (conn && chatId) {
            await conn.sendPresenceUpdate('paused', chatId);
            await conn.sendMessage(chatId, { text: responseText }, { quoted: msg });
            return;
          }
          return responseText;
        } catch (err) {
          console.error("TempMail Error:", err);
          return "❌ Error generating temporary email service.";
        }
      }
    },

    checkmail: {
      category: "Owner",
      desc: "Check inbox messages for a temp email. Usage: !checkmail <email>",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "❌ *Access Denied:* This is an owner-only command!";
        const { args, msg } = ctx;
        const conn = ctx.sock;
        const chatId = ctx.remoteJid;

        const email = args[0];
        if (!email || !email.includes("@")) {
          return "📥 *Usage:* \`!checkmail your_email@1secmail.com\`";
        }

        try {
          if (conn && chatId) await conn.sendPresenceUpdate('composing', chatId);

          const [login, domain] = email.split('@');
          const res = await fetch(`https://www.1secmail.com/api/v1/?action=getMessages&login=${login}&domain=${domain}`);
          const messages = await res.json();

          if (!messages || messages.length === 0) {
            return `📭 Inbox for *${email}* is currently empty.`;
          }

          let inboxText = `📬 *Inbox for ${email}* (${messages.length} messages):\n\n`;
          messages.forEach((m, index) => {
            inboxText += `*${index + 1}. ID:* \`${m.id}\`\n`;
            inboxText += `*From:* ${m.from}\n`;
            inboxText += `*Subject:* ${m.subject}\n`;
            inboxText += `*Date:* ${m.date}\n`;
            inboxText += `📖 Read: \`!readmail ${email} ${m.id}\`\n\n`;
          });

          if (conn && chatId) {
            await conn.sendPresenceUpdate('paused', chatId);
            await conn.sendMessage(chatId, { text: inboxText }, { quoted: msg });
            return;
          }
          return inboxText;
        } catch (err) {
          console.error("CheckMail Error:", err);
          return "❌ Failed to fetch inbox messages.";
        }
      }
    },

    readmail: {
      category: "Owner",
      desc: "Read a specific message ID. Usage: !readmail <email> <messageId>",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "❌ *Access Denied:* This is an owner-only command!";
        const { args, msg } = ctx;
        const conn = ctx.sock;
        const chatId = ctx.remoteJid;

        const email = args[0];
        const messageId = args[1];

        if (!email || !messageId) {
          return "📖 *Usage:* \`!readmail user@1secmail.com 123456\`";
        }

        try {
          if (conn && chatId) await conn.sendPresenceUpdate('composing', chatId);

          const [login, domain] = email.split('@');
          const res = await fetch(`https://www.1secmail.com/api/v1/?action=readMessage&login=${login}&domain=${domain}&id=${messageId}`);
          const mail = await res.json();

          if (!mail || !mail.id) {
            return "❌ Message not found or expired.";
          }

          const mailText = `✉️ *Email Details*\n\n` +
                           `*From:* ${mail.from}\n` +
                           `*Subject:* ${mail.subject}\n` +
                           `*Date:* ${mail.date}\n\n` +
                           `*Body:*\n${mail.textBody || mail.htmlBody || "No text body found."}`;

          if (conn && chatId) {
            await conn.sendPresenceUpdate('paused', chatId);
            await conn.sendMessage(chatId, { text: mailText }, { quoted: msg });
            return;
          }
          return mailText;
        } catch (err) {
          console.error("ReadMail Error:", err);
          return "❌ Failed to read email message.";
        }
      }
    },

    viewreports: {
      category: "Owner",
      desc: "View live user reports and feedback. Usage: !viewreports",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "❌ *Access Denied:* This is an owner-only command!";
        if (global.reportsList.length === 0) {
          return "📋 *Live Reports:* No active reports submitted yet.";
        }

        let output = `📋 *Live Reports Update (${global.reportsList.length}):*\n\n`;
        global.reportsList.forEach(r => {
          output += `*Report #${r.id}*\n`;
          output += `*From:* ${r.user}\n`;
          output += `*Details:* ${r.text}\n`;
          output += `*Time:* ${r.time}\n\n`;
        });
        return output;
      }
    },

    // ==================== OTHER UTILITIES ====================
    clearchat: {
      category: "Tools",
      desc: "Clear current chat history. Usage: .clearchat or !clearchat",
      run: async (ctx) => {
        const { msg } = ctx;
        const conn = ctx.sock;
        const chatId = ctx.remoteJid;

        try {
          if (conn && chatId) {
            await conn.chatModify({ delete: true, lastMessages: [{ key: msg.key, id: msg.id }] }, chatId);
            return "🧹 Chat history cleared successfully.";
          }
          return "🧹 Clear chat executed.";
        } catch (err) {
          console.error("ClearChat Error:", err);
          return "❌ Failed to clear chat automatically.";
        }
      }
    },

    report: {
      category: "Support",
      desc: "Report an issue or bug to the bot operators. Usage: !report <issue details>",
      run: async (ctx) => {
        const { args, msg } = ctx;
        const reportText = args.join(" ");

        if (!reportText) {
          return "🚨 *Usage:* \`!report Bot is not responding in group chat\`";
        }

        const reportEntry = {
          id: global.reportsList.length + 1,
          user: getSender(ctx) || "Unknown",
          chat: ctx.remoteJid || "Private",
          text: reportText,
          time: new Date().toLocaleString()
        };

        global.reportsList.push(reportEntry);
        return `🚨 *Report Submitted Successfully!*\nYour report ID is #${reportEntry.id}. The owner has been notified.`;
      }
    }
  }
};