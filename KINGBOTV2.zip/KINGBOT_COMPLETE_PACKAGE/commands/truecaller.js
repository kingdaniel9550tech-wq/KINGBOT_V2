const axios = require('axios');

function analyzeNumber(digits) {
  let country = "Unknown Country";
  let carrier = "Mobile Cellular Network";
  let region = "Global International";

  if (digits.startsWith("234")) {
    country = "Nigeria 🇳🇬";
    region = "Federal Republic of Nigeria";
    const prefix = digits.substring(3, 6);
    const mtn = ["703", "706", "803", "806", "810", "813", "814", "816", "903", "906", "913", "916"];
    const glo = ["705", "805", "807", "811", "815", "905", "915"];
    const airtel = ["701", "802", "808", "812", "901", "902", "904", "907", "912"];
    const mobile9 = ["809", "817", "818", "908", "909"];

    if (mtn.includes(prefix)) carrier = "MTN Nigeria Communications PLC";
    else if (glo.includes(prefix)) carrier = "Globacom (Glo)";
    else if (airtel.includes(prefix)) carrier = "Airtel Nigeria";
    else if (mobile9.includes(prefix)) carrier = "9mobile (Etisalat Nigeria)";
    else carrier = "Nigerian Mobile Carrier / VoIP";
  } else if (digits.startsWith("1")) {
    country = "United States / Canada 🇺🇸/🇨🇦";
    region = "North American Numbering Plan";
    carrier = "North American Regional Carrier";
  } else if (digits.startsWith("44")) {
    country = "United Kingdom 🇬🇧";
    region = "Great Britain";
    carrier = "UK Mobile / Landline Provider";
  } else if (digits.startsWith("254")) {
    country = "Kenya 🇰🇪";
    region = "Republic of Kenya";
    carrier = "Safaricom / Airtel Kenya";
  } else if (digits.startsWith("233")) {
    country = "Ghana 🇬🇭";
    region = "Republic of Ghana";
    carrier = "MTN Ghana / Vodafone / AirtelTigo";
  }

  return { country, region, carrier };
}

module.exports = {
  category: "tools",
  description: "Advanced phone intelligence and carrier lookup",
  commands: {
    truecaller: {
      category: "tools",
      description: "Analyze phone details. Usage: .truecaller <phone number>",
      aliases: ["tc", "lookup"],
      async run(ctx) {
        const { sock, remoteJid, args } = ctx;
        const rawInput = args.join(" ").trim();
        const number = rawInput.replace(/[^0-9]/g, "");

        if (!number) {
          return { 
            text: "👑 *Kingbot truecaller 🔍*\n\n" +
                  "⚠️ *Invalid Usage!*\n" +
                  "Please provide a phone number with country code.\n\n" +
                  "📌 *Example:*\n" +
                  "`.truecaller 2348012345678`" 
          };
        }

        let statusMsg;
        try {
          statusMsg = await sock.sendMessage(remoteJid, { 
            text: "👑 *Kingbot truecaller 🔍*\n\n`[■□□□□] 20% — Searching...`" 
          });
        } catch (e) {}

        const updateStatus = async (percent, text) => {
          if (statusMsg && statusMsg.key) {
            try {
              await sock.sendMessage(remoteJid, {
                text: `👑 *Kingbot truecaller 🔍*\n\n\`[${percent}] ${text}\``,
                edit: statusMsg.key
              });
            } catch (err) {}
          }
        };

        try {
          await updateStatus("■■■□□", "50% — Scanning global telecom databases & registries...");

          let apiData = null;

          try {
            const res = await axios.get(`https://api.siputzx.my.id/api/tools/truecaller?phone=${number}`, { timeout: 6000 });
            if (res.data && (res.data.result || res.data.data)) {
              apiData = res.data.result || res.data.data;
            }
          } catch (e) {}

          await updateStatus("■■■■■", "90% — Compiling carrier intelligence report...");

          if (statusMsg && statusMsg.key) {
            try { await sock.sendMessage(remoteJid, { delete: statusMsg.key }); } catch (e) {}
          }

          const localInfo = analyzeNumber(number);
          const name = (apiData && (apiData.name || apiData.displayName)) ? (apiData.name || apiData.displayName) : "Private / Unlisted Profile (Protected)";
          const carrier = (apiData && apiData.carrier) ? apiData.carrier : localInfo.carrier;
          const country = (apiData && apiData.country) ? apiData.country : localInfo.country;
          const email = (apiData && apiData.email) ? apiData.email : "Not Publicly Exposed";
          const isSpam = apiData ? (apiData.isSpam || apiData.spamScore > 0) : false;
          const spamStatus = isSpam ? "⚠️ High Spam / Scam Risk" : "✅ Verified Active Line (Safe)";

          return {
            text: `👑 *KINGBOT TRUECALLER 🔍*\n\n` +
                  `📞 *Target Number:* +${number}\n` +
                  `👤 *Caller Identity:* ${name}\n` +
                  `🌍 *Country / Region:* ${country}\n` +
                  `📡 *Telecom Carrier:* ${carrier}\n` +
                  `📧 *Registered Email:* ${email}\n` +
                  `🛡️ *Network Status:* ${spamStatus}\n\n` +
                  `_⚡ POWERED BY KINGBOT`
          };

        } catch (err) {
          if (statusMsg && statusMsg.key) {
            try { await sock.sendMessage(remoteJid, { delete: statusMsg.key }); } catch (e) {}
          }
          return {
            text: `👑 *Kingbot Truecaller*\n\n❌ Error processing.`
          };
        }
      }
    }
  }
};