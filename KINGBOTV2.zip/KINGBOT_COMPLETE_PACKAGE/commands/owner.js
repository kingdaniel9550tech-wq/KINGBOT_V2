const { PREFIX } = require("../config");
const { isOwner } = require("../utils");
const state = require("../state");
const { downloadMediaMessage } = require("@whiskeysockets/baileys");
const { exec } = require("child_process");
const path = require("path");

module.exports = {
  category: "Owner",
  commands: {
    broadcast: {
      desc: "(Owner only) Send a message to all known chats, e.g. !broadcast Hello everyone",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const text = ctx.args.join(" ");
        if (!text) return `Usage: ${PREFIX}broadcast <message>`;
        // Note: requires a stored list of chat JIDs in ctx.knownChats to actually broadcast.
        return "📢 Broadcast queued (hook this up to your stored chat list in index.js).";
      },
    },
    block: {
      desc: "(Owner only) Reply to a user's message with !block to block them",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const quotedParticipant = ctx.msg.message?.extendedTextMessage?.contextInfo?.participant;
        if (!quotedParticipant) return `Reply to a user's message with ${PREFIX}block`;
        await ctx.sock.updateBlockStatus(quotedParticipant, "block");
        return "🚫 User blocked.";
      },
    },
    unblock: {
      desc: "(Owner only) !unblock <number> to unblock a user",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const number = ctx.args[0];
        if (!number) return `Usage: ${PREFIX}unblock <number>`;
        await ctx.sock.updateBlockStatus(`${number}@s.whatsapp.net`, "unblock");
        return "✅ User unblocked.";
      },
    },
    setprefix: {
      desc: "(Owner only) Change the command prefix (requires restart to persist)",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const newPrefix = ctx.args[0];
        if (!newPrefix) return `Usage: ${PREFIX}setprefix <new prefix>`;
        return `ℹ️ To change the prefix permanently, edit PREFIX in config.js to "${newPrefix}" and restart the bot.`;
      },
    },
    setmode: {
      desc: "(Owner only) Set the bot to public (anyone can use it) or private (owner only): !setmode public | private",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const choice = (ctx.args[0] || "").toLowerCase();
        if (choice !== "public" && choice !== "private") return `Usage: ${PREFIX}setmode <public|private>\nCurrent mode: ${state.mode}`;
        state.mode = choice;
        return `✅ Bot mode set to *${choice}*.\n${choice === "private" ? "Only you can use commands now." : "Anyone can use commands now."}`;
      },
    },
    setpp: {
      desc: "(Owner only) Reply to an image with !setpp to set it as the bot's WhatsApp profile picture",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const quoted = ctx.msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const target = quoted ? { message: quoted, key: ctx.msg.key } : ctx.msg;
        if (!target.message?.imageMessage) return `Reply to an image with ${PREFIX}setpp`;
        try {
          const buffer = await downloadMediaMessage(target, "buffer", {});
          await ctx.sock.updateProfilePicture(ctx.sock.user.id, buffer);
          return "✅ Bot profile picture updated.";
        } catch (err) {
          return `⚠️ Couldn't update the profile picture: ${err.message}`;
        }
      },
    },
    setchannel: {
      desc: "(Owner only) Set your WhatsApp Channel link for the reply watermark: !setchannel <link>",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const link = ctx.args[0];
        if (!link) return `Usage: ${PREFIX}setchannel <link>\nCurrent: ${state.channelLink || "(not set)"}`;
        state.channelLink = link;
        return `✅ Channel link set to: ${link}\nTurn the watermark on with ${PREFIX}watermark on`;
      },
    },
    setreplyimage: {
      desc: "(Owner only) Reply to an image with !setreplyimage to attach it to every bot reply from now on. !setreplyimage off to go back to plain text.",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        if ((ctx.args[0] || "").toLowerCase() === "off") {
          state.replyImage = null;
          return "✅ Reply image removed — replies go back to plain text.";
        }
        const quoted = ctx.msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const target = quoted ? { message: quoted, key: ctx.msg.key } : ctx.msg;
        if (!target.message?.imageMessage) return `Reply to an image with ${PREFIX}setreplyimage (or ${PREFIX}setreplyimage off to turn it off)`;
        try {
          const buffer = await downloadMediaMessage(target, "buffer", {});
          state.replyImage = buffer;
          return "✅ Reply image set. Every bot reply will now include this image, with the reply text as the caption.\n(Note: this resets if the bot restarts — you'll need to set it again.)";
        } catch (err) {
          return `⚠️ Couldn't set the reply image: ${err.message}`;
        }
      },
    },
    watermark: {
      desc: "(Owner only) Toggle appending your channel link to bot replies: !watermark on|off",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const choice = (ctx.args[0] || "").toLowerCase();
        if (choice !== "on" && choice !== "off") {
          return `Usage: ${PREFIX}watermark <on|off>\nCurrently: ${state.watermarkEnabled ? "on" : "off"}\nChannel link: ${state.channelLink || "(not set)"}`;
        }
        if (choice === "on" && !state.channelLink) return `⚠️ Set a channel link first with ${PREFIX}setchannel <link>`;
        state.watermarkEnabled = choice === "on";
        return `✅ Watermark ${state.watermarkEnabled ? "enabled" : "disabled"}.`;
      },
    },
    update: {
      desc: "(Owner only) Pull the latest code from git and restart: !update (only works if this bot was deployed via 'git clone')",
      run: async (ctx) => {
        if (!isOwner(ctx)) return "⚠️ Owner only command.";
        const projectRoot = path.join(__dirname, "..");

        exec("git pull", { cwd: projectRoot }, async (err, stdout) => {
          if (err) {
            await ctx.sock.sendMessage(ctx.remoteJid, {
              text: `⚠️ Update failed: ${err.message}\nThis usually means the bot wasn't deployed via "git clone" — .update needs a real git repository to pull from, and won't work on a manually-uploaded copy.`,
            });
            return;
          }
          if (stdout.includes("Already up to date")) {
            await ctx.sock.sendMessage(ctx.remoteJid, { text: "✅ Already running the latest version — nothing to update." });
            return;
          }
          await ctx.sock.sendMessage(ctx.remoteJid, { text: "📦 New code pulled. Installing dependencies..." });
          exec("npm install", { cwd: projectRoot }, async (installErr) => {
            if (installErr) {
              await ctx.sock.sendMessage(ctx.remoteJid, {
                text: `✅ Code updated, but "npm install" failed: ${installErr.message}\nYou may need to run it manually before restarting.`,
              });
              return;
            }
            await ctx.sock.sendMessage(ctx.remoteJid, { text: "✅ Updated successfully. Restarting now..." });
            // Exits so the host's process manager restarts it fresh with the new code.
            // This relies on the host auto-restarting on exit (KataBump, PM2, Docker
            // with --restart, etc. all do this) — hosts without that will need a
            // manual Start afterward.
            setTimeout(() => process.exit(0), 2000);
          });
        });

        return "🔄 Checking for updates...";
      },
    },
  },
};