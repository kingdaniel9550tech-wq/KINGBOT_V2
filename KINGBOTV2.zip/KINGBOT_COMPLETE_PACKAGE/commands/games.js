const { PREFIX } = require("../config");
const { riddles, scrambleWords, slotEmojis } = require("../data");

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

// simple in-memory session store, keyed by chat id
const guessSessions = {};
const riddleSessions = {};
const scrambleSessions = {};
const hiloSessions = {};

function shuffle(word) {
  const arr = word.split("");
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  const shuffled = arr.join("");
  return shuffled === word ? shuffle(word) : shuffled;
}

module.exports = {
  category: "Games",
  commands: {
    guess: {
      desc: "Number guessing game. !guess start to begin, then !guess <number>",
      run: async (ctx) => {
        const jid = ctx.remoteJid;
        if (ctx.args[0] === "start") {
          guessSessions[jid] = Math.floor(Math.random() * 100) + 1;
          return "🎯 I'm thinking of a number between 1 and 100. Try !guess <number>";
        }
        if (!(jid in guessSessions)) return `Start a game first with ${PREFIX}guess start`;
        const num = parseInt(ctx.args[0]);
        if (isNaN(num)) return `Usage: ${PREFIX}guess <number>, or ${PREFIX}guess start`;
        const answer = guessSessions[jid];
        if (num === answer) {
          delete guessSessions[jid];
          return "🎉 Correct! You win!";
        }
        return num < answer ? "📈 Higher!" : "📉 Lower!";
      },
    },
    rps: {
      desc: "Play rock-paper-scissors, e.g. !rps rock",
      run: async (ctx) => {
        const choices = ["rock", "paper", "scissors"];
        const user = (ctx.args[0] || "").toLowerCase();
        if (!choices.includes(user)) return `Usage: ${PREFIX}rps <rock|paper|scissors>`;
        const bot = pick(choices);
        let result;
        if (bot === user) result = "It's a tie!";
        else if (
          (user === "rock" && bot === "scissors") ||
          (user === "paper" && bot === "rock") ||
          (user === "scissors" && bot === "paper")
        )
          result = "You win! 🎉";
        else result = "I win! 🤖";
        return `You: ${user}\nMe: ${bot}\n${result}`;
      },
    },
    trivia: {
      desc: "Get a random trivia question",
      run: async () => {
        const trivia = [
          { q: "What is the capital of Japan?", a: "Tokyo" },
          { q: "How many continents are there?", a: "7" },
          { q: "What planet is known as the Red Planet?", a: "Mars" },
          { q: "What's the largest ocean on Earth?", a: "Pacific" },
        ];
        const t = pick(trivia);
        return `❓ ${t.q}\n(Answer: ||${t.a}||)`;
      },
    },
    riddle: {
      desc: "!riddle for a new riddle, !riddle answer <your guess> to answer",
      run: async (ctx) => {
        const jid = ctx.remoteJid;
        if (ctx.args[0] === "answer") {
          if (!(jid in riddleSessions)) return `No active riddle. Start one with ${PREFIX}riddle`;
          const guess = ctx.args.slice(1).join(" ").toLowerCase();
          const correct = riddleSessions[jid].a.toLowerCase();
          if (guess === correct) {
            delete riddleSessions[jid];
            return "🎉 Correct!";
          }
          return "❌ Not quite, try again!";
        }
        const r = pick(riddles);
        riddleSessions[jid] = r;
        return `🧩 ${r.q}\nAnswer with: ${PREFIX}riddle answer <your guess>`;
      },
    },
    slots: {
      desc: "Spin the slot machine",
      run: async () => {
        const spin = [pick(slotEmojis), pick(slotEmojis), pick(slotEmojis)];
        const line = spin.join(" | ");
        const win = spin[0] === spin[1] && spin[1] === spin[2];
        return `🎰 ${line}\n${win ? "🎉 JACKPOT! You win!" : "Better luck next time!"}`;
      },
    },
    scramble: {
      desc: "!scramble for a new scrambled word, !scramble guess <word> to answer",
      run: async (ctx) => {
        const jid = ctx.remoteJid;
        if (ctx.args[0] === "guess") {
          if (!(jid in scrambleSessions)) return `No active scramble. Start one with ${PREFIX}scramble`;
          const guess = ctx.args.slice(1).join(" ").toLowerCase();
          const correct = scrambleSessions[jid].toLowerCase();
          if (guess === correct) {
            delete scrambleSessions[jid];
            return "🎉 Correct! Well unscrambled!";
          }
          return "❌ Not quite, try again!";
        }
        const word = pick(scrambleWords);
        scrambleSessions[jid] = word;
        return `🔀 Unscramble this: *${shuffle(word)}*\n(${word.length} letters)\nAnswer with: ${PREFIX}scramble guess <word>`;
      },
    },
    hilo: {
      desc: "Higher-or-lower card game. !hilo to start, then !hilo higher or !hilo lower",
      run: async (ctx) => {
        const jid = ctx.remoteJid;
        const choice = (ctx.args[0] || "").toLowerCase();
        if (choice !== "higher" && choice !== "lower") {
          const card = Math.floor(Math.random() * 13) + 1;
          hiloSessions[jid] = card;
          return `🃏 Your card: ${card} (1-13)\nWill the next card be ${PREFIX}hilo higher or ${PREFIX}hilo lower?`;
        }
        if (!(jid in hiloSessions)) return `Start a round first with ${PREFIX}hilo`;
        const prev = hiloSessions[jid];
        const next = Math.floor(Math.random() * 13) + 1;
        delete hiloSessions[jid];
        const won = (choice === "higher" && next > prev) || (choice === "lower" && next < prev);
        const tie = next === prev;
        return `🃏 Previous: ${prev} → Next: ${next}\n${tie ? "It's a tie — no win, no loss." : won ? "🎉 You won!" : "❌ You lost!"}`;
      },
    },
  },
};
