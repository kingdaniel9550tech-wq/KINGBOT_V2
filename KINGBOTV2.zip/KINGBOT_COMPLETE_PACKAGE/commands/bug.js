const { PREFIX } = require("../config");
const { isOwner } = require("../utils");
const state = require("../state");

module.exports = {
  category: "Owner",
  commands: {
    bug: {
      desc: "View system diagnostics and debug status (Owner only)",
      run: async (ctx) => {
        if (!isOwner(ctx)) {
          return "⚠️ This command is strictly for my sweet and handsome owner KING DANIEL.";
        }

        const uptimeSeconds = process.uptime();
        const hours = Math.floor(uptimeSeconds / 3600);
        const minutes = Math.floor((uptimeSeconds % 3600) / 60);
        const seconds = Math.floor(uptimeSeconds % 60);

        const memoryUsage = process.memoryUsage();
        const heapUsedMB = (memoryUsage.heapUsed / 1024 / 1024).toFixed(2);
        const rssMB = (memoryUsage.rss / 1024 / 1024).toFixed(2);

        return `👑 *KINGBOT DEBUG STATUS* 👑\n\n` +
          `⏱️ *Uptime:* ${hours}h ${minutes}m ${seconds}s\n` +
          `🧠 *Heap Memory:* ${heapUsedMB} MB\n` +
          `📦 *RSS Memory:* ${rssMB} MB\n` +
          `🤖 *Active AI Chats:* ${state.aiChatChats.size}\n` +
          `🛡️ *Antilink Groups:* ${state.antilinkChats ? state.antilinkChats.size : 0}\n` +
          `⚙️ *Bot Mode:* ${state.mode}\n\n` +
          `*Status:* All systems running smoothly. Raw crash logs appear in your server terminal console.`;
      },
    },
  },
};