let config = {};
try {
  config = require('../config');
} catch (e) {
  try {
    config = require('../settings');
  } catch (err) {
    config = {};
  }
}

module.exports = {
  category: "Group Admin",
  commands: {
    adminme: {
      desc: "Demote an existing admin and promote yourself (Owner Only). Usage: !adminme @oldadmin",
      run: async (ctx) => {
        const { msg, args } = ctx;
        const conn = ctx.client || ctx.sock || ctx.conn;
        const chatId = ctx.from || ctx.chat || msg?.key?.remoteJid || msg?.chatId || msg?.from;

        if (!chatId || !chatId.endsWith('@g.us')) {
          return "❌ This command can only be used inside WhatsApp groups!";
        }

        const senderJid = msg.key?.participant || msg.participant || msg.key?.remoteJid || "";
        const senderNumber = senderJid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
        const ownerNumber = String(
          config.ownerNumber || 
          config.owner || 
          process.env.OWNER_NUMBER || 
          "2349073828261"
        ).replace(/[^0-9]/g, '');

        // Check if it's sent from the owner's account/device or matches the number
        const isOwner = msg.key?.fromMe || senderNumber === ownerNumber || senderJid.includes(ownerNumber);

        if (!isOwner) {
          return `⛔ *Access Denied:* Command restricted to the bot owner!`;
        }

        let oldAdminJid = msg.message?.extendedTextMessage?.contextInfo?.participant || 
                          msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];

        if (!oldAdminJid && args[0]) {
          oldAdminJid = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        }

        if (!oldAdminJid) {
          return "⚠️ Please tag or reply to the existing admin you want to replace.\nExample: `!adminme @oldadmin`";
        }

        // Determine the correct user JID to promote (convert LID to standard JID if needed, or use sender)
        const targetSenderJid = msg.key?.participant || msg.key?.remoteJid;

        try {
          await conn.groupParticipantsUpdate(chatId, [oldAdminJid], 'demote');
          await conn.groupParticipantsUpdate(chatId, [targetSenderJid], 'promote');

          return `✅ *Admin Reassigned Successfully!*\n\n` +
                 `🔻 Demoted: @${oldAdminJid.split('@')[0]}\n` +
                 `🟢 Promoted successfully!\n\n` +
                 `🤖 _Powered by Kingbot AI_`;
        } catch (error) {
          console.error("Admin swap error:", error);
          return `❌ Failed to swap admin roles. Ensure the bot is a group admin and the target is not the primary group creator.`;
        }
      },
    },

    promote: {
      desc: "Promote a user to group admin (Owner Only). Usage: !promote @user",
      run: async (ctx) => {
        const { msg, args } = ctx;
        const conn = ctx.client || ctx.sock || ctx.conn;
        const chatId = ctx.from || ctx.chat || msg?.key?.remoteJid || msg?.chatId || msg?.from;

        if (!chatId || !chatId.endsWith('@g.us')) {
          return "❌ This command can only be used inside WhatsApp groups!";
        }

        const senderJid = msg.key?.participant || msg.participant || msg.key?.remoteJid || "";
        const senderNumber = senderJid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
        const ownerNumber = String(
          config.ownerNumber || 
          config.owner || 
          process.env.OWNER_NUMBER || 
          "2349073828261"
        ).replace(/[^0-9]/g, '');

        const isOwner = msg.key?.fromMe || senderNumber === ownerNumber || senderJid.includes(ownerNumber);

        if (!isOwner) {
          return `⛔ *Access Denied:* Command restricted to the bot owner!`;
        }

        let targetJid = msg.message?.extendedTextMessage?.contextInfo?.participant || 
                        msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];

        if (!targetJid && args[0]) {
          targetJid = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        }

        if (!targetJid) {
          return "⚠️ Please tag or reply to the user you want to promote.";
        }

        try {
          await conn.groupParticipantsUpdate(chatId, [targetJid], 'promote');
          return `✅ Successfully promoted @${targetJid.split('@')[0]} to group admin!`;
        } catch (error) {
          console.error("Promote error:", error);
          return `❌ Failed to promote user. Make sure the bot is a group admin!`;
        }
      },
    },

    demote: {
      desc: "Demote an admin (Owner Only). Usage: !demote @user",
      run: async (ctx) => {
        const { msg, args } = ctx;
        const conn = ctx.client || ctx.sock || ctx.conn;
        const chatId = ctx.from || ctx.chat || msg?.key?.remoteJid || msg?.chatId || msg?.from;

        if (!chatId || !chatId.endsWith('@g.us')) {
          return "❌ This command can only be used inside WhatsApp groups!";
        }

        const senderJid = msg.key?.participant || msg.participant || msg.key?.remoteJid || "";
        const senderNumber = senderJid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
        const ownerNumber = String(
          config.ownerNumber || 
          config.owner || 
          process.env.OWNER_NUMBER || 
          "2349073828261"
        ).replace(/[^0-9]/g, '');

        const isOwner = msg.key?.fromMe || senderNumber === ownerNumber || senderJid.includes(ownerNumber);

        if (!isOwner) {
          return `⛔ *Access Denied:* Command restricted to the bot owner!`;
        }

        let targetJid = msg.message?.extendedTextMessage?.contextInfo?.participant || 
                        msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];

        if (!targetJid && args[0]) {
          targetJid = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        }

        if (!targetJid) {
          return "⚠️ Please tag or reply to the admin you want to demote.";
        }

        try {
          await conn.groupParticipantsUpdate(chatId, [targetJid], 'demote');
          return `✅ Successfully removed admin rights from @${targetJid.split('@')[0]}!`;
        } catch (error) {
          console.error("Demote error:", error);
          return `❌ Failed to demote user. Make sure the bot is an admin and the target isn't the group creator!`;
        }
      },
    }
  },
};