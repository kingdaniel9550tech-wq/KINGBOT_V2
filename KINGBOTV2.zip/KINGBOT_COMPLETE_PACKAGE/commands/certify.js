const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

module.exports = {
  category: "Owner",
  description: "Generate premium official course certificates (Owner only)",
  commands: {
    certify: {
      category: "tools",
      description: "Generate a premium PDF certificate. Usage: .certify <Student Name>",
      async run(ctx) {
        const { sock, remoteJid, msg, args } = ctx;

        // Strict Owner Verification Check
        const ownerJid = sock.user?.id || "";
        const ownerPhoneNum = ownerJid ? ownerJid.split("@")[0].split(":")[0] : "";
        const configOwnerNum = process.env.OWNER_NUMBER || "";
        const sender = msg.key.participant || remoteJid;
        const isOwner = msg.key.fromMe || (ownerPhoneNum && sender.includes(ownerPhoneNum)) || (configOwnerNum && sender.includes(configOwnerNum));

        if (!isOwner) {
          return { text: "⚠️ *Access Denied:* This command is restricted to the bot owner only." };
        }

        const name = args.join(" ").trim();

        if (!name) {
          return { text: "⚠️ Usage: `.certify <Student Name>`" };
        }

        const fileNameOut = `${name.replace(/\s+/g, '_')}_Certificate.pdf`;
        const filePath = path.join(__dirname, `../data/${fileNameOut}`);

        // Ensure data directory exists
        const dir = path.dirname(filePath);
        if (!fs.existsSync(dir)) {
          fs.mkdirSync(dir, { recursive: true });
        }

        await sock.sendMessage(remoteJid, { text: `📜 *Kingbot is crafting a premium certificate for ${name}...*` });

        try {
          // A4 Landscape dimensions: width = 841.89, height = 595.28 points
          const doc = new PDFDocument({ layout: 'landscape', size: 'A4', margin: 0 });
          const stream = fs.createWriteStream(filePath);
          doc.pipe(stream);

          const pageWidth = 841.89;
          const pageHeight = 595.28;

          // 1. Background Frame & Double Borders
          // Outer thick border
          doc.rect(25, 25, pageWidth - 50, pageHeight - 50)
             .lineWidth(4)
             .strokeColor('#1A365D') // Deep Navy Blue
             .stroke();

          // Inner thin accent border (Gold/Bronze tone)
          doc.rect(32, 32, pageWidth - 64, pageHeight - 64)
             .lineWidth(1)
             .strokeColor('#C5A059') 
             .stroke();

          // Corner decorative squares for premium look
          const cornerSize = 10;
          doc.rect(28, 28, cornerSize, cornerSize).fill('#1A365D');
          doc.rect(pageWidth - 38, 28, cornerSize, cornerSize).fill('#1A365D');
          doc.rect(28, pageHeight - 38, cornerSize, cornerSize).fill('#1A365D');
          doc.rect(pageWidth - 38, pageHeight - 38, cornerSize, cornerSize).fill('#1A365D');

          // 2. Header Section
          doc.font('Helvetica-Bold')
             .fontSize(22)
             .fillColor('#1A365D')
             .text("KINGDANIEL", 0, 75, { align: 'center', characterSpacing: 2 });

          doc.font('Helvetica')
             .fontSize(11)
             .fillColor('#C5A059')
             .text("OFFICIAL CERTIFICATE OF COMPLETION", 0, 105, { align: 'center', characterSpacing: 3 });

          // 3. Body Content
          doc.font('Helvetica-Oblique')
             .fontSize(15)
             .fillColor('#4A5568')
             .text("This is proudly presented to", 0, 160, { align: 'center' });

          // Recipient Name (Large & Prominent)
          doc.font('Helvetica-Bold')
             .fontSize(38)
             .fillColor('#1A365D')
             .text(name, 0, 205, { align: 'center' });

          // Decorative underline beneath name
          doc.moveTo(pageWidth / 2 - 180, 255)
             .lineTo(pageWidth / 2 + 180, 255)
             .lineWidth(2)
             .strokeColor('#C5A059')
             .stroke();

          // Description Paragraph
          doc.font('Helvetica')
             .fontSize(13)
             .fillColor('#2D3748')
             .text(
               "For successfully completing the intensive 5-Day Introductory Coding Tutorial,\n" +
               "demonstrating exceptional dedication, mastering core web architecture,\n" +
               "and building foundational automation projects.",
               70, 285, 
               { align: 'center', lineGap: 6 }
             );

          // 4. Footer & Signature Section
          const signatureY = 430;

          // Left Side: Date Issued
          const currentDate = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
          doc.font('Helvetica-Bold').fontSize(11).fillColor('#1A365D').text("DATE ISSUED", 120, signatureY, { align: 'center', width: 180 });
          doc.moveTo(120, signatureY + 20).lineTo(300, signatureY + 20).lineWidth(1).strokeColor('#CBD5E0').stroke();
          doc.font('Helvetica').fontSize(11).fillColor('#4A5568').text(currentDate, 120, signatureY + 28, { align: 'center', width: 180 });

          // Right Side: Instructor Signature
          doc.font('Helvetica-Bold').fontSize(11).fillColor('#1A365D').text("AUTHORIZED SIGNATURE", pageWidth - 300, signatureY, { align: 'center', width: 180 });
          doc.moveTo(pageWidth - 300, signatureY + 20).lineTo(pageWidth - 120, signatureY + 20).lineWidth(1).strokeColor('#CBD5E0').stroke();
          doc.font('Helvetica-Bold').fontSize(12).fillColor('#1A365D').text("King Daniel", pageWidth - 300, signatureY + 28, { align: 'center', width: 180 });
          doc.font('Helvetica').fontSize(10).fillColor('#718096').text("Lead Instructor, KingDaniel", pageWidth - 300, signatureY + 44, { align: 'center', width: 180 });

          doc.end();

          stream.on('finish', async () => {
            await sock.sendMessage(remoteJid, {
              document: fs.readFileSync(filePath),
              mimetype: 'application/pdf',
              fileName: fileNameOut,
              caption: `👑 *Here is the official premium certificate for ${name}!*`
            });

            // Clean up file after sending
            if (fs.existsSync(filePath)) {
              fs.unlinkSync(filePath);
            }
          });

        } catch (err) {
          return { text: `❌ Error generating premium certificate: ${err.message || err}` };
        }
      }
    }
  }
};