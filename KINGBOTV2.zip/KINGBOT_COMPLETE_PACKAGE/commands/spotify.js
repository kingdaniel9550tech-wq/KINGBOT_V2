// commands/spotify.js
const axios = require('axios');

const SPOTIFY_API_BASE = 'https://apis.davidcyril.name.ng';
const SPOTIFY_API_PATH = '/spotifydl';
const SPOTIFY_API_TIMEOUT_MS = 60000;
const SPOTIFY_TRACK_PREFIX = 'https://open.spotify.com/track/';

async function fetchSpotifyTrack(url) {
    if (!url.startsWith(SPOTIFY_TRACK_PREFIX)) {
        throw new Error('Please provide a valid Spotify track link starting with https://open.spotify.com/track/...');
    }

    const { data } = await axios.get(`${SPOTIFY_API_BASE}${SPOTIFY_API_PATH}`, {
        params: { url },
        timeout: SPOTIFY_API_TIMEOUT_MS,
    });

    if (!data || !data.success || !data.DownloadLink) {
        throw new Error('Failed to process Spotify track or no download link returned.');
    }

    return data;
}

module.exports = {
  category: "downloader",
  commands: {
    spotify: {
      description: "Download Spotify tracks via link with rich KingBot UI",
      run: async (ctx) => {
        const { sock, msg, args, remoteJid, usedPrefix = "." } = ctx;
        const url = args.join(' ').trim();

        if (!url || !url.includes('open.spotify.com/track/')) {
          return `┏━━━〔 *🔍 SPOTIFY DOWNLOADER* 〕━━━\n┃\n┃ Please provide a valid Spotify track link!\n┃\n┗━━━ *Example:* \`${usedPrefix}spotify https://open.spotify.com/track/4uLU6hMCjMI75M1A2tKUQC\``;
        }

        try {
          await sock.sendMessage(remoteJid, { react: { text: '⏳', key: msg.key } });
        } catch (_) {}

        let result;
        try {
          result = await fetchSpotifyTrack(url);
        } catch (err) {
          try {
            await sock.sendMessage(remoteJid, { react: { text: '❌', key: msg.key } });
          } catch (_) {}

          const isTimeout = err.code === 'ECONNABORTED' || /timeout/i.test(err.message || '');
          const friendly = isTimeout
            ? 'The Spotify service took too long to respond. Try again in a moment.'
            : (err.message || 'Something went wrong fetching that track.');

          return `┏━━━〔 *❌ DOWNLOAD FAILED* 〕━━━\n┃\n┃ ${friendly}\n┗━━━━━━━━━━━━━━━━━━━━`;
        }

        const caption = 
            `┏━━━〔 👑 *KINGBOT SPOTIFY DOWNLOADER* 👑 〕━━━\n` +
            `┃\n` +
            `┃ 🎵 *Title:* ${result.title || 'Unknown'}\n` +
            `┃ 👤 *Author:* ${result.channel || 'Unknown'}\n` +
            `┃ ⏱️ *Duration:* ${result.duration || 'Unknown'}\n` +
            `┃ 📥 *Download:* ${result.DownloadLink}\n` +
            `┃\n` +
            `┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `> _⚡ Powered by KingBot Media Stream_`;

        try {
          if (result.thumbnail) {
            await sock.sendMessage(remoteJid, { image: { url: result.thumbnail }, caption }, { quoted: msg });
          } else {
            await sock.sendMessage(remoteJid, { text: caption }, { quoted: msg });
          }

          try {
            await sock.sendMessage(remoteJid, { react: { text: '✅', key: msg.key } });
          } catch (_) {}

          return;
        } catch (err) {
          try {
            await sock.sendMessage(remoteJid, { react: { text: '❌', key: msg.key } });
          } catch (_) {}
          return `❌ Failed to send the info card, but here's the link:\n\n${caption}`;
        }
      }
    }
  }
};