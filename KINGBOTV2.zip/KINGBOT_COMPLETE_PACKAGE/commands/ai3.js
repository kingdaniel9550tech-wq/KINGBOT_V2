const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const axios = require('axios');

module.exports = {
  category: "ai",
  description: "Kingbot AI assistant (Owner only)",
  commands: {
    ai3: {
      category: "ai",
      description: "Kingbot AI assistant with vision & text capabilities (Owner only)",
      async run(ctx) {
        const { sock, remoteJid, msg, args } = ctx;

        // Strict Owner Verification Check
        const ownerJid = sock.user?.id || "";
        const ownerPhoneNum = ownerJid ? ownerJid.split("@")[0].split(":")[0] : "";
        const configOwnerNum = process.env.OWNER_NUMBER || "";
        const sender = msg.key.participant || remoteJid;
        const isOwner = msg.key.fromMe || (ownerPhoneNum && sender.includes(ownerPhoneNum)) || (configOwnerNum && sender.includes(configOwnerNum));

        if (!isOwner) {
          return { text: "⚠️ *Access Denied:* This command is restricted to the bot owner only." };
        }

        const prompt = args.join(" ").trim() || "Describe this image in detail and extract any text.";

        const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
        const quotedStanzaId = msg.message?.extendedTextMessage?.contextInfo?.stanzaId;

        const isImage = quotedMsg?.imageMessage;
        let messagesPayload = [];
        
        // Define Kingbot persona
        const systemPrompt = "You are Kingbot, an advanced and intelligent AI assistant created by King Daniel. You are helpful, professional, and precise.";

        if (isImage) {
          await sock.sendMessage(remoteJid, { text: "🔍 *Kingbot scanning and analyzing image...*" });

          const pseudoMsg = {
            key: { remoteJid, id: quotedStanzaId, participant: quotedParticipant },
            message: quotedMsg
          };

          try {
            const buffer = await downloadMediaMessage(pseudoMsg, 'buffer', {}, { logger: console, reuploadRequest: sock.updateMediaMessage });
            if (!buffer) return { text: "❌ Failed to download the image from WhatsApp." };

            const base64Image = buffer.toString('base64');
            const dataUrl = `data:image/jpeg;base64,${base64Image}`;

            messagesPayload = [
              { role: "system", content: systemPrompt },
              {
                role: "user",
                content: [
                  { type: "text", text: prompt },
                  { type: "image_url", image_url: { url: dataUrl } }
                ]
              }
            ];
          } catch (err) {
            return { text: `❌ Error processing image: ${err.message}` };
          }
        } else {
          if (!prompt) {
            return { text: "⚠️ Usage: `.ai3 Your question` or reply to an image with `.ai3 <question>`" };
          }
          await sock.sendMessage(remoteJid, { text: "🤖 *Kingbot thinking...*" });
          messagesPayload = [
            { role: "system", content: systemPrompt },
            { role: "user", content: prompt }
          ];
        }

        try {
          const apiKey = "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";
          const modelName = isImage ? "qwen/qwen3.6-27b" : "openai/gpt-oss-20b";

          const response = await axios.post(
            "https://api.groq.com/openai/v1/chat/completions",
            {
              model: modelName,
              messages: messagesPayload,
              temperature: 0.7
            },
            {
              headers: {
                "Authorization": `Bearer ${apiKey}`,
                "Content-Type": "application/json"
              }
            }
          );

          const replyText = response.data?.choices?.[0]?.message?.content || "No response generated.";

          return { 
            text: `👑 *KINGBOT (CREATED BY KING DANIEL)*\n\n${replyText}` 
          };

        } catch (err) {
          return { text: `❌ Error connecting to AI: ${err.response?.data?.error?.message || err.message}` };
        }
      }
    }
  }
};