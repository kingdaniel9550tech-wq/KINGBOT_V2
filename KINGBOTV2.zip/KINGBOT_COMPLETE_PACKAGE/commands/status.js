const { downloadMediaMessage } = require("@whiskeysockets/baileys");
const { PREFIX } = require("../config");

module.exports = {
  category: "Status",
  commands: {
    status: {
      desc: "Post a text update to your WhatsApp Status, e.g. !status Having a great day!",
      run: async (ctx) => {
        const text = ctx.args.join(" ");
        if (!text) return `Usage: ${PREFIX}status <text>`;
        if (!ctx.knownContacts.length) {
          return "⚠️ Haven't synced any contacts yet — try again in a moment after the bot's been connected a bit longer.";
        }
        try {
          await ctx.sock.sendMessage(
            "status@broadcast",
            { text },
            { broadcast: true, statusJidList: ctx.knownContacts }
          );
          return `✅ Status posted, reaching ${ctx.knownContacts.length} contacts.\n(Note: whether contacts see it also depends on your Status privacy setting — see !statusprivacy.)`;
        } catch (err) {
          return `⚠️ Couldn't post the status: ${err.message}`;
        }
      },
    },
    statusimage: {
      desc: "Reply to an image with !statusimage <caption> to post it to your WhatsApp Status",
      run: async (ctx) => {
        const quoted = ctx.msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const target = quoted ? { message: quoted, key: ctx.msg.key } : ctx.msg;
        if (!target.message?.imageMessage) return `Reply to an image with ${PREFIX}statusimage <caption>`;
        if (!ctx.knownContacts.length) {
          return "⚠️ Haven't synced any contacts yet — try again in a moment after the bot's been connected a bit longer.";
        }
        try {
          const buffer = await downloadMediaMessage(target, "buffer", {});
          const caption = ctx.args.join(" ");
          await ctx.sock.sendMessage(
            "status@broadcast",
            { image: buffer, caption },
            { broadcast: true, statusJidList: ctx.knownContacts }
          );
          return `✅ Image status posted, reaching ${ctx.knownContacts.length} contacts.`;
        } catch (err) {
          return `⚠️ Couldn't post the status: ${err.message}`;
        }
      },
    },
    statusprivacy: {
      desc: "Set who can see your Status: !statusprivacy public | contacts | private",
      run: async (ctx) => {
        const choice = (ctx.args[0] || "").toLowerCase();
        const map = { public: "all", contacts: "contacts", private: "none" };
        if (!map[choice]) return `Usage: ${PREFIX}statusprivacy <public|contacts|private>`;
        try {
          await ctx.sock.updateStatusPrivacy(map[choice]);
          return `✅ Status privacy set to *${choice}*.`;
        } catch (err) {
          return `⚠️ Couldn't update privacy: ${err.message}`;
        }
      },
    },
  },
};
