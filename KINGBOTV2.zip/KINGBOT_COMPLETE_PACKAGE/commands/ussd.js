const axios = require('axios');
const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, '../data');
if (!fs.existsSync(dataDir)) {
  try { fs.mkdirSync(dataDir, { recursive: true }); } catch (e) {}
}

const ordersFile = path.join(dataDir, 'orders.json');
const pinsFile = path.join(dataDir, 'pins.json');
const examsFile = path.join(dataDir, 'exams.json');

function loadJSON(filePath, defaultVal) {
  try {
    if (fs.existsSync(filePath)) {
      return JSON.parse(fs.readFileSync(filePath, 'utf8'));
    }
  } catch (e) {}
  return defaultVal;
}

function saveJSON(filePath, data) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
  } catch (e) {}
}

const rawOrders = loadJSON(ordersFile, []);
const ordersDB = new Map(rawOrders);

const initialPins = loadJSON(pinsFile, {
  waec: [{ pin: "83920192837456", serial: "WAEC-SER-001" }],
  neco: [{ pin: "99283746501928", serial: "NECO-SER-001" }]
});
const waecPinVault = initialPins.waec;
const necoPinVault = initialPins.neco;

const examVault = loadJSON(examsFile, {
  "EXAM-DEMO1": {
    title: "JAMB CBT Practice Package (General English & Mathematics)",
    content: 
      `📚 *JAMB CBT PRACTICE PACK*\n\n` +
      `*SECTION A: Use of English*\n` +
      `1. Choose the word nearest in meaning to the underlined word: 'His speech was *taciturn*.'\n` +
      `A) Loquacious B) Reserved C) Arrogant D) Boring\n` +
      `*Answer:* B (Reserved)\n\n` +
      `_Good luck with your preparation!_`
  }
});

function persistOrders() { saveJSON(ordersFile, Array.from(ordersDB.entries())); }
function persistPins() { saveJSON(pinsFile, { waec: waecPinVault, neco: necoPinVault }); }
function persistExams() { saveJSON(examsFile, examVault); }

// In-memory session store
const ussdSessions = new Map();

const SERVICES = {
  "1": { name: "UTME Registration Pin", priceNum: 7500, priceStr: "₦7,500", type: "standard_paid" },
  "2": { name: "WAEC Result Checker Card", priceNum: 6500, priceStr: "₦6,500", type: "waec" },
  "3": { name: "NECO Result Checker Card", priceNum: 3000, priceStr: "₦3,000", type: "neco" },
  "4": { name: "MTN 1GB Data Bundle (VTU)", priceNum: 400, priceStr: "₦400", type: "vtu_data" },
  "5": { name: "Airtel 1GB Data Bundle (VTU)", priceNum: 400, priceStr: "₦400", type: "vtu_data" },
  "6": { name: "Airtime Top-up (₦1,000)", priceNum: 1000, priceStr: "₦1,000", type: "vtu_airtime" },
  "7": { name: "O'Level Result Check", priceNum: 1500, priceStr: "₦1,500", type: "standard_paid" },
  "8": { name: "JAMB Result Check", priceNum: 1500, priceStr: "₦1,500", type: "standard_paid" },
  "9": { name: "Admission Processing", priceNum: 15000, priceStr: "₦15,000", type: "standard_paid" },
  "10": { name: "Ebook Sales (PDF Guide)", priceNum: 5000, priceStr: "₦5,000", type: "ebook" },
  "11": { name: "Custom Website Development", priceNum: 50000, priceStr: "₦50,000", type: "standard_paid" },
  "12": { name: "Exam Past Questions Package", priceNum: 4000, priceStr: "₦4,000", type: "exam" }
};

const PAYSTACK_CHECKOUT_LINK = process.env.PAYSTACK_CHECKOUT_LINK || "https://paystack.shop/pay/YOUR_PAYSTACK_LINK_HERE";

async function notifyOwner(sock, messageText) {
  try {
    const ownerNum = process.env.OWNER_NUMBER || "";
    if (!ownerNum) return;
    const cleanNum = ownerNum.replace(/[^0-9]/g, "");
    await sock.sendMessage(`${cleanNum}@s.whatsapp.net`, { text: `🚨 *KINGDANIEL BOT*\n\n${messageText}` });
  } catch (err) {}
}

// Core USSD Processor Logic
async function processUSSDInput(ctx, inputArg) {
  const { sock, remoteJid, msg } = ctx;

  const ownerJid = sock.user?.id || "";
  const ownerPhoneNum = ownerJid ? ownerJid.split("@")[0].split(":")[0] : "";
  const configOwnerNum = process.env.OWNER_NUMBER || "";
  const sender = msg.key.participant || remoteJid;
  const isOwner = msg.key.fromMe || (ownerPhoneNum && sender.includes(ownerPhoneNum)) || (configOwnerNum && sender.includes(configOwnerNum));

  const input = inputArg ? inputArg.toLowerCase() : "";
  let session = ussdSessions.get(remoteJid);

  if (!session) {
    ussdSessions.set(remoteJid, { step: "HOME" });
    session = ussdSessions.get(remoteJid);
  }

  // ================= GLOBAL EXIT / QUIT CHECK (0 or exit) =================
  if (input === "0" || input === "exit") {
    ussdSessions.delete(remoteJid); // Wipes session completely so bot stops listening to raw digits
    return {
      text: `🙏 *Session Ended*\n\nThank you for using KingDaniel Digital Service Portal. Your session has been safely closed. Type \`.ussd\` whenever you wish to start a new session.`
    };
  }

  // Return to main menu if user types "menu"
  if (input === "menu") {
    ussdSessions.set(remoteJid, { step: "HOME" });
    if (isOwner) {
      return {
        text: `👑 *KINGDANIEL BUSINESS (OWNER)*\n\n` +
              `Just reply with a number:\n\n` +
              `1️⃣ Place New Order / Service Catalogue\n` +
              `2️⃣ View All Active Orders (${ordersDB.size})\n` +
              `3️⃣ View Business Statistics & Stock\n` +
              `4️⃣ Management Guide\n` +
              `0️⃣ Exit Session`
      };
    } else {
      return {
        text: `👑 *KINGDANIEL DIGITAL SERVICE PORTAL*\n\n` +
              `Welcome! Just reply with the number of your choice:\n\n` +
              `1️⃣ View Services & Place Order\n` +
              `0️⃣ Exit Session`
      };
    }
  }

  // ================= HOME MENU ROUTING =================
  if (session.step === "HOME") {
    if (input === "1") {
      ussdSessions.set(remoteJid, { step: "ADD_SELECT_SERVICE" });
      return {
        text: `📝 *SELECT A SERVICE & PRICING*\n\n` +
              `1️⃣ UTME Registration — *${SERVICES["1"].priceStr}*\n` +
              `2️⃣ WAEC Result Checker — *${SERVICES["2"].priceStr}* 💳\n` +
              `3️⃣ NECO Result Checker — *${SERVICES["3"].priceStr}* 💳\n` +
              `4️⃣ MTN 1GB Data — *${SERVICES["4"].priceStr}* 📶\n` +
              `5️⃣ Airtel 1GB Data — *${SERVICES["5"].priceStr}* 📶\n` +
              `6️⃣ Airtime Top-up (₦1,000) — *${SERVICES["6"].priceStr}* ⚡\n` +
              `7️⃣ O'Level Check — *${SERVICES["7"].priceStr}*\n` +
              `8️⃣ JAMB Check — *${SERVICES["8"].priceStr}*\n` +
              `9️⃣ Admission Processing — *${SERVICES["9"].priceStr}*\n` +
              `🔟 Ebook Sales (PDF) — *${SERVICES["10"].priceStr}* 📂\n` +
              `11️⃣ Custom Website Dev — *${SERVICES["11"].priceStr}*\n` +
              `12️⃣ Exam Past Questions — *${SERVICES["12"].priceStr}* 🧠\n\n` +
              `*Just reply with the number (1 - 12), or 0 to exit:*`
      };
    } else if (input === "2" && isOwner) {
      ussdSessions.set(remoteJid, { step: "HOME" });
      if (ordersDB.size === 0) return { text: `📋 *Order List*\n\nNo orders recorded yet.\n\nReply *0* to exit.` };
      let listText = `📋 *All Orders (${ordersDB.size}):*\n\n`;
      for (const [id, order] of ordersDB.entries()) {
        listText += `🆔 *ID:* ${id}\n👤 *Client:* ${order.customerName}\n💼 *Service:* ${order.service}\n💰 *Price:* ${order.amount}\n💳 *Ref:* ${order.txRef}\n🔑 *Details:* ${order.accessCode || "None"}\n📌 *Status:* ${order.status}\n-----------------------------------\n`;
      }
      return { text: listText + `\nReply *0* to exit session.` };
    } else if (input === "3" && isOwner) {
      ussdSessions.set(remoteJid, { step: "HOME" });
      let completed = 0;
      for (const order of ordersDB.values()) {
        if (order.status.includes("Completed") || order.status.includes("Verified")) completed++;
      }
      return {
        text: `📊 *Business Statistics*\n\n` +
              `📦 Total Orders: ${ordersDB.size}\n` +
              `✅ Completed: ${completed}\n` +
              `📘 WAEC Pins: ${waecPinVault.length}\n` +
              `📗 NECO Pins: ${necoPinVault.length}\n\n` +
              `Reply *0* to exit session.`
      };
    } else if (input === "4" && isOwner) {
      ussdSessions.set(remoteJid, { step: "HOME" });
      return {
        text: `🛠️ *MANAGEMENT GUIDE*\n\n` +
              `📌 \`.addwaecpin PIN | SERIAL\`\n` +
              `📌 \`.addnecopin PIN | SERIAL\`\n` +
              `📌 \`.td ORDER_ID\` *(Fulfill & Send Invoice)*\n\n` +
              `Reply *0* to exit session.`
      };
    } else {
      return { text: `⚠️ Invalid selection. Reply with a valid menu option or type *0* to exit.` };
    }
  }

  // ================= SERVICE SELECTION =================
  else if (session.step === "ADD_SELECT_SERVICE") {
    const selectedService = SERVICES[input];
    if (!selectedService) {
      return { text: `⚠️ Invalid choice. Please reply with a number between *1* and *12*, or type *0* to exit.` };
    }

    ussdSessions.set(remoteJid, { 
      step: selectedService.type.startsWith("vtu") || selectedService.type === "standard_paid" ? "ADD_ENTER_VTU_DETAILS" : "ADD_ENTER_PAYSTACK_REF", 
      serviceType: selectedService.type,
      service: selectedService.name, 
      priceStr: selectedService.priceStr,
      priceNum: selectedService.priceNum
    });

    if (selectedService.type.startsWith("vtu") || selectedService.type === "standard_paid") {
      return {
        text: `💼 *Service:* ${selectedService.name}\n` +
              `💰 *Amount:* *${selectedService.priceStr}*\n\n` +
              `💳 *PAYMENT INSTRUCTIONS*\n` +
              `1. Pay via link: \`${PAYSTACK_CHECKOUT_LINK}\`\n\n` +
              `📲 *Reply with your Phone Number & Reference separated by comma:*\n` +
              `*Example:* \`08012345678, T123456789\`\n\n` +
              `_(Reply *0* to cancel & exit)_`
      };
    } else {
      return {
        text: `💼 *Service:* ${selectedService.name}\n` +
              `💰 *Amount:* *${selectedService.priceStr}*\n\n` +
              `💳 *PAYMENT INSTRUCTIONS*\n` +
              `1. Pay via link: \`${PAYSTACK_CHECKOUT_LINK}\`\n\n` +
              `📲 *Reply with your Paystack Transaction Reference:*\n` +
              `*Example:* \`T123456789\`\n\n` +
              `_(Reply *0* to cancel & exit)_`
      };
    }
  }

  // ================= VTU & STANDARD PAID DETAILS FLOW =================
  else if (session.step === "ADD_ENTER_VTU_DETAILS") {
    const parts = inputArg.split(",").map(p => p.trim());
    if (parts.length < 2) {
      return { text: `⚠️ Please provide both your Phone Number and Reference separated by comma!\n*Example:* \`08012345678, T123456789\`\n\n_(Reply *0* to exit)_` };
    }

    const detailsInfo = parts[0];
    const txRef = parts[1];

    for (const existingOrder of ordersDB.values()) {
      if (existingOrder.txRef && existingOrder.txRef.toLowerCase() === txRef.toLowerCase()) {
        ussdSessions.delete(remoteJid);
        return { text: `❌ *Reference Already Used!*\nThis Paystack reference has already been used.\n\nSession ended. Type \`.ussd\` to restart.` };
      }
    }

    const paystackKey = process.env.PAYSTACK_SECRET_KEY;
    if (!paystackKey) return { text: `⚠️ \`PAYSTACK_SECRET_KEY\` not set in environment.` };

    let isVerified = false;
    try {
      const verifyRes = await axios.get(`https://api.paystack.co/transaction/verify/${txRef}`, {
        headers: { Authorization: `Bearer ${paystackKey}` }
      });
      if (verifyRes.data?.status && verifyRes.data.data.status === "success") {
        if (verifyRes.data.data.amount / 100 >= session.priceNum) isVerified = true;
      }
    } catch (e) {}

    if (!isVerified) {
      ussdSessions.delete(remoteJid);
      return { text: `❌ *Payment Verification Failed!* Invalid or unconfirmed reference.\n\nSession ended. Type \`.ussd\` to restart.` };
    }

    const orderId = `KDG-${Math.floor(100 + Math.random() * 900)}`;
    ordersDB.set(orderId, {
      id: orderId,
      service: session.service,
      amount: session.priceStr,
      customerName: `Client (${detailsInfo})`,
      chatJid: remoteJid,
      txRef: txRef,
      accessCode: `Info: ${detailsInfo}`,
      status: "Verified & Processing",
      date: new Date().toLocaleDateString()
    });
    persistOrders();
    await notifyOwner(sock, `New Paid Order!\n🆔 ID: ${orderId}\n💼 Service: ${session.service}\n📞 Phone: ${detailsInfo}\n💳 Ref: ${txRef}`);

    ussdSessions.delete(remoteJid); // Terminate session successfully after completion
    return {
      text: `✅ *Payment Verified Successfully!* 🎉\n\n` +
            `🆔 *Order ID:* \`${orderId}\`\n` +
            `💼 *Service:* ${session.service}\n` +
            `📌 *Status:* *Verified & Processing*\n\n` +
            `Your order has been queued for fulfillment. Session closed.`
    };
  }

  // ================= PAYSTACK PIN / FILE VERIFICATION FLOW =================
  else if (session.step === "ADD_ENTER_PAYSTACK_REF") {
    const txRef = inputArg.trim();
    if (!txRef) return { text: `⚠️ Please provide your Paystack Transaction Reference!\n\n_(Reply *0* to exit)_` };

    for (const existingOrder of ordersDB.values()) {
      if (existingOrder.txRef && existingOrder.txRef.toLowerCase() === txRef.toLowerCase()) {
        ussdSessions.delete(remoteJid);
        return { text: `❌ *Reference Already Used!*\n\nSession ended. Type \`.ussd\` to restart.` };
      }
    }

    const paystackKey = process.env.PAYSTACK_SECRET_KEY;
    if (!paystackKey) return { text: `⚠️ \`PAYSTACK_SECRET_KEY\` not set.` };

    let isVerified = false;
    try {
      const verifyRes = await axios.get(`https://api.paystack.co/transaction/verify/${txRef}`, {
        headers: { Authorization: `Bearer ${paystackKey}` }
      });
      if (verifyRes.data?.status && verifyRes.data.data.status === "success") {
        if (verifyRes.data.data.amount / 100 >= session.priceNum) isVerified = true;
      }
    } catch (err) {}

    if (!isVerified) {
      ussdSessions.delete(remoteJid);
      return { text: `❌ *Payment Verification Failed!* Invalid reference.\n\nSession ended. Type \`.ussd\` to restart.` };
    }

    const orderId = `KDG-${Math.floor(100 + Math.random() * 900)}`;

    if (session.serviceType === "waec" || session.serviceType === "neco") {
      const vault = session.serviceType === "waec" ? waecPinVault : necoPinVault;
      if (vault.length === 0) {
        ussdSessions.delete(remoteJid);
        await notifyOwner(sock, `⚠️ Stock Empty for ${session.service}! Order ${orderId}`);
        return { text: `⚠️ *Payment Verified, but Pin Stock is Empty!*\nAdmin has been notified. Session ended.` };
      }
      const allocated = vault.shift();
      session.serviceType === "waec" ? persistPins() : persistPins();
      
      ordersDB.set(orderId, {
        id: orderId,
        service: session.service,
        amount: session.priceStr,
        customerName: `${session.service.split(" ")[0]} Buyer`,
        chatJid: remoteJid,
        txRef: txRef,
        accessCode: `PIN: ${allocated.pin} | Serial: ${allocated.serial}`,
        status: "Verified & Completed",
        date: new Date().toLocaleDateString()
      });
      persistOrders();
      ussdSessions.delete(remoteJid);
      return {
        text: `✅ *Payment Verified Successfully!* 🎉\n\n` +
              `🆔 *Order ID:* \`${orderId}\`\n` +
              `📌 *PIN:* \`${allocated.pin}\`\n` +
              `🔢 *Serial:* \`${allocated.serial}\`\n\n` +
              `Session closed. Thank you!`
      };
    }

    if (session.serviceType === "ebook") {
      ordersDB.set(orderId, {
        id: orderId,
        service: session.service,
        amount: session.priceStr,
        customerName: "Ebook Buyer",
        chatJid: remoteJid,
        txRef: txRef,
        accessCode: "Ebook PDF Delivered",
        status: "Verified & Completed",
        date: new Date().toLocaleDateString()
      });
      persistOrders();
      ussdSessions.delete(remoteJid);

      const docBuffer = Buffer.from("📚 KINGDANIEL OFFICIAL EBOOK GUIDE\n\nChapter 1: Getting Started...\nThank you for your purchase!", "utf-8");
      await sock.sendMessage(remoteJid, {
        document: docBuffer,
        mimetype: "application/pdf",
        fileName: "KingDaniel_Ebook.pdf",
        caption: `✅ *Payment Verified!* 📂 Your PDF guide is attached above.`
      });
      return { text: `✅ *Payment Verified & Ebook Sent!* 🎉 Session closed.` };
    }

    ussdSessions.delete(remoteJid);
    return { text: `✅ *Payment Verified Successfully!* Order ID: \`${orderId}\`\n\nSession closed.` };
  }

  ussdSessions.delete(remoteJid);
  return { text: `Session ended. Type \`.ussd\` to restart.` };
}

module.exports = {
  category: "business",
  ussdSessions,
  processUSSDInput,
  commands: {
    ussd: {
      description: "Interactive USSD portal",
      async run(ctx) {
        const { remoteJid, sock, msg } = ctx;
        ussdSessions.set(remoteJid, { step: "HOME" });

        const ownerJid = sock.user?.id || "";
        const ownerPhoneNum = ownerJid ? ownerJid.split("@")[0].split(":")[0] : "";
        const configOwnerNum = process.env.OWNER_NUMBER || "";
        const sender = msg.key.participant || remoteJid;
        const isOwner = msg.key.fromMe || (ownerPhoneNum && sender.includes(ownerPhoneNum)) || (configOwnerNum && sender.includes(configOwnerNum));

        if (isOwner) {
          return {
            text: `👑 *KINGDANIEL BUSINESS (OWNER)*\n\n` +
                  `Just reply with a number:\n\n` +
                  `1️⃣ Place New Order / Service Catalogue\n` +
                  `2️⃣ View All Active Orders (${ordersDB.size})\n` +
                  `3️⃣ View Business Statistics & Stock\n` +
                  `4️⃣ Management Guide\n` +
                  `0️⃣ Exit Session`
          };
        } else {
          return {
            text: `👑 *KINGDANIEL DIGITAL SERVICE PORTAL*\n\n` +
                  `Welcome! Just reply with the number of your choice:\n\n` +
                  `1️⃣ View Services & Place Order\n` +
                  `0️⃣ Exit Session`
          };
        }
      }
    },
    track: {
      category: "business",
      description: "Track order status",
      async run(ctx) {
        const orderId = ctx.args[0]?.toUpperCase();
        if (!orderId) return { text: "⚠️ Usage: `.track KDG-101`" };
        const order = ordersDB.get(orderId);
        if (!order) return { text: `❌ Order not found: *${orderId}*` };
        return { text: `📦 *ORDER TRACKER*\n\n🆔 ID: ${order.id}\n💼 Service: ${order.service}\n💰 Amount: ${order.amount}\n📌 Status: *${order.status}*\n🔑 Details: \`${order.accessCode || "None"}\`` };
      }
    },
    addwaecpin: {
      category: "business",
      description: "Stock WAEC pins",
      async run(ctx) {
        const parts = ctx.args.join(" ").split("|").map(p => p.trim());
        if (parts.length < 2) return { text: "⚠️ Usage: `.addwaecpin PIN | SERIAL`" };
        waecPinVault.push({ pin: parts[0], serial: parts[1] });
        persistPins();
        return { text: `✅ WAEC Pin Stocked! Total: ${waecPinVault.length}` };
      }
    },
    addnecopin: {
      category: "business",
      description: "Stock NECO pins",
      async run(ctx) {
        const parts = ctx.args.join(" ").split("|").map(p => p.trim());
        if (parts.length < 2) return { text: "⚠️ Usage: `.addnecopin PIN | SERIAL`" };
        necoPinVault.push({ pin: parts[0], serial: parts[1] });
        persistPins();
        return { text: `✅ NECO Pin Stocked! Total: ${necoPinVault.length}` };
      }
    },
    td: {
      category: "business",
      description: "Fulfill order and send premium enterprise invoice",
      async run(ctx) {
        const { sock, remoteJid, args } = ctx;
        const orderId = args[0]?.trim().toUpperCase();
        if (!orderId || !ordersDB.has(orderId)) return { text: `⚠️ Usage: \`.td KDG-101\`` };

        const order = ordersDB.get(orderId);
        order.status = "Completed & Fulfilled";
        persistOrders();

        const receiptContent = 
          `========================================\n` +
          `         KINGDANIEL DIGITAL HUB         \n` +
          `       OFFICIAL TRANSACTION INVOICE     \n` +
          `========================================\n\n` +
          `[TRANSACTION DETAILS]\n` +
          `* Order ID    : ${order.id}\n` +
          `* Date        : ${order.date}\n` +
          `* Client      : ${order.customerName}\n` +
          `* Pay Ref     : ${order.txRef || "N/A"}\n\n` +
          `----------------------------------------\n` +
          `[ITEMIZED SERVICE]\n` +
          `* Description : ${order.service}\n` +
          `* Total Paid  : ${order.amount}\n` +
          `* Status      : VERIFIED & COMPLETED\n\n` +
          `----------------------------------------\n` +
          `[ACCESS CREDENTIALS / PINS]\n` +
          `${order.accessCode || "None"}\n\n` +
          `========================================\n` +
          `      Thank you for your patronage!     \n` +
          `========================================`;

        const receiptBuffer = Buffer.from(receiptContent, "utf-8");

        if (order.chatJid) {
          try {
            await sock.sendMessage(order.chatJid, {
              document: receiptBuffer,
              mimetype: "text/plain",
              fileName: `Invoice_${order.id}.txt`,
              caption: `✅ *Your Order Has Been Fulfilled!* 📄 Official invoice attached above.`
            });
          } catch (e) {}
        }

        return { text: `✅ Order *${order.id}* fulfilled and invoice file dispatched!` };
      }
    }
  }
};