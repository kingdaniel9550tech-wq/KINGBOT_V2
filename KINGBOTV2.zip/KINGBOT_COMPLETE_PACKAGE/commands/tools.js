const { PREFIX } = require("../config");
const QRCode = require("qrcode");

module.exports = {
  category: "Tools",
  commands: {
    calc: {
      desc: "Evaluate a math expression, e.g. !calc (2+3)*4",
      run: async (ctx) => {
        const expr = ctx.args.join(" ");
        if (!expr) return `Usage: ${PREFIX}calc <expression>`;
        if (!/^[0-9+\-*/().\s%^]+$/.test(expr)) return "⚠️ Only numbers and + - * / ( ) % ^ are allowed.";
        try {
          const safeExpr = expr.replace(/\^/g, "**");
          // eslint-disable-next-line no-new-func
          const result = Function(`"use strict"; return (${safeExpr})`)();
          return `🧮 Result: ${result}`;
        } catch {
          return "⚠️ Invalid expression.";
        }
      },
    },
    currency: {
      desc: "Convert currency, e.g. !currency 10 USD NGN",
      run: async (ctx) => {
        const [amtStr, from, to] = ctx.args;
        if (!amtStr || !from || !to) return `Usage: ${PREFIX}currency <amount> <from> <to>`;
        const amt = parseFloat(amtStr);
        if (isNaN(amt)) return "⚠️ Invalid amount.";
        try {
          const res = await fetch(`https://api.exchangerate.host/convert?from=${from.toUpperCase()}&to=${to.toUpperCase()}&amount=${amt}`);
          const data = await res.json();
          if (!data.result) return "⚠️ Could not fetch conversion rate.";
          return `💱 ${amt} ${from.toUpperCase()} = ${data.result.toFixed(2)} ${to.toUpperCase()}`;
        } catch {
          return "⚠️ Currency service is unavailable right now.";
        }
      },
    },
    time: {
      desc: "Show the current server time",
      run: async () => `🕐 ${new Date().toUTCString()}`,
    },
    date: {
      desc: "Show today's date",
      run: async () => `📅 ${new Date().toDateString()}`,
    },
    weather: {
      desc: "Get current weather for a city, e.g. !weather Lagos",
      run: async (ctx) => {
        const city = ctx.args.join(" ");
        if (!city) return `Usage: ${PREFIX}weather <city>`;
        try {
          const geoRes = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1`);
          const geo = await geoRes.json();
          if (!geo.results || !geo.results.length) return `⚠️ Couldn't find "${city}".`;
          const { latitude, longitude, name, country } = geo.results[0];
          const wRes = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true`);
          const w = await wRes.json();
          const cw = w.current_weather;
          return `🌦️ Weather in ${name}, ${country}\n🌡️ Temp: ${cw.temperature}°C\n💨 Wind: ${cw.windspeed} km/h`;
        } catch {
          return "⚠️ Weather service is unavailable right now.";
        }
      },
    },
    translate: {
      desc: "Translate text, e.g. !translate es Hello there",
      run: async (ctx) => {
        const [lang, ...rest] = ctx.args;
        const text = rest.join(" ");
        if (!lang || !text) return `Usage: ${PREFIX}translate <lang-code> <text>`;
        try {
          const res = await fetch(
            `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${lang}&dt=t&q=${encodeURIComponent(text)}`
          );
          const data = await res.json();
          const translated = data[0].map((chunk) => chunk[0]).join("");
          return `🌐 ${translated}`;
        } catch {
          return "⚠️ Translation service is unavailable right now.";
        }
      },
    },
    qrcode: {
      desc: "Generate a QR code image from text",
      run: async (ctx) => {
        const text = ctx.args.join(" ");
        if (!text) return `Usage: ${PREFIX}qrcode <text>`;
        const buffer = await QRCode.toBuffer(text, { width: 400 });
        return { image: buffer, caption: `📱 QR code for: ${text}` };
      },
    },
    wiki: {
      desc: "Get a Wikipedia summary, e.g. !wiki Nigeria",
      run: async (ctx) => {
        const term = ctx.args.join(" ");
        if (!term) return `Usage: ${PREFIX}wiki <topic>`;
        try {
          const res = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(term)}`);
          if (res.status === 404) return `⚠️ No Wikipedia article found for "${term}".`;
          const data = await res.json();
          return `📖 *${data.title}*\n${data.extract}`;
        } catch {
          return "⚠️ Wikipedia is unavailable right now.";
        }
      },
    },
    define: {
      desc: "Get the dictionary definition of a word",
      run: async (ctx) => {
        const word = ctx.args[0];
        if (!word) return `Usage: ${PREFIX}define <word>`;
        try {
          const res = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`);
          if (res.status === 404) return `⚠️ No definition found for "${word}".`;
          const data = await res.json();
          const meaning = data[0].meanings[0];
          return `📘 *${word}* (${meaning.partOfSpeech})\n${meaning.definitions[0].definition}`;
        } catch {
          return "⚠️ Dictionary service is unavailable right now.";
        }
      },
    },
    shorturl: {
      desc: "Shorten a URL, e.g. !shorturl https://example.com",
      run: async (ctx) => {
        const url = ctx.args[0];
        if (!url) return `Usage: ${PREFIX}shorturl <url>`;
        try {
          const res = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`);
          const short = await res.text();
          return `🔗 ${short}`;
        } catch {
          return "⚠️ URL shortener is unavailable right now.";
        }
      },
    },
    poll: {
      desc: "Create a poll, e.g. !poll Best pizza topping? | Cheese | Pepperoni | Pineapple",
      run: async (ctx) => {
        const parts = ctx.args.join(" ").split("|").map((s) => s.trim()).filter(Boolean);
        if (parts.length < 3) return `Usage: ${PREFIX}poll <question> | <option1> | <option2> [| more options...]`;
        const [name, ...values] = parts;
        return { poll: { name, values, selectableCount: 1 } };
      },
    },
    reminder: {
      desc: "Set a reminder, e.g. !reminder 10m Call mom (units: s, m, h)",
      run: async (ctx) => {
        const match = ctx.args[0]?.match(/^(\d+)(s|m|h)$/);
        const text = ctx.args.slice(1).join(" ");
        if (!match || !text) return `Usage: ${PREFIX}reminder <10s|10m|10h> <message>`;
        const [, amount, unit] = match;
        const ms = { s: 1000, m: 60000, h: 3600000 }[unit] * parseInt(amount);
        if (ms > 24 * 3600000) return "⚠️ Max reminder time is 24h.";
        setTimeout(() => {
          ctx.sock.sendMessage(ctx.remoteJid, { text: `⏰ Reminder: ${text}` }).catch(() => {});
        }, ms);
        return `✅ Reminder set for ${amount}${unit} from now.\n(Note: reminders are lost if the bot restarts before they fire.)`;
      },
    },
    worldclock: {
      desc: "Get current time in a timezone, e.g. !worldclock Africa/Lagos",
      run: async (ctx) => {
        const tz = ctx.args[0];
        if (!tz) return `Usage: ${PREFIX}worldclock <Area/City> (e.g. Africa/Lagos, America/New_York, Asia/Tokyo)`;
        try {
          const res = await fetch(`https://worldtimeapi.org/api/timezone/${tz}`);
          if (!res.ok) return `⚠️ Unknown timezone "${tz}". Use format like Africa/Lagos.`;
          const data = await res.json();
          const dt = new Date(data.datetime);
          return `🕐 ${tz}: ${dt.toUTCString()}`;
        } catch {
          return "⚠️ World clock service is unavailable right now.";
        }
      },
    },
    bmi: {
      desc: "Calculate BMI, e.g. !bmi 70 1.75 (kg, meters)",
      run: async (ctx) => {
        const [weight, height] = ctx.args.map(Number);
        if (!weight || !height) return `Usage: ${PREFIX}bmi <weight_kg> <height_m>`;
        const bmi = weight / (height * height);
        let category;
        if (bmi < 18.5) category = "Underweight";
        else if (bmi < 25) category = "Normal weight";
        else if (bmi < 30) category = "Overweight";
        else category = "Obese";
        return `⚖️ BMI: ${bmi.toFixed(1)} (${category})\nThis is a general estimate, not medical advice.`;
      },
    },
    age: {
      desc: "Calculate age from a birth date, e.g. !age 2000-05-14",
      run: async (ctx) => {
        const dateStr = ctx.args[0];
        if (!dateStr || !/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return `Usage: ${PREFIX}age <YYYY-MM-DD>`;
        const birth = new Date(dateStr);
        if (isNaN(birth.getTime())) return "⚠️ Invalid date.";
        const now = new Date();
        let age = now.getFullYear() - birth.getFullYear();
        const m = now.getMonth() - birth.getMonth();
        if (m < 0 || (m === 0 && now.getDate() < birth.getDate())) age--;
        return `🎂 Age: ${age} years old`;
      },
    },
    genpass: {
      desc: "Generate a random secure password, e.g. !genpass 16",
      run: async (ctx) => {
        const length = Math.min(Math.max(parseInt(ctx.args[0]) || 12, 4), 64);
        const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
        let pass = "";
        for (let i = 0; i < length; i++) pass += chars[Math.floor(Math.random() * chars.length)];
        return `🔐 ${pass}`;
      },
    },
    lorem: {
      desc: "Generate lorem ipsum placeholder text, e.g. !lorem 30",
      run: async (ctx) => {
        const words = "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco laboris".split(" ");
        const count = Math.min(Math.max(parseInt(ctx.args[0]) || 20, 1), 200);
        const out = [];
        for (let i = 0; i < count; i++) out.push(words[i % words.length]);
        return out.join(" ") + ".";
      },
    },
  },
};
