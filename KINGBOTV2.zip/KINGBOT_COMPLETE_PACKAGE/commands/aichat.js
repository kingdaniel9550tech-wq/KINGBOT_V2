// commands/aichat.js
const fs = require('fs');
const path = require('path');

const statePath = path.join(__dirname, '../data/aichat_state.json');

// Helper to load state
function loadState() {
  try {
    const dir = path.dirname(statePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    if (!fs.existsSync(statePath)) {
      fs.writeFileSync(statePath, JSON.stringify({ enabled: false }));
      return { enabled: false };
    }
    return JSON.parse(fs.readFileSync(statePath, 'utf8'));
  } catch (e) {
    return { enabled: false };
  }
}

// Helper to save state
function saveState(state) {
  fs.writeFileSync(statePath, JSON.stringify(state, null, 2));
}

async function getAIResponse(prompt) {
  const apiKey = process.env.GEMINI_API_KEY || "AQ.Ab8RN6Iho7eRYbkvDOa3lA2jNAlhj63d5B4ENqYPvNAr935evQ";
  
  if (!apiKey) {
    return "⚠️ Kingbot AI is missing its Gemini API key!";
  }

  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=${apiKey}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [
          {
            role: "user",
            parts: [{ text: `System Instruction: You are Kingbot AI, a friendly, intelligent, and conversational WhatsApp assistant built by Abioye Daniel Olusegun (also known as Dan). Keep your responses natural, engaging, and suitably concise like a real person chatting on WhatsApp. Do not sound overly robotic.\n\nUser message: ${prompt}` }]
          }
        ]
      })
    });

    const data = await res.json();
    const reply = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    return reply || "Hmm, I'm drawing a blank right now. Say that again?";
  } catch (err) {
    console.error("AI Chat API error:", err);
    return "Oops! I had a little hiccup connecting to my brain. Try again in a second.";
  }
}

module.exports = {
  category: "AI",
  commands: {
    aichat: {
      desc: "Toggle AI chat feature on or off. Usage: !aichat on / !aichat off",
      run: async (ctx) => {
        const { msg, args } = ctx;
        const senderJid = msg.key?.participant || msg.key?.remoteJid || "";
        const senderNumber = senderJid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
        const ownerNumber = "2349073828261";

        // Strict owner check
        if (!msg.key?.fromMe && senderNumber !== ownerNumber) {
          return "⛔ *Access Denied:* Only Dan (the bot owner) can control AI chat!";
        }

        const action = args[0]?.toLowerCase();
        if (!action || !['on', 'off'].includes(action)) {
          const statusText = loadState().enabled ? "🟢 Enabled" : "🔴 Disabled";
          return `🤖 *AI Chat Status:* ${statusText}\n\n*Usage:* \`!aichat on\` or \`!aichat off\``;
        }

        const state = loadState();
        state.enabled = (action === 'on');
        saveState(state);

        return state.enabled 
          ? "🟢 *AI Chat has been enabled successfully!*" 
          : "🔴 *AI Chat has been disabled.*";
      }
    }
  },

  // Passive message listener
  onMessage: async (ctx) => {
    const state = loadState();
    if (!state.enabled) return; // Do nothing if AI chat is turned off

    const { msg } = ctx;
    const conn = ctx.client || ctx.sock || ctx.conn;
    const chatId = ctx.from || ctx.chat || msg?.key?.remoteJid || msg?.chatId;

    if (msg.key?.fromMe || !chatId) return;

    const messageText = 
      msg.message?.conversation || 
      msg.message?.extendedTextMessage?.text || 
      msg.message?.imageMessage?.caption || "";

    if (!messageText || messageText.trim().startsWith('!')) return;

    const isGroup = chatId.endsWith('@g.us');
    const botNumber = conn.user?.id ? conn.user.id.split(':')[0] : "";
    const isMentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.some(j => j.includes(botNumber));

    // In groups, only reply if tagged. In DMs, reply normally when active.
    if (isGroup && !isMentioned) return;

    try {
      await conn.sendPresenceUpdate('composing', chatId);
      const cleanPrompt = messageText.replace(/@\d+/g, "").trim();
      const replyText = await getAIResponse(cleanPrompt);
      await conn.sendMessage(chatId, { text: replyText }, { quoted: msg });
      await conn.sendPresenceUpdate('paused', chatId);
    } catch (error) {
      console.error("AI chat handling error:", error);
    }
  }
};