const axios = require('axios');

module.exports = {
  category: "Tools",
  commands: {
    getpp: {
      description: "Fetch and download a user's profile picture",
      async run(ctx) {
        const { sock, remoteJid, msg, args } = ctx;

        // Determine the target user (Mention, Replied message, or Phone number argument)
        let targetJid = remoteJid;
        const contextInfo = msg.message?.extendedTextMessage?.contextInfo;

        if (contextInfo?.mentionedJid?.[0]) {
          targetJid = contextInfo.mentionedJid[0];
        } else if (contextInfo?.participant) {
          targetJid = contextInfo.participant;
        } else if (args[0]) {
          const cleanNum = args[0].replace(/[^0-9]/g, "");
          targetJid = `${cleanNum}@s.whatsapp.net`;
        }

        try {
          // Fetch the high-resolution profile picture URL from WhatsApp
          const ppUrl = await sock.profilePictureUrl(targetJid, 'image').catch(() => null);

          if (!ppUrl) {
            return { 
              text: `❌ Could not retrieve profile picture. The user may have their privacy settings set to restrict profile photos, or they don't have one.` 
            };
          }

          // Download the image data as a buffer
          const response = await axios.get(ppUrl, { responseType: 'arraybuffer' });
          const buffer = Buffer.from(response.data);

          // Send the image directly to chat with a caption
          await sock.sendMessage(remoteJid, {
            image: buffer,
            caption: `📸 *Profile Picture Retrieved!*\n👤 *User:* \`${targetJid.split('@')[0]}\``
          });

        } catch (err) {
          console.error("Error fetching profile picture:", err);
          return { text: `⚠️ Failed to fetch profile picture due to an error.` };
        }
      }
    }
  }
};