module.exports = {
  category: "utility",
  description: "Capture a live screenshot of any website instantly",
  commands: {
    ss: {
      category: "utility",
      description: "Take a screenshot of a webpage. Usage: .ss <url>",
      async run(ctx) {
        const { sock, remoteJid, args } = ctx;
        const targetUrl = args[0] ? args[0].trim() : "";

        if (!targetUrl) {
          return { 
            text: "👑 *Kingbot Screenshot Utility* 📸\n\n" +
                  "⚠️ *Invalid Usage!*\n" +
                  "Please provide a valid website URL to capture.\n\n" +
                  "📌 *Example:*\n" +
                  "`.ss https://google.com`" 
          };
        }

        // Ensure URL has http/https protocol
        let formattedUrl = targetUrl;
        if (!formattedUrl.startsWith("http://") && !formattedUrl.startsWith("https://")) {
          formattedUrl = "https://" + formattedUrl;
        }

        let statusMsg;
        try {
          statusMsg = await sock.sendMessage(remoteJid, { 
            text: "👑 *Kingbot Screenshot 📸*\n\n`[■■□□□] 40% — Rendering webpage snapshot...`" 
          });
        } catch (e) {}

        try {
          // Using a reliable public screenshot rendering API
          const screenshotApi = `https://api.screenshotone.com/take?url=${encodeURIComponent(formattedUrl)}&full_page=false&viewport_width=1280&viewport_height=800&device_scale_factor=1&format=jpg`;
          
          // Alternatively, using a free public utility endpoint if ScreenshotOne requires auth, let's use a robust public shot API:
          const fallbackApi = `https://api.siputzx.my.id/api/tools/ssweb?url=${encodeURIComponent(formattedUrl)}&device=desktop`;

          // Let's send the image directly via URL buffer or image message format in Baileys
          await sock.sendMessage(remoteJid, {
            image: { url: fallbackApi },
            caption: `👑 *Kingbot Web Screenshot* 📸\n\n🌐 *Target:* ${formattedUrl}\n\n_Generated successfully via Kingbot`
          });

          // Delete status message
          if (statusMsg && statusMsg.key) {
            try { await sock.sendMessage(remoteJid, { delete: statusMsg.key }); } catch (e) {}
          }

          return;

        } catch (err) {
          if (statusMsg && statusMsg.key) {
            try {
              await sock.sendMessage(remoteJid, {
                text: `👑 *Kingbot Screenshot Error*\n\n❌ Failed to capture webpage: ${err.message}`,
                edit: statusMsg.key
              });
            } catch (e) {}
          }
          return;
        }
      }
    }
  }
};