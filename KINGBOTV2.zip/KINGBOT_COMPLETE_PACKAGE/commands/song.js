const axios = require('axios');

module.exports = {
  category: "downloader",
  description: "Download song snippets",
  commands: {
    song: {
      category: "downloader",
      description: "Download 30s song. Usage: .song <song name>",
      async run(ctx) {
        const { sock, remoteJid, args } = ctx;
        const query = args.join(" ").trim();

        if (!query) {
          return { 
            text: "👑 *Kingbot Downloader 🎵*\n\n" +
                  "⚠️ *Invalid Usage!*\n" +
                  "Please provide the name of the song or artist.\n\n" +
                  "📌 *Example:*\n" +
                  "`.song kingdaniel9550`" 
          };
        }

        // 1. Initial status bar
        let statusMsg;
        try {
          statusMsg = await sock.sendMessage(remoteJid, { 
            text: "👑 *Kingbot Downloader 🎵*\n\n`[■□□□□] 20% — Initializing search...`" 
          });
        } catch (e) {
          statusMsg = await sock.sendMessage(remoteJid, { text: "👑 *Kingbot Downloader 🎵* — Searching..." });
        }

        const updateStatus = async (percent, text) => {
          if (statusMsg && statusMsg.key) {
            try {
              await sock.sendMessage(remoteJid, {
                text: `👑 *Kingbot Downloader 🎵*\n\n\`[${percent}] ${text}\``,
                edit: statusMsg.key
              });
            } catch (err) {}
          }
        };

        try {
          // 2. Search audio database
          await updateStatus("■■□□□", "50% — Finding audio...");
          const searchRes = await axios.get(`https://api.deezer.com/search?q=${encodeURIComponent(query)}`);
          const tracks = searchRes.data.data;

          if (!tracks || tracks.length === 0) {
            await updateStatus("█████", "❌ Error: No matching songs found.");
            return;
          }

          const track = tracks[0];
          const title = track.title;
          const artist = track.artist.name;
          const previewUrl = track.preview; // This is the standard ~30s sample

          if (!previewUrl) {
            await updateStatus("█████", "❌ Error: No preview available for this track.");
            return;
          }

          // 3. Finalizing
          await updateStatus("■■■■■", "100% — Sending 30s snippet...");

          // 4. Send the 30s audio file
          await sock.sendMessage(remoteJid, {
            audio: { url: previewUrl },
            mimetype: 'audio/mp4',
            ptt: false,
            caption: `👑 *Kingbot Downloader 🎵*\n\n` +
                     `🎵 *Title:* ${title}\n` +
                     `🎤 *Artist:* ${artist}\n\n` +
                     `_POWERED BY KINGBOT_`
          });

          // Delete status bar
          if (statusMsg && statusMsg.key) {
            try {
              await sock.sendMessage(remoteJid, { delete: statusMsg.key });
            } catch (e) {}
          }

          return;

        } catch (err) {
          if (statusMsg && statusMsg.key) {
            await sock.sendMessage(remoteJid, {
              text: `👑 *Kingbot Downloader 🎵*\n\n❌ *Error:* Failed: ${err.message}`,
              edit: statusMsg.key
            });
          }
          return;
        }
      }
    }
  }
};