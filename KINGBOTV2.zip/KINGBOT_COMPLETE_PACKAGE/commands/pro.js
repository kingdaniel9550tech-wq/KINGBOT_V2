const { askAI } = require("../aiClient");

module.exports = {
  category: "ai",
  commands: {
    pro: {
      description: "Translate local slang or Pidgin into formal professional business English",
      async run(ctx) {
        const { sock, remoteJid, args, msg } = ctx;
        const text = args.join(" ");

        if (!text) {
          return {
            text: "⚠️ Please provide text to translate!\n*Usage:* `!pro <your local slang, chat, or messy notes>`"
          };
        }

        await sock.sendMessage(remoteJid, { text: "🧠 Analyzing context and polishing into professional English..." }, { quoted: msg });

        try {
          const prompt = [
            {
              role: "system",
              content: "You are an expert linguistic AI translator specializing in converting Nigerian/African local slang, street expressions, informal chats, and Pidgin English into exceptionally polished, formal, and clear corporate business English, while preserving the exact core meaning and intent."
            },
            {
              role: "user",
              content: text
            }
          ];

          const translation = await askAI(prompt);

          return {
            text: `💼 *Professional Business Translation*\n\n"${translation.trim()}"\n\n───────────────────\n_Original Input: "${text}"_`
          };
        } catch (err) {
          console.error("Pro translation error:", err);
          return { text: "⚠️ Failed to process translation through AI." };
        }
      }
    }
  }
};