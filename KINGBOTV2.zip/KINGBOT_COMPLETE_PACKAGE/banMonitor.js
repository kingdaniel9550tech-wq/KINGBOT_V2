/**
 * 🚫 BAN MONITOR SYSTEM
 * Tracks WhatsApp bot account health and detects ban risks
 * Alerts user when ban indicators are detected
 */

const fs = require('fs');
const path = require('path');

class BanRiskMonitor {
  constructor(sessionId, ownerJid) {
    this.sessionId = sessionId;
    this.ownerJid = ownerJid;
    this.riskScore = 0;
    this.alerts = [];
    this.metrics = {
      failedMessageCount: 0,
      successfulMessages: 0,
      disconnects: 0,
      authFailures: 0,
      mediaBlockCount: 0,
      rateLimitHits: 0,
      lastFailTime: null,
      firstFailTime: null,
      connectionDrops24h: [],
    };
    this.healthCheckInterval = null;
    this.lastHealthCheck = Date.now();
    this.dataFile = path.join(__dirname, `data/ban_monitor_${sessionId}.json`);
    this.loadFromDisk();
  }

  /**
   * Add a failed message and update risk score
   */
  addFailedMessage(error) {
    this.metrics.failedMessageCount++;
    this.metrics.lastFailTime = Date.now();
    
    if (!this.metrics.firstFailTime) {
      this.metrics.firstFailTime = Date.now();
    }

    // Parse error type
    if (error.status === 401 || error.status === 403) {
      this.metrics.authFailures++;
      this.riskScore += 25;
      this._addAlert({
        type: 'AUTH_FAILURE',
        severity: 'CRITICAL',
        message: 'WhatsApp rejected authentication - possible ban',
        errorCode: error.status
      });
      return 'CRITICAL';
    }

    if (error.status === 429) {
      this.metrics.rateLimitHits++;
      this.riskScore += 15;
      this._addAlert({
        type: 'RATE_LIMITED',
        severity: 'HIGH',
        message: 'Rate limited by WhatsApp - reduce message frequency',
        errorCode: error.status
      });
      return 'HIGH';
    }

    if (error.message?.includes('media') || error.message?.includes('download')) {
      this.metrics.mediaBlockCount++;
      this.riskScore += 20;
      this._addAlert({
        type: 'MEDIA_BLOCKED',
        severity: 'HIGH',
        message: 'Cannot send/receive media - elevated ban risk'
      });
      return 'HIGH';
    }

    if (error.message?.includes('ERR_BAD_REQUEST') || error.message?.includes('400')) {
      this.riskScore += 10;
      return 'MEDIUM';
    }

    this.riskScore += 5;
    return 'LOW';
  }

  /**
   * Record successful message send
   */
  addSuccessfulMessage() {
    this.metrics.successfulMessages++;
    // Decrease risk slightly after success
    if (this.riskScore > 0) this.riskScore -= 2;
  }

  /**
   * Record a connection drop/disconnect
   */
  addDisconnect() {
    this.metrics.disconnects++;
    const today = new Date().toDateString();
    
    this.metrics.connectionDrops24h.push({
      time: Date.now(),
      date: today
    });

    // Keep only last 24 hours
    this.metrics.connectionDrops24h = this.metrics.connectionDrops24h.filter(d => {
      const diff = Date.now() - d.time;
      return diff < 86400000; // 24 hours
    });

    this.riskScore += 5;

    // Multiple disconnects = serious problem
    if (this.metrics.connectionDrops24h.length > 3) {
      this.riskScore += 15;
      this._addAlert({
        type: 'FREQUENT_DISCONNECTS',
        severity: 'HIGH',
        message: `${this.metrics.connectionDrops24h.length} disconnects in 24h - network instability or ban incoming`
      });
      return 'HIGH';
    }

    return 'MEDIUM';
  }

  /**
   * Add a soft-ban signal (can send to some users but not others)
   */
  addSoftBanSignal(chatJid) {
    this.riskScore += 20;
    this._addAlert({
      type: 'SOFT_BAN',
      severity: 'CRITICAL',
      message: `Cannot send to ${chatJid} - possible shadow ban`
    });
  }

  /**
   * Get current risk level
   */
  getRiskLevel() {
    const threshold = process.env.CRITICAL_BAN_RISK_THRESHOLD || 80;
    const alertThreshold = process.env.BAN_RISK_ALERT_THRESHOLD || 50;

    if (this.riskScore >= threshold) return 'CRITICAL';
    if (this.riskScore >= alertThreshold) return 'HIGH';
    if (this.riskScore >= 25) return 'MEDIUM';
    return 'LOW';
  }

  /**
   * Check if should notify user
   */
  shouldNotifyUser() {
    const threshold = process.env.BAN_RISK_ALERT_THRESHOLD || 50;
    return this.riskScore >= threshold;
  }

  /**
   * Check if should pause bot operations
   */
  shouldPauseBot() {
    const threshold = process.env.CRITICAL_BAN_RISK_THRESHOLD || 80;
    return this.riskScore >= threshold;
  }

  /**
   * Get comprehensive health status
   */
  getStatus() {
    return {
      sessionId: this.sessionId,
      riskScore: Math.min(100, this.riskScore),
      riskLevel: this.getRiskLevel(),
      healthScore: Math.max(0, 100 - this.riskScore),
      alerts: this.alerts.slice(-10), // Last 10 alerts
      metrics: this.metrics,
      shouldPause: this.shouldPauseBot(),
      shouldAlert: this.shouldNotifyUser(),
      recommendation: this._getRecommendation(),
      timestamp: new Date().toISOString()
    };
  }

  /**
   * Get recommendation based on risk level
   */
  _getRecommendation() {
    const risk = this.getRiskLevel();

    switch (risk) {
      case 'CRITICAL':
        return '🚫 CRITICAL: STOP using this number immediately. Prepare to switch to a new number.';
      case 'HIGH':
        return '⚠️ HIGH RISK: Stop all bulk actions. Use bot sparingly only. Monitor closely.';
      case 'MEDIUM':
        return '📊 MEDIUM RISK: Reduce message frequency. Avoid bulk operations.';
      default:
        return '✅ SAFE: Low risk. Continue normal operation.';
    }
  }

  /**
   * Internal: Add alert to queue
   */
  _addAlert(alert) {
    this.alerts.push({
      ...alert,
      time: new Date().toISOString(),
      timestamp: Date.now()
    });

    // Keep only last 100 alerts
    if (this.alerts.length > 100) {
      this.alerts.shift();
    }

    this.saveToDisk();
  }

  /**
   * Reset risk score (use cautiously - only when issue is resolved)
   */
  resetRiskScore() {
    const oldScore = this.riskScore;
    this.riskScore = 0;
    this._addAlert({
      type: 'RISK_RESET',
      severity: 'INFO',
      message: `Risk score manually reset from ${oldScore} to 0`
    });
  }

  /**
   * Save state to disk
   */
  saveToDisk() {
    try {
      const dataDir = path.join(__dirname, 'data');
      if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
      
      fs.writeFileSync(this.dataFile, JSON.stringify({
        sessionId: this.sessionId,
        ownerJid: this.ownerJid,
        riskScore: this.riskScore,
        alerts: this.alerts,
        metrics: this.metrics,
        lastSaved: new Date().toISOString()
      }, null, 2));
    } catch (err) {
      console.error(`[BanMonitor] Failed to save to disk:`, err.message);
    }
  }

  /**
   * Load state from disk
   */
  loadFromDisk() {
    try {
      if (fs.existsSync(this.dataFile)) {
        const data = JSON.parse(fs.readFileSync(this.dataFile, 'utf8'));
        this.riskScore = data.riskScore || 0;
        this.alerts = data.alerts || [];
        this.metrics = { ...this.metrics, ...data.metrics };
        console.log(`[BanMonitor] Loaded state for ${this.sessionId}`);
      }
    } catch (err) {
      console.error(`[BanMonitor] Failed to load from disk:`, err.message);
    }
  }

  /**
   * Get detailed health report
   */
  getDetailedReport() {
    const recentAlerts = this.alerts.filter(a => Date.now() - a.timestamp < 3600000); // Last hour
    const criticalAlerts = this.alerts.filter(a => a.severity === 'CRITICAL');

    return {
      ...this.getStatus(),
      recentAlerts24h: this.alerts.slice(-20),
      criticalAlertsTotal: criticalAlerts.length,
      successRate: this.metrics.successfulMessages / (this.metrics.successfulMessages + this.metrics.failedMessageCount) || 0,
      avgFailuresPerHour: recentAlerts.length,
      statusEmoji: this.getRiskLevel() === 'CRITICAL' ? '🚫' : 
                   this.getRiskLevel() === 'HIGH' ? '⚠️' :
                   this.getRiskLevel() === 'MEDIUM' ? '📊' : '✅'
    };
  }
}

module.exports = BanRiskMonitor;
