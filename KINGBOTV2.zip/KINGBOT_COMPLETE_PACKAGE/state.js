module.exports = {
  mode: "public", // "public" — anyone can use commands | "private" — owner only

  // Automation (all in-memory — resets to these defaults on every restart)
  autoReplyEnabled: true, // keyword-based canned replies (see data.js autoReplies)
  autoReactEnabled: false,
  autoReactEmoji: "👍",
  groupWelcome: {}, // groupJid -> boolean (undefined = default enabled)
  aiChatChats: new Set(), // chat JIDs with AI auto-chat turned on
  antilinkChats: new Map(), // groupJid -> action mode ("delete", "warn", or "kick")
  antilinkWarnings: new Map(), // "groupJid_userJid" -> warning strike count
  schedules: [], // { id, jid, time: "HH:MM", text, lastFired: "YYYY-MM-DD" | null }
  groupSchedules: [], // { id, jid, action: "close" | "open", time: "HH:MM", lastFired: "YYYY-MM-DD" | null }
  // Watermark footer appended to bot replies
  watermarkEnabled: false, // off until a channel link is set
  channelLink: "", // set via !setchannel <link>
  replyImage: null, // Buffer — if set, every text reply sends as this image with the reply as caption
};