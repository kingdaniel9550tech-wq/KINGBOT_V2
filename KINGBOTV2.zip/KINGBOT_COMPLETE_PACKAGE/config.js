module.exports = {
  BOT_NAME: "KINGBOT",
  PREFIX: ".",
  OWNER_NUMBER: "2349073828261", // <-- your number
  OWNER_NAME: "KING DANIEL",
  SESSION_DIR: "session",

  // Pairing code login only — QR code is disabled in index.js entirely.
  USE_PAIRING_CODE: true,
  PHONE_NUMBER: "2349073828261",

  // Get a key at https://console.anthropic.com — required for .ai and .aichat.
  // Leave blank to leave the AI features disabled.
  ANTHROPIC_API_KEY: "",
  AI_MODEL: "claude-haiku-4-5-20251001",
};
