// ========================================
// 🔒 LOAD ENVIRONMENT VARIABLES
// ========================================
require('dotenv').config();

// Verify critical environment variables are set
const requiredEnvVars = ['BOT_LICENSE_KEY'];
const missingEnvVars = requiredEnvVars.filter(key => !process.env[key]);

if (missingEnvVars.length > 0) {
  console.error(`❌ CRITICAL: Missing required environment variables: ${missingEnvVars.join(', ')}`);
  console.error(`📋 Copy .env.example to .env and fill in all required values`);
  process.exit(1);
}

const { 
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} = require("@whiskeysockets/baileys");
const { Boom } = require("@hapi/boom");
const pino = require("pino");
const fs = require("fs");
const path = require("path");
const readline = require("readline");
const express = require("express");

const { PREFIX, SESSION_DIR, BOT_NAME, PHONE_NUMBER } = require("./config");
const state = require("./state");
const { isOwner } = require("./utils");
const { autoReplies } = require("./data");
const { askAI } = require("./aiClient");
const { isVerified, verifyUser, getPending, setPending, clearPending, sendOtpEmail } = require("./middleware/verify");
const db = require("./db");

// Import ban monitoring & session management
const BanRiskMonitor = require("./banMonitor");
const { globalSessionManager } = require("./sessionManager");

// ---- Anti-Spam & Session Tracking ----
const processedMessages = new Set();
let currentSock = null;
let pairingCodeRequested = false;
const knownContacts = new Set();
const groupActivity = new Map();

// Ban monitoring per session
const sessionMonitors = new Map();

// Tenant sessions and human handoffs storage
const tenantSessions = new Map();
const humanHandoffs = new Map(); 

// API Latency Tracking Metrics Array
const latencies = [];

async function measureLatency(apiName, apiCallFn) {
  const start = process.hrtime();
  try {
    const result = await apiCallFn();
    const diff = process.hrtime(start);
    const durationMs = (diff[0] * 1e3 + diff[1] * 1e-6).toFixed(2);
    latencies.push({ api: apiName, durationMs: Number(durationMs), timestamp: Date.now() });
    if (latencies.length > 500) latencies.shift();
    return result;
  } catch (err) {
    const diff = process.hrtime(start);
    latencies.push({ api: apiName, error: err.message, durationMs: Number((diff[0] * 1e3 + diff[1] * 1e-6).toFixed(2)), timestamp: Date.now() });
    throw err;
  }
}

// ---- Anti-Ban Human Simulation Helper ----
async function executeWithHumanDelay(sock, remoteJid, callback) {
  try {
    await sock.sendPresenceUpdate("composing", remoteJid);
    const randomDelay = Math.floor(Math.random() * 1500) + 1500;
    await new Promise((resolve) => setTimeout(resolve, randomDelay));
    return await callback();
  } catch (err) {
    console.error("Human delay execution error:", err);
    return null;
  }
}

// ---- Express Web Server & Paystack Webhook ----
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Paystack Webhook Handler
app.post("/api/paystack-webhook", async (req, res) => {
  const event = req.body;

  if (event && event.event === "charge.success") {
    const data = event.data;
    const metadata = data.metadata || {};
    const whatsappJid = metadata.whatsapp_jid;
    const productId = metadata.product_id;

    console.log(`💰 Payment successful received for product: ${productId} by ${whatsappJid}`);

    if (whatsappJid && currentSock) {
      try {
        const productFiles = {
          "ebook1": {
            caption: "🎉 *Payment Confirmed!* Here is your e-book. Thank you for your purchase!",
            documentUrl: "https://yourdomain.com/path-to-your-ebook.pdf", 
            fileName: "The_AI_Powered_Creator_Guide.pdf"
          }
        };

        const product = productFiles[productId];
        if (product) {
          await currentSock.sendMessage(whatsappJid, {
            document: { url: product.documentUrl },
            mimetype: "application/pdf",
            fileName: product.fileName,
            caption: product.caption
          });
        }
      } catch (err) {
        console.error("Failed to auto-deliver PDF via webhook:", err);
      }
    }
  }

  res.sendStatus(200);
});

const PORT = process.env.SERVER_PORT || process.env.PORT || 3000;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`🌐 Webhook server active on internal port ${PORT}`);
});

function ask(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => rl.question(question, (answer) => { rl.close(); resolve(answer.trim()); }));
}

// ---- Centralized Reply Helper ----
async function sendReply(sock, remoteJid, content, quotedMsg) {
  let textToSend = "";
  let imageToSend = null;

  if (typeof content === "string") {
    textToSend = content;
  } else if (content) {
    textToSend = content.text || content.caption || "";
    imageToSend = content.image || null;
  }

  if (state.replyImage && !imageToSend) {
    await sock.sendMessage(remoteJid, { image: state.replyImage, caption: textToSend }, { quoted: quotedMsg });
  } else if (imageToSend) {
    await sock.sendMessage(remoteJid, { image: imageToSend, caption: textToSend }, { quoted: quotedMsg });
  } else {
    await sock.sendMessage(remoteJid, { text: textToSend }, { quoted: quotedMsg });
  }
}

function getRealSender(sock, msg) {
  const participant = msg.key.participant || msg.participant || msg.key.remoteJid;
  if (!participant) return participant;
  
  state.lidMap = state.lidMap || {};
  if (msg.key.participantAlt && !msg.key.participantAlt.endsWith("@lid")) {
    state.lidMap[participant] = msg.key.participantAlt;
    return msg.key.participantAlt;
  }
  if (state.lidMap[participant]) return state.lidMap[participant];
  return participant;
}

// ---- STRICT LICENSE ENFORCEMENT ----
async function verifyDeploymentLicense() {
  const licenseKey = process.env.BOT_LICENSE_KEY;
  if (!licenseKey) {
    console.error("❌ CRITICAL: No license token provided in environment variables! Shutting down.");
    process.exit(1);
  }
  try {
    const res = await db.query("SELECT * FROM licenses WHERE token = $1", [licenseKey]);
    if (res.rows.length === 0) {
      console.error("❌ CRITICAL: Invalid license token! Shutting down bot immediately.");
      process.exit(1); // Hard-stops the application if license is fake or doesn't match database
    } else {
      console.log("🔒 License verification passed successfully!");
    }
  } catch (err) {
    console.error("❌ License database verification failed:", err.message);
    process.exit(1); // Fails safe
  }
}

// ---- Command Registry Loader ----
const registry = {};
let ussdModule = null;
let ksModule = null;
let kingChatModule = null;
let antilinkModule = null;

const commandsDir = path.join(__dirname, "commands");
if (fs.existsSync(commandsDir)) {
  for (const file of fs.readdirSync(commandsDir)) {
    if (!file.endsWith(".js")) continue;
    const modPath = path.join(commandsDir, file);
    const mod = require(modPath);
    
    if (file === "ussd.js") ussdModule = mod;
    if (file === "ks.js" || file === "police.js" || typeof mod.autoRaidCheck === "function") ksModule = mod;
    if (file === "kingchat.js") kingChatModule = mod;
    if (file === "antilink.js") antilinkModule = mod;

    for (const [name, cmd] of Object.entries(mod.commands || {})) {
      registry[name.toLowerCase()] = { ...cmd, category: mod.category };
    }
  }
  console.log(`${BOT_NAME || "KingBot"} Loaded ${Object.keys(registry).length} commands.`);
}

// ---- Main Master Bot Startup ----
async function startBot() {
  await verifyDeploymentLicense(); // Will kill process if license is invalid

  const { state: authState, saveCreds } = await useMultiFileAuthState(SESSION_DIR || './auth_info');
  const { version } = await fetchLatestBaileysVersion();
  const needsLogin = !authState.creds.registered && !pairingCodeRequested;

  const sock = makeWASocket({
    version,
    auth: authState,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    browser: ["Windows", "Chrome", "114.0.5735.198"],
  });

  currentSock = sock;
  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;
    const sessionId = SESSION_DIR || './auth_info';
    const monitor = sessionMonitors.get(sessionId);
    
    if (needsLogin && connection === "connecting" && !pairingCodeRequested) {
      pairingCodeRequested = true;
      setTimeout(async () => {
        let phoneNumber = PHONE_NUMBER;
        if (!phoneNumber) {
          phoneNumber = await ask("Enter your WhatsApp number with country code: ");
        }
        try {
          const code = await measureLatency("Master_PairingCode", async () => {
            return await sock.requestPairingCode(phoneNumber.replace(/[^0-9]/g, ""));
          });
          console.log(`\n========================================`);
          console.log(`👑 YOUR WHATSAPP PAIRING CODE: ${code}`);
          console.log(`========================================\n`);
        } catch (err) {
          console.error("Failed to request pairing code:", err.message);
          pairingCodeRequested = false;
          
          // Track auth failure
          if (monitor) {
            monitor.addFailedMessage(err);
          }
        }
      }, 2000);
    }

    if (connection === "close") {
      let statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
      console.warn(`[Connection] Disconnected with status code: ${statusCode}`);
      
      // Track disconnect for ban monitoring
      if (monitor) {
        monitor.addDisconnect();
        if (monitor.shouldPauseBot()) {
          console.error(`🚫 [BanMonitor] CRITICAL BAN RISK - Bot paused. ${monitor._getRecommendation()}`);
        }
      }
      
      if (statusCode !== DisconnectReason.loggedOut) {
        currentSock = null;
        setTimeout(() => startBot().catch(() => {}), 3000);
      }
    } else if (connection === "open") {
      console.log(`${BOT_NAME || "KingBot"} connected cleanly!`);
      if (monitor) monitor.resetRiskScore(); // Reset on successful reconnection
    }
  });

  // ---- Message Upsert / Router Handler ----
  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    const msg = messages[0];
    if (!msg.message) return;

    const msgId = msg.key.id;
    if (processedMessages.has(msgId)) return;
    processedMessages.add(msgId);
    if (processedMessages.size > 1000) {
      const firstKey = processedMessages.values().next().value;
      processedMessages.delete(firstKey);
    }

    const remoteJid = msg.key.remoteJid;
    const sender = getRealSender(sock, msg);
    const isFromMe = msg.key.fromMe === true;
    const userId = sender.split('@')[0];

    // ---- BAN MONITORING: Get/create session monitor ----
    const sessionId = SESSION_DIR || './auth_info';
    if (!sessionMonitors.has(sessionId)) {
      sessionMonitors.set(sessionId, new BanRiskMonitor(sessionId, process.env.OWNER_NUMBER));
    }
    const banMonitor = sessionMonitors.get(sessionId);
    
    // Check if bot should be paused due to ban risk
    if (banMonitor.shouldPauseBot() && !isOwner(sender)) {
      await sock.sendMessage(remoteJid, { 
        text: `⚠️ *Bot Temporarily Disabled*\n\nThis bot instance is experiencing issues and has been automatically paused for safety.\n\n${banMonitor._getRecommendation()}`
      }, { quoted: msg });
      return;
    }

    // Human Agent Handoff Check
    const bodyText = msg.message.conversation || msg.message.extendedTextMessage?.text || "";
    if (bodyText.toLowerCase() === '.handoff') {
      humanHandoffs.set(remoteJid, true);
      await sock.sendMessage(remoteJid, { text: "🛡️ Transferred to human support mode." }, { quoted: msg });
      return;
    }
    if (bodyText.toLowerCase() === '.resumeai') {
      humanHandoffs.delete(remoteJid);
      await sock.sendMessage(remoteJid, { text: "🤖 AI Bot resumed for this chat." }, { quoted: msg });
      return;
    }
    if (bodyText.toLowerCase() === '.banstatus' && isOwner(sender)) {
      const status = banMonitor.getStatus();
      const report = banMonitor.getDetailedReport();
      await sock.sendMessage(remoteJid, { 
        text: `*🚨 BAN RISK REPORT*\n\n${report.statusEmoji} *Risk Level:* ${report.riskLevel}\n*Risk Score:* ${report.riskScore}/100\n*Health Score:* ${report.healthScore}/100\n\n*Recent Alerts:* ${report.recentAlerts24h.length}\n*Critical Alerts:* ${report.criticalAlertsTotal}\n\n*Success Rate:* ${(report.successRate * 100).toFixed(1)}%\n\n*Recommendation:*\n${report.recommendation}`
      }, { quoted: msg });
      return;
    }
    if (humanHandoffs.get(remoteJid)) return; // Skip bot commands if under human agent control

    const body = bodyText;
    if (!body) return;

    // Run antilink and security checks if available
    if (antilinkModule && typeof antilinkModule.handleAntiLink === "function") {
      await antilinkModule.handleAntiLink({ sock, msg, remoteJid, sender, isFromMe, body }).catch(() => {});
    }

    const usedPrefix = body.startsWith(".") ? "." : (body.startsWith(PREFIX || "!") ? (PREFIX || "!") : null);

    // KingChat integration
    if (kingChatModule && typeof kingChatModule.handleKingChat === "function") {
      const handled = await kingChatModule.handleKingChat({ sock, msg, remoteJid, sender, isFromMe });
      if (handled) return;
    }

    if (!usedPrefix) return;

    const [rawCmd, ...args] = body.slice(usedPrefix.length).trim().split(/\s+/);
    const cmdName = rawCmd.toLowerCase();

    const cmd = registry[cmdName];
    if (!cmd) return;

    // ---- RATE LIMITING CHECK ----
    const session = globalSessionManager.getOrCreateSession(sessionId, process.env.OWNER_NUMBER);
    if (globalSessionManager.isRateLimited(sessionId, cmdName) && !isOwner(sender)) {
      const remaining = session.rateLimit.getRemainingForCommand(cmdName);
      await sock.sendMessage(remoteJid, { 
        text: `⏱️ *Rate Limit Exceeded*\n\nCommand \`${cmdName}\` is rate limited.\n\nPlease wait before using this command again.\n*Remaining uses this minute:* ${remaining}`
      }, { quoted: msg });
      return;
    }

    // ---- QUOTA CHECK ----
    if (globalSessionManager.isQuotaExceeded(sessionId) && !isOwner(sender)) {
      const quota = session.quotaManager.getStatus();
      await sock.sendMessage(remoteJid, { 
        text: `📊 *Quota Exceeded*\n\nHourly quota used: ${quota.hourlyUsage}/${quota.hourlyQuota}\nDaily quota used: ${quota.dailyUsage}/${quota.dailyQuota}\n\nPlease wait until quota resets.`
      }, { quoted: msg });
      return;
    }

    const ctx = { sock, msg, args, remoteJid, sender, registry, isFromMe };

    try {
      const result = await executeWithHumanDelay(sock, remoteJid, async () => {
        return await cmd.run(ctx);
      });
      
      // Track successful message
      banMonitor.addSuccessfulMessage();
      globalSessionManager.recordUsage(sessionId);
      
      await sendReply(sock, remoteJid, result, msg);
    } catch (err) {
      console.error(`Error running command "${cmdName}":`, err);
      
      // Track failed message for ban monitoring
      banMonitor.addFailedMessage(err);
      
      // Notify owner if ban risk is high
      if (banMonitor.shouldNotifyUser()) {
        const report = banMonitor.getDetailedReport();
        await sock.sendMessage(process.env.OWNER_NUMBER, { 
          text: `🚨 *Ban Risk Alert* 🚨\n\n${report.statusEmoji} ${report.recommendation}\n\nSession: ${sessionId}\nError: ${err.message}`
        }).catch(() => {});
      }
    }
  });

  return sock;
}

// ---- Memory Leak Detection & GC Triggers ----
setInterval(() => {
  const memUsage = process.memoryUsage().heapUsed / 1024 / 1024; // MB
  if (memUsage > 450 && global.gc) {
    console.warn(`[Warning] High memory usage: ${memUsage.toFixed(2)} MB. Triggering Garbage Collection.`);
    global.gc();
  }
}, 60000);

// ---- Automated Self-Healing Restarts ----
process.on("unhandledRejection", (err) => console.error("Unhandled rejection:", err));
process.on("uncaughtException", (err) => {
  console.error("Uncaught exception (Self-healing restart):", err);
  setTimeout(() => process.exit(1), 1000);
});

startBot();
