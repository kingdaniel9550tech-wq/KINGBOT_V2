# 🤴 KINGBOT - Setup & Deployment Guide

## 🚀 Quick Start

### Prerequisites
- **Node.js** ≥ 18 (check with `node -v`)
- **npm** (comes with Node.js)
- **PostgreSQL** 12+ (for database features)
- A **WhatsApp number** (preferably fresh/new for bot deployment)

### 1. Installation

```bash
# Extract the bot files
tar -xzf KINGBOT.tar.gz
cd kingbot

# Install dependencies
npm install

# Copy environment template
cp .env.example .env
```

### 2. Configure Environment Variables

Edit the `.env` file and add your credentials:

```bash
nano .env
```

**CRITICAL VARIABLES** (required):
```env
# Bot Configuration
BOT_NAME=KINGBOT
PREFIX=.
OWNER_NUMBER=2349073828261
OWNER_NAME=KING DANIEL
BOT_LICENSE_KEY=YOUR_LICENSE_KEY

# API Keys (get from official sources)
GROQ_API_KEY=YOUR_GROQ_KEY
ANTHROPIC_API_KEY=YOUR_CLAUDE_KEY
GEMINI_API_KEY=YOUR_GEMINI_KEY

# Payment (Paystack)
PAYSTACK_SECRET_KEY=sk_live_YOUR_LIVE_KEY
PAYSTACK_PUBLIC_KEY=pk_live_YOUR_PUBLIC_KEY

# Database
DB_HOST=localhost
DB_USER=postgres
DB_PASSWORD=your_secure_password
DB_NAME=kingbot_db
```

**DO NOT hardcode secrets in code — use .env only!**

### 3. Database Setup

```bash
# Create PostgreSQL database
createdb kingbot_db

# Run migrations (if any are provided)
# psql -d kingbot_db -f migrations.sql
```

### 4. Start the Bot

```bash
npm start
```

You should see:
```
✅ License verification passed successfully!
👑 YOUR WHATSAPP PAIRING CODE: 123-456-7890
```

Use the pairing code in **WhatsApp Settings → Linked Devices → Link a Device** (or scan QR on WhatsApp Web).

---

## 🚫 BAN PREVENTION & SAFETY

### WhatsApp Ban Risk Summary

⚠️ **WhatsApp actively detects and bans automated bots.** This bot includes anti-ban protections, but **no system is 100% safe**.

**Most Common Ban Triggers:**
- ✗ Rapid message sending (spam detection)
- ✗ Bulk messaging to many users
- ✗ Login from different IPs frequently
- ✗ Unusual account behavior patterns
- ✗ High error rates / failed messages

**This Bot Includes:**
- ✅ Rate limiting per command
- ✅ Hourly/daily quotas
- ✅ Ban risk monitoring with alerts
- ✅ Automatic pause on critical risk
- ✅ Human-like delays between messages
- ✅ Connection health tracking

### Check Ban Status

Use the `.banstatus` command (owner only):

```
.banstatus
```

Returns:
- Risk Level (🟢 LOW / 🟡 MEDIUM / 🟠 HIGH / 🔴 CRITICAL)
- Risk Score (0-100)
- Recent alerts & errors
- Success rate
- Recommendation

### Ban Risk Thresholds

```
Risk Score:  Meaning:                Action:
0-25         ✅ SAFE                Normal operation
25-50        📊 MEDIUM RISK          Monitor. Reduce usage.
50-80        ⚠️  HIGH RISK           Pause bulk operations.
80-100       🚫 CRITICAL             Stop immediately. Switch number.
```

### Rate Limits (per minute per session)

| Command | Limit | Reasoning |
|---------|-------|-----------|
| `.ai`, `.aichat` | 5/min | API cost + ban risk |
| `.download`, `.tiktok`, `.song` | 3/min | Heavy resource usage |
| `.imagine`, `.image` | 2/min | Heavy compute |
| Default commands | 20/min | Safety baseline |

### Daily Quotas

- **Hourly:** 300 requests
- **Daily:** 3,600 requests
- Quotas reset automatically each hour/day

### Connection Health

The bot monitors:
- Authentication failures (401/403 errors)
- Rate limiting (429 errors)
- Media send failures
- Excessive disconnects (>3 per 24h)
- Message send success rate

---

## 📊 Monitoring & Alerts

### Automatic Alerts

The bot owner receives alerts when:
- Ban risk reaches HIGH threshold
- Critical auth failure detected
- Media sending blocked
- Excessive disconnections occur

**Alert Format:**
```
🚨 Ban Risk Alert 🚨

🔴 CRITICAL: STOP using this number immediately.

Session: session
Error: Rate limited by WhatsApp
```

### Manual Health Check

Check session health anytime:

```bash
# In a Node REPL or from another service:
const { globalSessionManager } = require('./sessionManager');
const status = globalSessionManager.getSessionStatus('session');
console.log(status);
```

---

## 🔒 Security Best Practices

### 1. Protect Your .env File

```bash
# Make .env readable only by owner
chmod 600 .env

# Never commit .env to git
echo ".env" >> .gitignore
```

### 2. Rotate API Keys Regularly

For each external API (Groq, Claude, Gemini, Paystack):
1. Generate a new key on the service dashboard
2. Update `.env`
3. Restart the bot
4. Delete the old key from the service

**Schedule:** At least quarterly (every 3 months)

### 3. Use Environment-Specific Keys

```env
# Development (sandboxed/test keys)
PAYSTACK_SECRET_KEY=sk_test_dev_key

# Production (live keys only on production server)
PAYSTACK_SECRET_KEY=sk_live_prod_key
```

### 4. Database Security

```bash
# Use strong password (20+ chars, mixed case, numbers, symbols)
DB_PASSWORD=Tr0p!c@lSunset#2024$Secure

# Limit database access to localhost only
# In postgresql.conf:
# listen_addresses = 'localhost'
```

### 5. Monitor Access Logs

```bash
# Check which commands are being used frequently
grep "command" logs/*.log | wc -l

# Monitor failed authentications
grep "401\|403\|FAIL" logs/*.log
```

---

## 🚀 Deployment to VPS

### Option 1: Using PM2 (Recommended)

```bash
# Install PM2 globally
npm install -g pm2

# Start bot with PM2
pm2 start index.js --name kingbot --expose-gc

# Auto-restart on reboot
pm2 startup
pm2 save

# Monitor in real-time
pm2 monit
```

### Option 2: Using systemd

Create `/etc/systemd/system/kingbot.service`:

```ini
[Unit]
Description=KINGBOT WhatsApp Bot
After=network.target

[Service]
Type=simple
User=kingbot
WorkingDirectory=/home/kingbot/bot
Environment="NODE_ENV=production"
ExecStart=/usr/bin/node --expose-gc /home/kingbot/bot/index.js
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Then:
```bash
sudo systemctl daemon-reload
sudo systemctl start kingbot
sudo systemctl enable kingbot
sudo systemctl status kingbot
```

### Option 3: Using Docker (Recommended for Scaling)

Create `Dockerfile`:

```dockerfile
FROM node:18-slim

WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY . .

ENV NODE_ENV=production
EXPOSE 3000

CMD ["node", "--expose-gc", "index.js"]
```

Then:

```bash
# Build image
docker build -t kingbot:latest .

# Run container
docker run -d \
  --name kingbot \
  --restart unless-stopped \
  -e NODE_ENV=production \
  -v $(pwd)/.env:/app/.env:ro \
  -v kingbot_data:/app/data \
  -v kingbot_sessions:/app/session \
  kingbot:latest

# View logs
docker logs -f kingbot
```

---

## 🔧 Troubleshooting

### Bot Won't Connect

```
❌ Error: QR code timeout / Pairing failed
```

**Solution:**
1. Delete the `session` folder: `rm -rf session`
2. Restart: `npm start`
3. Scan QR code immediately (code expires after 60s)

### "PAYSTACK_SECRET_KEY not set"

```
❌ Payment system is not configured
```

**Solution:**
1. Check `.env` has `PAYSTACK_SECRET_KEY=sk_live_...`
2. Verify no trailing spaces
3. Restart bot: `npm start`

### High Memory Usage

The bot includes automatic garbage collection:

```bash
# If memory still high, start with explicit GC flag
npm start
# which runs: node --expose-gc index.js
```

### Bot Keeps Disconnecting

```
⚠️ Frequent disconnects - possible ban incoming
```

**Check:**
1. Internet connection: `ping google.com`
2. WhatsApp isn't logged in elsewhere
3. Bot isn't rate-limited: `.banstatus`
4. No firewall blocking: Allow ports 443, 5222

**If persistent:**
- Switch to a new WhatsApp number
- Use a residential proxy (VPN)
- Reduce message frequency

### "Ban Risk CRITICAL"

```
🚫 CRITICAL: STOP using this number immediately.
```

**Actions:**
1. Stop the bot: `npm stop` (or Ctrl+C)
2. Wait 24-48 hours
3. Try with new WhatsApp number
4. Review: What caused high risk score?
   - Too many messages?
   - Too many errors?
   - Media sending failures?

---

## 📈 Scaling Considerations

### Single Instance Limits
- ~1 WhatsApp account per instance
- ~100-500 messages/hour (safe limits)
- ~20-50 concurrent conversations
- Memory: ~300-500MB

### Multi-Instance Setup

For multiple bots, use separate:
- `.env` files (or env variables per instance)
- Session directories
- Database users
- Port numbers (for webhooks)

Example:
```bash
# Bot #1
PORT=3001 SESSION_DIR=session1 npm start

# Bot #2 (in another terminal)
PORT=3002 SESSION_DIR=session2 npm start
```

### Database Optimization

```sql
-- Index frequently queried columns
CREATE INDEX idx_user_phone ON users(phone_number);
CREATE INDEX idx_transaction_date ON transactions(created_at);

-- Archive old data
DELETE FROM logs WHERE created_at < NOW() - INTERVAL '90 days';
```

---

## 📝 Important Notes

### Terms of Service Compliance

⚠️ **WhatsApp Policies:**
- Bots are technically against ToS
- WhatsApp may ban your number without notice
- No official bot API (Baileys is reverse-engineered)
- Use at your own risk

### Liability

- This bot is **provided as-is**
- Author assumes **no liability** for banned accounts
- Users are responsible for compliance with WhatsApp ToS
- Keep backups of important data

### Support & Updates

- Check CHANGELOG.md for updates
- Report bugs: Create an issue (if available)
- Community: [Discord/Telegram link if available]

---

## ✅ Verification Checklist

Before going live:

- [ ] `.env` configured with all keys
- [ ] Database created and connected
- [ ] Tested with `.help` command
- [ ] Checked `.banstatus` (should be GREEN)
- [ ] Verified `.credits` works (if enabled)
- [ ] Tested `.ai` with sample query
- [ ] Reviewed rate limits (don't exceed)
- [ ] Set up monitoring (PM2/systemd)
- [ ] Backed up `session` directory
- [ ] Reviewed security checklist above
- [ ] Tested with small traffic first

---

## 🆘 Emergency Procedures

### If Ban is Imminent

1. **Immediately stop bot:**
   ```bash
   npm stop
   ```

2. **Backup session data:**
   ```bash
   cp -r session session_backup_$(date +%s)
   ```

3. **Switch to new number:**
   - Get new WhatsApp number
   - Delete `session` folder
   - Update `PHONE_NUMBER` in `.env`
   - Restart: `npm start`

4. **Pause all bulk operations**
   - Reduce message frequency to 1/second max
   - Avoid media downloads
   - Focus on essential features only

### If Banned

1. The account is permanently unusable with Baileys
2. Get a new phone number
3. Start fresh (new session directory)
4. Review what caused the ban
5. Implement stricter rate limits

---

## 📞 Contacts

- **WhatsApp Support:** Within WhatsApp app
- **License Issues:** Contact bot owner
- **Database Help:** PostgreSQL docs

**Last Updated:** September 2026

---

**🎉 You're ready to deploy KINGBOT safely!**

Remember: **Safe operation > maximum features**

If in doubt, use `.banstatus` and follow its recommendations.
