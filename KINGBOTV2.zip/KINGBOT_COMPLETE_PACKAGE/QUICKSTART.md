# ⚡ KINGBOT - Quick Start Reference

## 🚀 5-Minute Setup

```bash
# 1. Extract
tar -xzf KINGBOT_SECURE_UPDATED.tar.gz
cd kingbot

# 2. Install
npm install

# 3. Configure
cp .env.example .env
nano .env  # Add your API keys

# 4. Run
npm start

# 5. Pair
# Scan QR code or use pairing code shown in terminal
```

---

## 🔑 Minimum .env Configuration

```env
BOT_LICENSE_KEY=YOUR_LICENSE
OWNER_NUMBER=2349073828261
PAYSTACK_SECRET_KEY=sk_live_YOUR_KEY
GROQ_API_KEY=Gsk_YOUR_KEY
```

---

## 📊 Check Health

```
.banstatus    # Risk level & recommendations
.help         # List all commands
.credits      # Check credit balance
```

---

## ⚙️ Adjust Rate Limits

Edit `.env`:
```env
# Requests per hour (default 300)
REQUESTS_PER_HOUR=300

# Alert threshold (0-100, default 50)
BAN_RISK_ALERT_THRESHOLD=50

# Auto-pause threshold (0-100, default 80)
CRITICAL_BAN_RISK_THRESHOLD=80
```

Restart bot after changes.

---

## 🚨 Emergency: Account at Risk

**If `.banstatus` shows CRITICAL:**

1. Stop bot: `Ctrl+C`
2. Backup: `cp -r session session_backup`
3. Delete session: `rm -rf session`
4. Get new number
5. Update: `PHONE_NUMBER=NEW_NUMBER` in `.env`
6. Start: `npm start`

---

## 🔄 Rotate API Keys

1. Generate new key on service dashboard
2. Update `.env`: `API_KEY_NAME=new_key_value`
3. Restart: `npm start`
4. Delete old key from dashboard

**Do this:** Quarterly (every 3 months)

---

## 📈 Monitor in Production

### Using PM2
```bash
npm install -g pm2

# Start
pm2 start index.js --name kingbot --expose-gc

# Monitor
pm2 monit

# Logs
pm2 logs kingbot

# Restart
pm2 restart kingbot
```

### Using systemd
```bash
sudo systemctl start kingbot
sudo systemctl status kingbot
sudo journalctl -u kingbot -f
```

---

## 🔒 Security Checklist

- [ ] `.env` created (not committed to git)
- [ ] All API keys filled in
- [ ] Database configured (if using)
- [ ] File permissions: `chmod 600 .env`
- [ ] `.gitignore` includes `.env`
- [ ] No hardcoded secrets in code
- [ ] `.banstatus` returns GREEN/SAFE

---

## 🐛 Common Issues

| Issue | Fix |
|-------|-----|
| "Cannot find module 'dotenv'" | `npm install` |
| "BOT_LICENSE_KEY not set" | Edit `.env`, add key |
| "PAYSTACK_SECRET_KEY not set" | Edit `.env`, add key |
| "Module not found" | `npm install` |
| "Pairing timeout" | Delete session folder, try again |
| "Rate limited" | Wait, or increase `REQUESTS_PER_HOUR` |

---

## 📞 Key Commands

```
.help                # Show all commands
.banstatus          # Ban risk report (owner)
.credits            # Your credit balance
.ai <query>         # Ask Claude/Groq AI
.tiktok <url>       # Download TikTok video
.song <name>        # Download song
.buyai <plan>       # Buy more credits
```

---

## 🚫 Do NOT

```
❌ Commit .env to git
❌ Share .env file
❌ Use hardcoded keys in code
❌ Spam commands (triggers ban risk)
❌ Download 100+ files/hour
❌ Send to many users at once
```

---

## ✅ Do

```
✅ Use .env for all secrets
✅ Rotate keys quarterly
✅ Check .banstatus weekly
✅ Backup session folder
✅ Update npm packages: npm update
✅ Read SETUP.md for details
✅ Monitor bot health
```

---

## 📊 Rate Limits Per Minute

| Command | Limit | Wait Time if Hit |
|---------|-------|-----------------|
| .ai, .aichat | 5 | 12s |
| .download, .tiktok, .song | 3 | 20s |
| .imagine, .image | 2 | 30s |
| Other commands | 20 | 3s |

---

## 📈 Resource Requirements

- **CPU:** 1 core minimum, 2 recommended
- **RAM:** 512MB minimum, 1GB recommended
- **Storage:** 2GB for logs & data
- **Bandwidth:** Unlimited (minimal usage)
- **Node.js:** v18+
- **Database:** PostgreSQL 12+ (optional)

---

## 🔗 Useful Links

- **Groq API:** https://console.groq.com
- **Anthropic API:** https://console.anthropic.com
- **Gemini API:** https://ai.google.dev
- **Paystack:** https://dashboard.paystack.com
- **Node.js:** https://nodejs.org/
- **PM2:** https://pm2.keymetrics.io/

---

## 📚 Full Documentation

- **SETUP.md** - Complete setup with security
- **CHANGES.md** - All updates in this version
- **.env.example** - All configuration options

---

**Last Updated:** September 2026

**Need help?** Read SETUP.md → Troubleshooting section
