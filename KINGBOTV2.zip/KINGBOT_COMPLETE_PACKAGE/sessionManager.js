/**
 * 📊 SESSION MANAGER
 * Manages rate limiting, quotas, and resource allocation per session
 */

const BanRiskMonitor = require('./banMonitor');

class SessionManager {
  constructor() {
    this.sessions = new Map();
    this.globalMetrics = {
      totalMessages: 0,
      totalErrors: 0,
      activeSessions: 0
    };
  }

  /**
   * Create or get session
   */
  getOrCreateSession(sessionId, ownerJid) {
    if (!this.sessions.has(sessionId)) {
      this.sessions.set(sessionId, {
        sessionId,
        ownerJid,
        monitor: new BanRiskMonitor(sessionId, ownerJid),
        rateLimit: new RateLimiter(sessionId),
        quotaManager: new QuotaManager(sessionId),
        createdAt: Date.now(),
        lastActivity: Date.now()
      });
      this.globalMetrics.activeSessions = this.sessions.size;
    }
    
    const session = this.sessions.get(sessionId);
    session.lastActivity = Date.now();
    return session;
  }

  /**
   * Get monitor for session
   */
  getMonitor(sessionId) {
    const session = this.sessions.get(sessionId);
    return session ? session.monitor : null;
  }

  /**
   * Check if command is rate limited
   */
  isRateLimited(sessionId, command) {
    const session = this.sessions.get(sessionId);
    if (!session) return false;
    return !session.rateLimit.check(command);
  }

  /**
   * Check if quota is exceeded
   */
  isQuotaExceeded(sessionId) {
    const session = this.sessions.get(sessionId);
    if (!session) return false;
    return !session.quotaManager.canUse();
  }

  /**
   * Record message usage
   */
  recordUsage(sessionId) {
    const session = this.sessions.get(sessionId);
    if (session) {
      session.quotaManager.consume();
      this.globalMetrics.totalMessages++;
    }
  }

  /**
   * Get session status
   */
  getSessionStatus(sessionId) {
    const session = this.sessions.get(sessionId);
    if (!session) return null;

    return {
      sessionId,
      monitor: session.monitor.getStatus(),
      rateLimit: session.rateLimit.getStatus(),
      quota: session.quotaManager.getStatus(),
      uptime: Date.now() - session.createdAt,
      lastActivity: Date.now() - session.lastActivity
    };
  }

  /**
   * Get all sessions status
   */
  getAllSessions() {
    const statuses = [];
    for (const [sessionId, session] of this.sessions) {
      statuses.push(this.getSessionStatus(sessionId));
    }
    return statuses;
  }

  /**
   * Cleanup old inactive sessions
   */
  cleanupInactiveSessions(inactivityTimeoutMs = 3600000) { // 1 hour default
    const now = Date.now();
    const toDelete = [];

    for (const [sessionId, session] of this.sessions) {
      if (now - session.lastActivity > inactivityTimeoutMs) {
        toDelete.push(sessionId);
      }
    }

    toDelete.forEach(sessionId => this.sessions.delete(sessionId));
    this.globalMetrics.activeSessions = this.sessions.size;

    if (toDelete.length > 0) {
      console.log(`[SessionManager] Cleaned up ${toDelete.length} inactive sessions`);
    }

    return toDelete;
  }
}

/**
 * 🚦 RATE LIMITER
 * Per-command rate limiting
 */
class RateLimiter {
  constructor(sessionId) {
    this.sessionId = sessionId;
    this.commandLimits = new Map();
    this.windowMs = 60000; // 1 minute
    this.limits = {
      'ai': 5,           // 5 per minute
      'aiChat': 5,       // 5 per minute
      'aichat': 5,       // 5 per minute
      'download': 3,     // 3 per minute
      'tiktok': 3,       // 3 per minute
      'song': 2,         // 2 per minute (media download)
      'image': 3,        // 3 per minute
      'imagine': 2,      // 2 per minute (heavy resource)
      'send': 10,        // 10 per minute (internal)
      'default': 20      // 20 per minute (default)
    };
  }

  check(command) {
    const limit = this.limits[command] || this.limits.default;
    const key = `${this.sessionId}:${command}`;

    if (!this.commandLimits.has(key)) {
      this.commandLimits.set(key, {
        count: 0,
        reset: Date.now() + this.windowMs
      });
    }

    const data = this.commandLimits.get(key);
    const now = Date.now();

    // Reset if window expired
    if (now > data.reset) {
      data.count = 0;
      data.reset = now + this.windowMs;
    }

    data.count++;

    return data.count <= limit;
  }

  getRemainingForCommand(command) {
    const limit = this.limits[command] || this.limits.default;
    const key = `${this.sessionId}:${command}`;
    const data = this.commandLimits.get(key);

    if (!data) return limit;
    return Math.max(0, limit - data.count);
  }

  getStatus() {
    return {
      sessionId: this.sessionId,
      totalLimitedCommands: this.commandLimits.size,
      limits: this.limits
    };
  }
}

/**
 * 📊 QUOTA MANAGER
 * Hourly/daily quota system
 */
class QuotaManager {
  constructor(sessionId) {
    this.sessionId = sessionId;
    this.hourlyQuota = parseInt(process.env.REQUESTS_PER_HOUR || 300);
    this.dailyQuota = this.hourlyQuota * 12; // 12 hours of hourly quota
    
    this.hourlyUsage = [];
    this.dailyUsage = [];
  }

  canUse(tokens = 1) {
    const now = Date.now();
    const hourAgo = now - 3600000;
    const dayAgo = now - 86400000;

    // Filter old entries
    this.hourlyUsage = this.hourlyUsage.filter(t => t > hourAgo);
    this.dailyUsage = this.dailyUsage.filter(t => t > dayAgo);

    return (
      this.hourlyUsage.length + tokens <= this.hourlyQuota &&
      this.dailyUsage.length + tokens <= this.dailyQuota
    );
  }

  consume(tokens = 1) {
    const now = Date.now();
    for (let i = 0; i < tokens; i++) {
      this.hourlyUsage.push(now);
      this.dailyUsage.push(now);
    }
  }

  getStatus() {
    const now = Date.now();
    const hourAgo = now - 3600000;
    const dayAgo = now - 86400000;

    this.hourlyUsage = this.hourlyUsage.filter(t => t > hourAgo);
    this.dailyUsage = this.dailyUsage.filter(t => t > dayAgo);

    return {
      hourlyUsage: this.hourlyUsage.length,
      hourlyQuota: this.hourlyQuota,
      hourlyRemaining: Math.max(0, this.hourlyQuota - this.hourlyUsage.length),
      dailyUsage: this.dailyUsage.length,
      dailyQuota: this.dailyQuota,
      dailyRemaining: Math.max(0, this.dailyQuota - this.dailyUsage.length),
      hourlyPercentage: Math.round((this.hourlyUsage.length / this.hourlyQuota) * 100),
      dailyPercentage: Math.round((this.dailyUsage.length / this.dailyQuota) * 100)
    };
  }
}

// Global session manager instance
const globalSessionManager = new SessionManager();

// Cleanup inactive sessions every 30 minutes
setInterval(() => {
  globalSessionManager.cleanupInactiveSessions();
}, 1800000);

module.exports = {
  SessionManager,
  RateLimiter,
  QuotaManager,
  globalSessionManager
};
