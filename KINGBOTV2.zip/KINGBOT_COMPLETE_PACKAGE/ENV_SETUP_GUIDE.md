# 🔑 HOW TO SET UP YOUR .env FILE - COMPLETE GUIDE

**Time Required:** 15-20 minutes  
**Difficulty:** Beginner-Friendly ✅

---

## 📋 What You Need to Do

You will copy values from websites and paste them into a `.env` file.

**That's it!** No coding required.

---

## 🚀 Step-by-Step Instructions

### PART 1: CREATE THE .env FILE (5 minutes)

**Step 1: Navigate to bot folder**
```bash
cd kingbot
```

**Step 2: Copy the template file**
```bash
cp .env.configured .env
```

**Step 3: Open .env file for editing**

**On Windows:**
- Right-click `.env`
- Select "Open with Notepad"
- Or use VS Code

**On Mac/Linux:**
```bash
nano .env
```

You should see lots of text starting with `BOT_NAME=KINGBOT`

---

### PART 2: FILL IN THE REQUIRED KEYS (10 minutes)

#### 🔴 REQUIRED #1: BOT_LICENSE_KEY

**What it is:** Your bot's license/activation key

**How to get it:**
- Ask your bot provider for the license key
- It usually looks like: `KING-ABC123XYZ`

**What to change:**
```env
# BEFORE:
BOT_LICENSE_KEY=YOUR_LICENSE_KEY_HERE

# AFTER:
BOT_LICENSE_KEY=KING-ABC123XYZ
```

**Where to find in file:** Line ~30

---

#### 🔴 REQUIRED #2: PAYSTACK KEYS (Payment)

**What it is:** Payment gateway credentials

**How to get them:**

1. **Go to:** https://dashboard.paystack.com
2. **Sign up** (if you don't have account)
3. **Log in**
4. **Click:** "Settings" (top right)
5. **Click:** "API Keys & Webhooks"
6. **You'll see TWO keys:**
   - Secret Key (starts with `sk_live_`)
   - Public Key (starts with `pk_live_`)

7. **Copy Secret Key** and paste:
```env
PAYSTACK_SECRET_KEY=sk_live_YOUR_ACTUAL_KEY_HERE
PAYSTACK_SECRET=sk_live_YOUR_ACTUAL_KEY_HERE
```

8. **Copy Public Key** and paste:
```env
PAYSTACK_PUBLIC_KEY=pk_live_YOUR_ACTUAL_KEY_HERE
```

**Where to find in file:** Lines ~45-50

---

#### 🔴 REQUIRED #3: GROQ API KEY (AI)

**What it is:** API key for Groq AI (powers `.ai` command)

**How to get it:**

1. **Go to:** https://console.groq.com
2. **Click:** "Sign Up" (top right)
   - Use email
   - Or use Google account
3. **Fill the form** (name, email, password)
4. **Check email** and verify
5. **After verified**, you'll be in dashboard
6. **Click:** "API Keys" (on left menu)
7. **Click:** "Create API Key"
8. **Copy the key** (starts with `Gsk_`)
9. **Paste in .env:**

```env
GROQ_API_KEY=Gsk_YOUR_ACTUAL_KEY_HERE
```

**Where to find in file:** Lines ~65-67

---

### PART 3: FILL IN OPTIONAL KEYS (5 minutes)

#### 🟡 OPTIONAL #1: ANTHROPIC (Claude AI)

**What it is:** Better AI for `.ai` command

**How to get it:**

1. **Go to:** https://console.anthropic.com
2. **Click:** "Sign Up" (or log in)
3. **Fill form** (email, password)
4. **Verify email**
5. **After login**, click "API Keys"
6. **Click:** "Create Key"
7. **Copy the key** (starts with `sk-ant-`)
8. **Paste:**

```env
ANTHROPIC_API_KEY=sk-ant-YOUR_ACTUAL_KEY_HERE
```

**Skip if:** You don't want Claude AI. Groq is enough.

---

#### 🟡 OPTIONAL #2: GOOGLE GEMINI (Google AI)

**What it is:** Extra AI option for `.ai` command

**How to get it:**

1. **Go to:** https://ai.google.dev
2. **Click:** "Get Started"
3. **Sign in with Google**
4. **Click:** "Create API key in new project"
5. **Copy the key shown**
6. **Paste:**

```env
GEMINI_API_KEY=AIzaSy_YOUR_ACTUAL_KEY_HERE
```

**Skip if:** You don't want Google AI.

---

### PART 4: OPTIONAL - EMAIL SETUP (5 minutes)

**What it is:** For email verification features

**How to get Gmail App Password:**

1. **Go to:** https://myaccount.google.com/apppasswords
2. **Sign in with your Gmail**
3. **Select:** "Mail" and "Windows Computer" (or device)
4. **Click:** "Generate"
5. **Copy the 16-character password shown**
6. **Paste:**

```env
GMAIL_USER=your-actual-email@gmail.com
GMAIL_APP_PASSWORD=xxxx xxxx xxxx xxxx
```

**Important:** This is NOT your regular Gmail password!

---

## ✅ CHECKLIST: What You Should See

After filling in, your file should have:

- [ ] `BOT_LICENSE_KEY=KING-...` (not YOUR_...)
- [ ] `PAYSTACK_SECRET_KEY=sk_live_...` (not YOUR_...)
- [ ] `PAYSTACK_PUBLIC_KEY=pk_live_...` (not YOUR_...)
- [ ] `GROQ_API_KEY=Gsk_...` (not YOUR_...)
- [ ] No lines with `YOUR_` left (except optional ones you skip)

**Example of GOOD:**
```env
BOT_LICENSE_KEY=KING-ABC123DEF
PAYSTACK_SECRET_KEY=sk_live_abc123xyz789
GROQ_API_KEY=Gsk_xyz789abc123
```

**Example of BAD (still has placeholders):**
```env
BOT_LICENSE_KEY=YOUR_LICENSE_KEY_HERE
PAYSTACK_SECRET_KEY=YOUR_SECRET_KEY_HERE
GROQ_API_KEY=Gsk_YOUR_GROQ_KEY
```

---

## 💾 SAVE THE FILE

**On Windows (Notepad):**
- Press: `Ctrl+S`
- Make sure filename is `.env` (not `.env.txt`)

**On Mac/Linux (nano):**
- Press: `Ctrl+X`
- Press: `Y` (for yes)
- Press: `Enter`

---

## 🧪 TEST IT WORKS

```bash
# Check file was saved
cat .env | grep "BOT_LICENSE_KEY"

# Should show your actual key, like:
# BOT_LICENSE_KEY=KING-ABC123XYZ

# If it shows YOUR_..., you didn't save correctly
```

---

## 🚀 NOW YOU'RE READY!

```bash
# Install
npm install

# Start bot
npm start

# Expected output:
# ✅ License verification passed successfully!
# 🤴 KINGBOT Loaded 60+ commands.
# 👑 YOUR WHATSAPP PAIRING CODE: 123-456-7890
```

If you see this ✅, everything works!

---

## ❌ COMMON MISTAKES & FIXES

### Mistake #1: "BOT_LICENSE_KEY not set"

**Problem:** You left it as `YOUR_LICENSE_KEY_HERE`

**Fix:** 
1. Open .env
2. Find: `BOT_LICENSE_KEY=YOUR_LICENSE_KEY_HERE`
3. Change to: `BOT_LICENSE_KEY=KING-YOURACTUALKEY`
4. Save (Ctrl+S)
5. Try again: `npm start`

---

### Mistake #2: "Cannot find module 'dotenv'"

**Problem:** Forgot to run `npm install`

**Fix:**
```bash
npm install
npm start
```

---

### Mistake #3: "PAYSTACK_SECRET_KEY not set"

**Problem:** You left `sk_live_YOUR_KEY_HERE`

**Fix:**
1. Go to paystack.com
2. Copy your ACTUAL secret key
3. Paste in .env
4. Save file
5. Restart: `npm start`

---

### Mistake #4: Pairing code expires

**Problem:** You took too long to scan QR

**Fix:**
1. Stop bot: `Ctrl+C`
2. Delete session: `rm -rf session` (or delete session folder)
3. Restart: `npm start`
4. Scan QR code IMMEDIATELY (expires in 60 seconds)

---

## 📱 WHERE TO GET EACH KEY - QUICK LINKS

| Service | Link | Key Format |
|---------|------|-----------|
| Groq AI | https://console.groq.com | Gsk_... |
| Paystack | https://dashboard.paystack.com | sk_live_... |
| Anthropic | https://console.anthropic.com | sk-ant-... |
| Google Gemini | https://ai.google.dev | AIzaSy_... |
| Gmail App Password | https://myaccount.google.com/apppasswords | 16 chars |

---

## 🔐 SECURITY REMINDERS

**DO:**
- ✅ Keep .env file secret
- ✅ Don't share .env with anyone
- ✅ Don't post .env online
- ✅ Add .env to .gitignore (if using git)
- ✅ Rotate keys every 3 months

**DON'T:**
- ❌ Commit .env to GitHub/GitLab
- ❌ Share .env in Discord/Telegram
- ❌ Take screenshots of .env
- ❌ Put .env on public servers

---

## ❓ STILL CONFUSED?

**I don't have X key:**
- Leave it as `YOUR_...` 
- That feature will be disabled
- Bot will still work

**Example:**
```env
# Skip if you don't have Anthropic
ANTHROPIC_API_KEY=sk-ant-YOUR_ANTHROPIC_KEY_HERE

# Skip if you don't have Gemini
GEMINI_API_KEY=YOUR_GEMINI_KEY_HERE
```

**The ONLY requirement:**
- `BOT_LICENSE_KEY` (must have)
- `PAYSTACK_SECRET_KEY` (needed for payments)
- `GROQ_API_KEY` (needed for AI)

---

## 🎉 YOU DID IT!

Once `.env` is set up:

1. Run: `npm install`
2. Run: `npm start`
3. Scan QR code
4. Bot comes online
5. Send: `.help`
6. Enjoy! 🚀

---

## 📞 QUICK HELP

**File not found?**
```bash
ls -la | grep env
# Should show: .env
```

**Keys not working?**
```bash
cat .env | grep -v "^#" | grep -v "^$"
# Should show all your actual keys (not YOUR_...)
```

**Still stuck?**
- Read this guide again (section by section)
- Check you copied EXACTLY what's shown
- Make sure file is saved (Ctrl+S)
- Try: `npm start` again

---

**Time spent:** ~20 minutes ✅  
**Difficulty:** Easy ✅  
**Knowledge needed:** Zero coding ✅

**You've got this! 💪**
